/* 2453253 ������ �Ű� */
#pragma once
#include "config.h"
#include "options.h"
#include "../include/check_exe.h"    // Ϊ���� CheckExec_Errno

int do_check_only(const Config& cfg, const Options& opt);
int run_demo(const Config& cfg, const Options& opt);

//�ռ� demo ��׼���
int collect_demo_outputs(const Config& cfg,const Options& opt,std::vector<std::string>& std_outs,std::vector<CheckExec_Errno>& std_status);
int run_students(const Config& cfg, const Options& opt);