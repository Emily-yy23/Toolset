/* 2453253 ������ �Ű� */
#include "../include/txt_compare.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <cctype>
#include <cstring>

using namespace std;

txt_compare::txt_compare(const string& f1, const string& f2,const string& trim, const string& display,int skip, int offset, int max_diff, int max_line,bool ignore_bl, bool notignore_lf, bool dbg) :filename1(f1), filename2(f2), trim_type(trim), display_type(display),line_skip(skip), line_offset(offset), line_max_diffnum(max_diff),line_max_linenum(max_line), ignore_blank(ignore_bl),not_ignore_linefeed(notignore_lf), debug(dbg),  files_match(true), diff_count(0), line_maxlen(0) 
{
}

string txt_compare::trim_string(const string& str, const string& type) 
{
    if (type == "none") return str;

    string result = str;

    if (type == "left" || type == "all")
    {
        size_t start = result.find_first_not_of(" \t\r\n");
        if (start != string::npos) 
        {
            result = result.substr(start);
        }
        else 
        {
            result = "";
        }
    }

    if (type == "right" || type == "all") 
    {
        string line_ending = "";
        if (!result.empty()) 
        {
            if (result.length() >= 2 && result[result.length() - 2] == '\r' && result[result.length() - 1] == '\n')
            {
                line_ending = "\r\n";
                result = result.substr(0, result.length() - 2);
            }
            else if (!result.empty() &&(result.back() == '\r' || result.back() == '\n'))
            {
                line_ending = string(1, result.back());
                result = result.substr(0, result.length() - 1);
            }
        }

        size_t end = result.find_last_not_of(" \t");
        if (end != string::npos)
        {
            result = result.substr(0, end + 1);
        }
        else 
        {
            result = "";
        }

        result += line_ending;
    }

    return result;
}

bool txt_compare::is_blank_line(const string& line) 
{
    for (size_t i = 0; i < line.length(); i++) 
    {
        char c = line[i];
        if (c != ' ' && c != '\t' && c != '\r' && c != '\n') 
        {
            return false;
        }
    }
    return true;
}

string txt_compare::get_line_ending_type(const string& line, bool include_eof) 
{
    if (line.empty()) 
    {
        if (include_eof) return "<EOF>";
        return "";
    }

    size_t len = line.length();
    if (len >= 2 && line[len - 2] == '\r' && line[len - 1] == '\n') 
    {
        return "<CR><LF>";
    }
    else if (len >= 1 && line.back() == '\r')
    {
        return "<CR>";
    }
    else if (len >= 1 && line.back() == '\n') 
    {
        return "<LF>";
    }

    if (include_eof)
    {
        return "<EOF>";
    }

    return "";
}

string txt_compare::replace_special_chars(const string& str)
{
    string result;
    for (size_t i = 0; i < str.length(); i++)
    {
        char c = str[i];
        switch (c) 
        {
        case '\r':
            result += "<CR>"; 
            break;
        case '\n': 
            result += "<LF>"; 
            break;
        case '\t': 
            result += "\\t";
            break;
        case '\v':
            result += "<VT>"; 
            break;
        case '\b': 
            result += "<BS>"; 
            break;
        case '\a': 
            result += "<BEL>";
            break;
        default: 
            result += c;
        }
    }
    return result;
}

string txt_compare::to_hex_string(const string& str, int start_pos) 
{
    ostringstream oss;
    oss << hex << setfill('0');
    for (size_t i = 0; i < str.length(); i++) 
    {
        unsigned char c = static_cast<unsigned char>(str[i]);
        oss << setw(2) << static_cast<int>(c) << " ";
        if ((i + 1) % 16 == 0 && i + 1 < str.length()) 
        {
            oss << endl << setw(8) << setfill('0')<< dec << (static_cast<int>(start_pos) + static_cast<int>(i) + 1) << " : " << hex << setfill('0');
        }
    }
    return oss.str();
}

void txt_compare::compare_lines(const string& line1, const string& line2,int line_num1, int line_num2,bool& content_diff, bool& ending_diff) 
{
    content_diff = false;
    ending_diff = false;

    // ��ȡԭʼ���н�����
    string ending1 = get_line_ending_type(line1);
    string ending2 = get_line_ending_type(line2);

    string content1 = line1, content2 = line2;
    if (!ending1.empty()) 
    {
        size_t pos = line1.length();
        if (ending1 == "<CR><LF>") 
            pos -= 2;
        else if (ending1 == "<CR>" || ending1 == "<LF>") 
            pos -= 1;
        content1 = line1.substr(0, pos);
    }
    if (!ending2.empty()) 
    {
        size_t pos = line2.length();
        if (ending2 == "<CR><LF>")
            pos -= 2;
        else if (ending2 == "<CR>" || ending2 == "<LF>") 
            pos -= 1;
        content2 = line2.substr(0, pos);
    }

    content_diff = (content1 != content2);

    if (not_ignore_linefeed)
    {
        ending_diff = (ending1 != ending2);
    }
    else 
    {
        ending_diff = false;
    }
}

void txt_compare::print_ruler(ostream& oss, int max_len, bool is_detailed)
{
    //�����߳��ȣ�����ȡ��
    int ruler_len = (max_len / 10 + 2) * 10 + 1;

    // ��һ�к���
    oss << "        ";
    for (int i = 0; i < ruler_len; i++) 
    {
        oss << "-";
    }
    oss << endl;

    // �ڶ��У�ʮλ��
    oss << "        ";
    for (int i = 0; i < ruler_len; i++) 
    {
        if (i % 10 == 0) 
        {
            oss << (i / 10) % 10;
        }
        else 
        {
            oss << " ";
        }
    }
    oss << endl;

    // �����У���λ��
    oss << "        ";
    for (int i = 0; i < ruler_len; i++) 
    {
        oss << i % 10;
    }
    oss << endl;

    // �����к���
    oss << "        ";
    for (int i = 0; i < ruler_len; i++) 
    {
        oss << "-";
    }
    oss << endl;
}

string txt_compare::format_difference(const string& line1, const string& line2,int line_num1, int line_num2, bool is_normal)
{
    ostringstream oss;

    // ��ȡ���ݺ��н�����
    string ending1 = get_line_ending_type(line1);
    string ending2 = get_line_ending_type(line2);

    // ��ȡ����
    string content1 = line1, content2 = line2;
    if (!ending1.empty()) 
    {
        size_t pos = line1.length();
        if (ending1 == "<CR><LF>") 
            pos -= 2;
        else if (ending1 == "<CR>" || ending1 == "<LF>") 
            pos -= 1;
        content1 = line1.substr(0, pos);
    }
    if (!ending2.empty()) 
    {
        size_t pos = line2.length();
        if (ending2 == "<CR><LF>") 
            pos -= 2;
        else if (ending2 == "<CR>" || ending2 == "<LF>")
            pos -= 1;
        content2 = line2.substr(0, pos);
    }

    int max_len = max(static_cast<int>(content1.length()),
        static_cast<int>(content2.length()));

    if (is_normal)
    {
        bool content_diff, ending_diff;
        compare_lines(line1, line2, line_num1, line_num2, content_diff, ending_diff);

        oss << "��[" << line_num1 << " / " << line_num2 << "]�� - ";

        if (content_diff) 
        {
            int diff_pos = -1;
            int min_len = min(static_cast<int>(content1.length()),static_cast<int>(content2.length()));
            for (int i = 0; i < min_len; i++) 
            {
                if (content1[i] != content2[i]) 
                {
                    diff_pos = i ;  
                    break;
                }
            }

            if (diff_pos > 0) 
            {
                oss << "��[" << diff_pos << "]���ַ���ʼ�в���" << endl;
            }
            else if (content1.length() != content2.length()) 
            {
                oss << "��[" << min_len + 1 << "]���ַ���ʼ�в���" << endl;
            }
            else
            {
                oss << "�����в���" << endl;
            }
        }
        else if (ending_diff) 
        {
            oss << "�н�������ͬ" << endl;
        }
        else {
            oss << "�в���" << endl;
        }

        print_ruler(oss, max_len, false);

        oss << "�ļ�1 : ";
        string display1 = replace_special_chars(content1);
        oss << display1;
        if (!ending1.empty()) 
        {
            oss << ending1;
        }
        else 
        {
            oss << "<EOF>";
        }
        oss << endl;

        oss << "�ļ�2 : ";
        string display2 = replace_special_chars(content2);
        oss << display2;
        if (!ending2.empty()) 
        {
            oss << ending2;
        }
        else {
            oss << "<EOF>";
        }
        oss << endl;

    }
    else 
    {
        // detailedģʽ���
        oss << "��[" << line_num1 << " / " << line_num2 << "]�� - �н�������ͬ" << endl;

        print_ruler(oss, max_len, true);

        oss << "�ļ�1 : ";
        string display1 = replace_special_chars(content1);
        oss << display1;
        if (!ending1.empty())
        {
            oss << ending1;
        }
        else
        {
            oss << "<EOF>";
        }
        oss << endl;

        oss << "�ļ�2 : ";
        string display2 = replace_special_chars(content2);
        oss << display2;
        if (!ending2.empty()) 
        {
            oss << ending2;
        }
        else 
        {
            oss << "<EOF>";
        }
        oss << endl;

        oss << "�ļ�1(HEX) :" << endl;
        oss << setw(8) << setfill('0') << dec << 0 << " : ";
        if (line1.empty()) 
        {
            oss << hex << setw(2) << setfill('0') << 0x1a; // EOF��HEX��ʾ
        }
        else 
        {
            oss << to_hex_string(line1, 0);
        }
        oss << endl;

        oss << "�ļ�2(HEX) :" << endl;
        oss << setw(8) << setfill('0') << dec << 0 << " : ";
        if (line2.empty()) 
        {
            oss << hex << setw(2) << setfill('0') << 0x0d << " "
                << hex << setw(2) << setfill('0') << 0x0a; // CRLF��HEX��ʾ
        }
        else 
        {
            oss << to_hex_string(line2, 0);
        }
        oss << endl;
    }

    return oss.str();
}


void txt_compare::process_file(const string& filename, string*& lines, int& line_count, int& actual_line_count)
{
    ifstream file(filename.c_str(), ios::binary); // �Զ����Ʒ�ʽ��
    if (!file.is_open())
    {
        ostringstream oss;
        oss << "�޷����ļ�: " << filename << endl;
        result_msg = oss.str();
        return;
    }

    string* temp_lines = new string[10001];
    int count = 0;

    // ���ַ���ȡ�ļ�
    while (count < 10000 && file.good()) 
    {
        string line;
        char c;
        bool got_line = false;

        while (file.get(c))
        {
            if (c == '\r') 
            {
                if (file.peek() == '\n') 
                {
                    file.get(); 
                    line += "\r\n"; 
                }
                else
                {
                    line += "\r"; 
                }
                got_line = true;
                break;
            }
            else if (c == '\n')
            {
                line += "\n";
                got_line = true;
                break;
            }
            else
            {
                line += c;
            }
        }

        if (!got_line && !line.empty())
        {
        }

        if (file.eof() && line.empty() && !got_line) 
        {
            break;
        }

        if (!file.fail() || got_line || !line.empty()) 
        {
            temp_lines[count++] = line;
        }

        if (file.eof())
        {
            break;
        }
    }

    // Ӧ��trim
    for (int i = 0; i < count; i++)
    {
        temp_lines[i] = trim_string(temp_lines[i], trim_type);
    }

    // Ӧ��ignore_blank
    if (ignore_blank)
    {
        string* filtered = new string[10001];
        int filtered_count = 0;
        for (int i = 0; i < count; i++)
        {
            if (!is_blank_line(temp_lines[i]))
            {
                filtered[filtered_count++] = temp_lines[i];
            }
        }
        delete[] temp_lines;
        temp_lines = filtered;
        count = filtered_count;
    }

    // Ӧ��line_skip
    int start_idx = (line_skip < count) ? line_skip : count;

    lines = new string[10001];
    line_count = 0;
    actual_line_count = count;

    // ���������������
    int max_lines_to_process = line_max_linenum;
    if (max_lines_to_process <= 0 || max_lines_to_process > 10000)
    {
        max_lines_to_process = 10000;
    }

    for (int i = start_idx; i < count && line_count < max_lines_to_process; i++)
    {
        lines[line_count] = temp_lines[i];
        line_count++;
    }

    delete[] temp_lines;
}

void txt_compare::compare()
{
    ostringstream oss;

    //���������ļ�
    string* lines1 = nullptr;
    string* lines2 = nullptr;
    int count1 = 0, count2 = 0;
    int actual_count1 = 0, actual_count2 = 0;

    process_file(filename1, lines1, count1, actual_count1);
    process_file(filename2, lines2, count2, actual_count2);

    if (!result_msg.empty())
    {
        if (lines1) delete[] lines1;
        if (lines2) delete[] lines2;
        return;
    }

    //����line_maxlen
    for (int i = 0; i < count1; i++) 
    {
        int len = static_cast<int>(lines1[i].length());
        if (len > line_maxlen)
        {
            line_maxlen = len;
        }
    }
    for (int i = 0; i < count2; i++) 
    {
        int len = static_cast<int>(lines2[i].length());
        if (len > line_maxlen) 
        {
            line_maxlen = len;
        }
    }

    int max_compare = min(count1, count2);
    if (line_max_linenum > 0)
    {
        max_compare = min(max_compare, line_max_linenum);
    }

    diff_count = 0;
    files_match = true;

    for (int i = 0; i < max_compare; i++) 
    {
        if (line_max_diffnum > 0 && diff_count >= line_max_diffnum) 
        {
            break;
        }

        // Ӧ��line_offset
        int idx1 = i;
        int idx2 = i;

        if (line_offset < 0)
        {
            idx1 = i - line_offset; 
            if (idx1 >= count1) 
            {
                break;
            }
        }
        else if (line_offset > 0) 
        {
            idx2 = i - line_offset;
            if (idx2 >= count2) 
            {
                break;
            }
        }

        if (idx1 >= count1 || idx2 >= count2)
        {
            break;
        }

        bool content_diff, ending_diff;
        compare_lines(lines1[idx1], lines2[idx2], idx1 + 1, idx2 + 1,content_diff, ending_diff);

        if (content_diff || ending_diff)
        {
            files_match = false;
            diff_count++;

            if (display_type == "normal" || display_type == "detailed")
            {
                oss << format_difference(lines1[idx1], lines2[idx2],idx1 + 1, idx2 + 1,display_type == "normal");
                oss << endl;
            }
        }
    }

    if (count1 > max_compare || count2 > max_compare) 
    {
        files_match = false;
        if (display_type == "normal" || display_type == "detailed") 
        {
            if (count1 > max_compare) 
            {
                for (int i = max_compare; i < count1; i++)
                {
                    if (line_max_diffnum > 0 && diff_count >= line_max_diffnum)
                    {
                        break;
                    }

                    oss << "��[" << (i + 1) << " / " << max_compare << "]�� - �ļ�1��������" << endl;
                    string display = lines1[i];
                    if (display.empty()) display = "<EMPTY>";
                    else display = replace_special_chars(display);
                    display += get_line_ending_type(lines1[i], true);
                    oss << "�ļ�1��" << display << endl;
                    oss << "�ļ�2��<EOF>" << endl << endl;

                    diff_count++;
                    files_match = false;
                }
            }

            if (count2 > max_compare) 
            {
                for (int i = max_compare; i < count2; i++) 
                {
                    if (line_max_diffnum > 0 && diff_count >= line_max_diffnum) 
                    {
                        break;
                    }

                    oss << "��[" << max_compare << " / " << (i + 1) << "]�� - �ļ�2��������" << endl;
                    oss << "�ļ�1��<EOF>" << endl;
                    string display = lines2[i];
                    if (display.empty()) display = "<EMPTY>";
                    else display = replace_special_chars(display);
                    display += get_line_ending_type(lines2[i], true);
                    oss << "�ļ�2��" << display << endl << endl;

                    diff_count++;
                    files_match = false;
                }
            }
        }
    }

    //����
    if (lines1) delete[] lines1;
    if (lines2) delete[] lines2;

    //�������ս��
    ostringstream final_oss;

    if (display_type == "none" || display_type.empty()) 
    {
        if (files_match) 
        {
            final_oss << "�ļ���ͬ" << endl;
        }
        else 
        {
            final_oss << "�ļ���ͬ" << endl;
        }
    }
    else
    {
        if (files_match) 
        {
            final_oss << "��ָ�������������ȫһ�¡�" << endl;
        }
        else 
        {
            if (display_type == "normal") 
            {
                final_oss << "�ȽϽ����"  << endl;
                final_oss << "========================================" << endl;
            }
            final_oss << oss.str();
            final_oss << "========================================" << endl;
            final_oss << "��ָ����������¹�" << diff_count << "���в��졣" << endl;
        }
    final_oss << "�Ķ���ʾ��" << endl;
    final_oss << "1��ÿ�е��н�������<CR>/<LF>/<CR><LF>/<EOF>���(���㿴���н�����������)" << endl;
    final_oss << "2�����ÿ�н���<CR>/<LF>/<CR><LF>/<EOF>�����ʾ����" << endl;
    final_oss << "3���ļ��������Ϊ<EOF>" << endl;
    final_oss << "4��������ͬ��λ�õĲ����ַ�����ɫ���" << endl;
    final_oss << "5��ÿ���е�CR/LF/VT/BS/BEL��X���(���㿴�������ַ�)" << endl;
    final_oss << "6��ÿ��β�Ķ�����ַ�����ɫ�����VT/BS/BEL����ɫX���(���㿴�������ַ�)" << endl;
    final_oss << "7��������Ϊ�������⣬����λ�ÿ��ܱ��ں��������ϣ����������ֶ���ɫ���" << endl;
    final_oss << "8����--display detailed���Եõ�����ϸ����Ϣ" << endl;
    final_oss << "========================================" << endl;
    final_oss << endl;
    }
   
    result_msg = final_oss.str();
}

void txt_compare::result() const 
{
    cout << result_msg;
}