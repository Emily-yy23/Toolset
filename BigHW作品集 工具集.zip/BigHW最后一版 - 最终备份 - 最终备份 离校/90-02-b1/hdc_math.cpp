/* 2453253 ������ �Ű� */
#include <cmath>
#include "../include/cmd_hdc_tools.h"

void hdc_draw_Mathematical_curve_2453253()
{
    hdc_cls(); // ����

    const int center_x = 400;
    const int center_y = 300;
    const int scale = 150;
    const int n = 5;  // õ�����ߵĲ���

    // ����õ������ r = a * cos(n��)
    for (double angle = 0; angle <= 360; angle += 0.5) 
    {
        double radian = angle * 3.14159 / 180.0;
        double r = scale * cos(n * radian);

        int x = center_x + (int)(r * cos(radian));
        int y = center_y + (int)(r * sin(radian));

        // ���ݽǶ�ѡ��ͬ��ɫ�������ʺ�Ч��
        int color;
        int color_angle = (int)angle % 360;

        if (color_angle < 60)
        {
            color = 0xFF0000; // ��ɫ
        }
        else if (color_angle < 120)
        {
            color = 0xFFFF00; // ��ɫ
        }
        else if (color_angle < 180)
        {
            color = 0x00FF00; // ��ɫ
        }
        else if (color_angle < 240)
        {
            color = 0x00FFFF; // ��ɫ
        }
        else if (color_angle < 300)
        {
            color = 0x0000FF; // ��ɫ
        }
        else 
        {
            color = 0xFF00FF; // ��ɫ
        }

        hdc_point(x, y, 2, color);
    }
}