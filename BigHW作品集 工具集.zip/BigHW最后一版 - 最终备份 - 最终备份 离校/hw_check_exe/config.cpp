/* 2453253 ������ �Ű� */
#include "config.h"
#include <fstream>

using namespace std;

void trim(string& s)
{
    size_t i = 0;
    while (i < s.size() && (s[i] == ' ' || s[i] == '\t'))
        ++i;
    size_t j = s.size();
    while (j > i &&
        (s[j - 1] == ' ' || s[j - 1] == '\t' || s[j - 1] == '\r'))
        --j;
    s = s.substr(i, j - i);
}

string strip_brackets(const string& name)
{
    string s = name;
    trim(s);
    if (s.size() >= 2 && s.front() == '[' && s.back() == ']') 
    {
        s = s.substr(1, s.size() - 2);
        trim(s);
    }
    return s;
}

// ��ȡcfg�ļ�
bool Config::load(const string& filename)
{
    ifstream fin(filename.c_str());
    if (!fin) 
        return false;

    string line;
    CfgGroup* cur = nullptr;

    while (getline(fin, line)) 
    {
        // ȥ��ĩβ \r / \n
        if (!line.empty() &&(line.back() == '\r' || line.back() == '\n'))
            line.pop_back();

        // ȥ����β # ע��
        size_t pos_hash = line.find('#');
        if (pos_hash != string::npos)
        {
            line = line.substr(0, pos_hash);
        }

        trim(line);
        if (line.empty())
            continue;
        if (line[0] == '#')
            continue;

        // [����]
        if (line.front() == '[' && line.back() == ']')
        {
            CfgGroup g;
            g.name = line.substr(1, line.size() - 2);
            trim(g.name);
            groups.push_back(g);
            cur = &groups.back();
            continue;
        }

        if (!cur) 
            continue;

        size_t pos_eq = line.find('=');
        if (pos_eq == string::npos) 
            continue;

        string key = line.substr(0, pos_eq);
        string val = line.substr(pos_eq + 1);
        trim(key);
        trim(val);

        CfgItem it;
        it.key = key;
        it.value = val;
        cur->items.push_back(it);
    }
    return true;
}

const CfgGroup* Config::find_group(const string& name) const
{
    for (size_t i = 0; i < groups.size(); ++i) 
    {
        if (groups[i].name == name)
            return &groups[i];
    }
    return nullptr;
}

string Config::get_value(const CfgGroup& g, const string& key, const string& def) const
{
    for (size_t i = 0; i < g.items.size(); ++i) 
    {
        if (g.items[i].key == key)
            return g.items[i].value;
    }
    return def;
}

bool build_effective_group(const Config& cfg,const string& group_name,CfgGroup& out,int depth)
{
    if (depth > 5) 
    {       // ��ֹ include Ƕ�׹���
        return false;
    }

    const CfgGroup* g = cfg.find_group(group_name);
    if (!g) return false;

    // �ȴ��� include ����
    Config tmp_cfg = cfg;  // ֻΪ��ʹ�� get_value
    string inc_raw = cfg.get_value(*g, "include", "");
    string inc = strip_brackets(inc_raw);

    if (!inc.empty()) 
    {
        if (!build_effective_group(cfg, inc, out, depth + 1))
            return false;
    }

    // ���õ�ǰ�鸲��/���Ӽ�ֵ������ include ������
    for (size_t i = 0; i < g->items.size(); ++i) 
    {
        const CfgItem& it = g->items[i];
        if (it.key == "include")
            continue;

        bool found = false;
        for (size_t j = 0; j < out.items.size(); ++j)
        {
            if (out.items[j].key == it.key) 
            {
                out.items[j].value = it.value; // ����
                found = true;
                break;
            }
        }
        if (!found)
        {
            out.items.push_back(it);
        }
    }
    out.name = group_name;
    return true;
}