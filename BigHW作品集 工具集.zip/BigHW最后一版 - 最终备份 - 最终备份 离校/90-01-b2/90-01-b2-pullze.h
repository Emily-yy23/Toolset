/* 2453253 �Ű� ������ */
#pragma once
#include <iostream>
#include <conio.h>
#include "../include/cmd_console_tools.h"
#include <Windows.h>

const int MAX_SIZE = 15;

struct GameData
{
    int size;                                           // size
    bool board[MAX_SIZE][MAX_SIZE] = { false };           // board by 0
    bool marked[MAX_SIZE][MAX_SIZE] = { false };          // marked by x
    int rowHints[MAX_SIZE][MAX_SIZE];
    int rowMax;                                         // row max hints
    int colHints[MAX_SIZE][MAX_SIZE];
    int colMax;                                         // col max hints
    bool operations[MAX_SIZE][MAX_SIZE] = { false };
};


// tools 
void print_submission_menu();  // menu
void init_game_inner_array(GameData& game, int size);
bool check_answer(GameData& game); // check submission


// submissions
void print_submission_A(GameData& game);
void print_submission_B(GameData& game);
void print_submission_C(GameData& game);
void print_submission_D(GameData& game);
void print_submission_E(GameData& game, bool tooltip);
void print_submission_F(GameData& game);
void print_submission_G(GameData& game);
void print_submission_H(GameData& game);
void print_submission_I(GameData& game);
void print_submission_J(GameData& game);
void print_submission_K(GameData& game);

