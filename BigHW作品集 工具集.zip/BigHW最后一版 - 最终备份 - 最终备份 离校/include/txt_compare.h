/* 2453253 ������ �Ű� */
#ifndef TXT_COMPARE_H
#define TXT_COMPARE_H

#include <string>

class txt_compare 
{
private:
    std::string filename1;
    std::string filename2;
    std::string trim_type;
    std::string display_type;
    int line_skip;
    int line_offset;
    int line_max_diffnum;
    int line_max_linenum;
    bool ignore_blank;
    bool not_ignore_linefeed;  
    bool debug;

    // �ڲ�״̬
    std::string result_msg;
    bool files_match;
    int diff_count;
    int line_maxlen;

    // ��������
    std::string trim_string(const std::string& str, const std::string& trim_type);
    bool is_blank_line(const std::string& line);
    std::string get_line_ending_type(const std::string& line, bool include_eof = false);
    std::string replace_special_chars(const std::string& str);
    std::string to_hex_string(const std::string& str, int start_pos = 0);
    std::string format_difference(const std::string& line1, const std::string& line2,int line_num1, int line_num2, bool is_normal);
    void compare_lines(const std::string& line1, const std::string& line2,int line_num1, int line_num2, bool& content_diff, bool& ending_diff);
    void process_file(const std::string& filename,std::string*& lines, int& line_count, int& actual_line_count);
    void print_ruler(std::ostream& oss, int max_len, bool is_detailed);

public:
    txt_compare(const std::string& f1, const std::string& f2,const std::string& trim, const std::string& display,int skip, int offset, int max_diff, int max_line,bool ignore_bl, bool notignore_lf, bool dbg); 
    void compare();
    void result() const;
};

#endif 