/* 2453253 ������ �Ű� */
#include "checker.h"
#include "../include/check_exe.h"
#include "student.h"
#include "config.h"
#include <iostream>
#include "db.h"
#include <iomanip>  //setw, left
#include <io.h>    //_access
#include <chrono>
#include <ctime>
#include <sstream>
#include <fstream>


using namespace std;

// ���ߣ��ж�·���Ƿ����
static bool path_exists(const string& path)
{
    if (path.empty()) 
        return false;
    return _access(path.c_str(), 0) == 0;
}

// ����Options���debug�ȼ������־
static void dbg_log(const Options& opt, DebugLevel lvl, const std::string& msg)
{
    // �����ǰ�ȼ���������ȼ����Ͳ����
    if (!is_debug_enabled(opt, lvl)) 
        return;

    //warn �������� cerr�������� cout
    std::ostream& os = (lvl <= DebugLevel::WARN) ? std::cerr : std::cout;

    os << "[" << debug_level_name(lvl) << "] " << msg << "\n";
}

// ��ӡ [���ݿ�] ���������Ϣ
static void print_database_cfg(const Config& cfg)
{
    const CfgGroup* db = cfg.find_group("���ݿ�");
    if (!db) 
        return;

    auto print_kv = [](const std::string& key, const std::string& val) 
        {
        std::cout << "  " << std::left << std::setw(28) << key<< " = " << val << "\n";
        };

    std::cout << "[���ݿ�]��" << "\n";
    print_kv("db_host", cfg.get_value(*db, "db_host", ""));
    print_kv("db_port", cfg.get_value(*db, "db_port", ""));
    print_kv("db_name", cfg.get_value(*db, "db_name", ""));
    print_kv("db_username", cfg.get_value(*db, "db_username", ""));
    print_kv("db_curr_term", cfg.get_value(*db, "db_curr_term", ""));
    print_kv("db_cno_list", cfg.get_value(*db, "db_cno_list", ""));
    std::cout << "\n";
}

// ��ʱ����ʽ��Ϊ "YYYY-MM-DD HH:MM:SS"
static std::string format_time(const std::chrono::system_clock::time_point& tp)
{
    using namespace std::chrono;

    // �� time_point ת�� time_t���뼶��
    std::time_t tt = system_clock::to_time_t(tp);

    // �ٰ� time_t ת�ɱ���ʱ��� tm �ṹ
    std::tm tm{};
    localtime_s(&tm, &tt);   

    // ��ʽ�������������
    char buf[32] = { 0 };
    std::strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &tm);

    return std::string(buf);
}

static bool is_valid_exe_style(const string& s)
{
    return s == "none" || s == "single" || s == "multi";
}

static bool is_valid_cmd_style(const string& s)
{
    return s == "normal" || s == "pipe" ||s == "redirection" || s == "main_with_arguments";
}

// ��·����ȡ�ļ���
static string get_file_name(const string& path)
{
    size_t pos = path.find_last_of("\\/");
    if (pos == string::npos) 
        return path;
    return path.substr(pos + 1);
}

// ����checkname
// ������·�����÷�б��ƴ�������м��Զ���һ�� '\'
static std::string join_path(const std::string& a, const std::string& b)
{
    if (a.empty()) 
        return b;
    if (b.empty()) 
        return a;
    if (a.back() == '\\' || a.back() == '/')
        return a + b;
    else
        return a + "\\" + b;
}

// ���� cfg �� multi/single ������ѧ�� exe ������·��
static std::string build_student_exe_path(const Config& cfg, const CfgGroup& eff,const Student& stu)
{
    std::string exe_style = cfg.get_value(eff, "exe_style", "none");
    std::string exe_name = cfg.get_value(eff, "stu_exe_name", "");
    std::string single_dir = cfg.get_value(eff, "single_exe_dirname", "");
    std::string multi_root = cfg.get_value(eff, "multi_exe_main_dirname", "");
    std::string multi_sub = cfg.get_value(eff, "multi_exe_sub_dirname", "");

    trim(single_dir);
    trim(multi_root);
    trim(multi_sub);
    trim(exe_name);

    if (exe_style == "single") {
        // single ģʽ
        std::string fname = stu.sno + "-" + stu.cno + "-" + exe_name;
        return join_path(single_dir, fname);
    }
    else if (exe_style == "multi") 
    {
        // multi ģʽ��D:\25261-term\allfile\ѧ��-�κ�\vs-exec\3-b3-2.cpp.vs.x86.debug.exe
        std::string stu_dir = stu.sno + "-" + stu.cno;
        std::string path = join_path(multi_root, stu_dir);
        path = join_path(path, multi_sub);
        path = join_path(path, exe_name);
        return path;
    }
    else 
    {
        return ""; // exe_style = none ʱ������ѧ��
    }
}

//---------------- check_only ----------------

// �ڲ�ʵ�֣���֪չ����� eff��with_db_extra �����Ƿ���� [���ݿ�] ��
static void print_group_cfg_inner(const Config& cfg,const CfgGroup& eff, const std::string& group_name,bool with_db_extra)
{
    std::string sep(100, '=');

    std::cout << sep << "\n";
    std::cout << "[" << group_name << "]������Ϣ���£�" << "\n";
    std::cout << sep << "\n";

    // �����Ҫ���Ȳ��� [���ݿ�] �飨ֻ�� name_list/exe_style �йأ�
    if (with_db_extra)
    {
        print_database_cfg(cfg);
    }

    std::cout << "[" << group_name << "]��" << "\n";

    auto print_kv = [](const std::string& key, const std::string& value)
        {
        std::cout << "  " << std::left << std::setw(28) << key<< " = " << value << "\n";
        };

    // �����ֶ�
    std::string exe_style = cfg.get_value(eff, "exe_style", "none");
    std::string name_list = cfg.get_value(eff, "name_list", "");

    std::string demo_exe = cfg.get_value(eff, "demo_exe_name", "");
    std::string cmd_style = cfg.get_value(eff, "cmd_style", "normal");
    std::string max_out = cfg.get_value(eff, "max_output_len", "0");
    std::string timeout = cfg.get_value(eff, "timeout", "0");
    std::string pipe_get = cfg.get_value(eff, "pipe_get_input_data_exe_name", "");
    std::string pipe_file = cfg.get_value(eff, "pipe_data_file", "");
    std::string redir_dir = cfg.get_value(eff, "redirection_data_dirname", "");

    // exe_style һ����ӡ
    print_kv("exe_style", exe_style);

    // ֻҪ�� single/multi���ʹ�ӡ name_list
    if (exe_style == "single" || exe_style == "multi") 
    {
        if (!name_list.empty())
            print_kv("name_list", name_list);
    }

    // single/multi �ֱ��ӡ����·������ֶ�
    if (exe_style == "multi") 
    {
        std::string mmain = cfg.get_value(eff, "multi_exe_main_dirname", "");
        std::string msub = cfg.get_value(eff, "multi_exe_sub_dirname", "");
        if (!mmain.empty())
            print_kv("multi_exe_main_dirname", mmain);
        if (!msub.empty())
            print_kv("multi_exe_sub_dirname", msub);
        std::string stu_exe = cfg.get_value(eff, "stu_exe_name", "");
        if (!stu_exe.empty())
            print_kv("stu_exe_name", stu_exe);
    }
    else if (exe_style == "single")
    {
        std::string sdir = cfg.get_value(eff, "single_exe_dirname", "");
        if (!sdir.empty())
            print_kv("single_exe_dirname", sdir);
        std::string stu_exe = cfg.get_value(eff, "stu_exe_name", "");
        if (!stu_exe.empty())
            print_kv("stu_exe_name", stu_exe);
    }

    // ����ԭ���߼�
    print_kv("demo_exe_name", demo_exe);
    print_kv("cmd_style", cmd_style);
    print_kv("max_output_len", max_out);
    print_kv("timeout", timeout);

    if (cmd_style == "pipe") 
    {
        print_kv("pipe_get_input_data_exe_name", pipe_get);
        print_kv("pipe_data_file", pipe_file);
    }
    else if (cmd_style == "redirection") 
    {
        print_kv("redirection_data_dirname", redir_dir);
    }

    std::cout << "\n";

    print_kv("tc_trim", cfg.get_value(eff, "tc_trim", "right"));
    print_kv("tc_lineskip", cfg.get_value(eff, "tc_lineskip", "0"));
    print_kv("tc_lineoffset", cfg.get_value(eff, "tc_lineoffset", "0"));
    print_kv("tc_ignoreblank", cfg.get_value(eff, "tc_ignoreblank", "0"));
    print_kv("tc_not_ignore_linefeed", cfg.get_value(eff, "tc_not_ignore_linefeed", "0"));
    print_kv("tc_maxdiff", cfg.get_value(eff, "tc_maxdiff", "0"));
    print_kv("tc_maxline", cfg.get_value(eff, "tc_maxline", "0"));
    print_kv("tc_display", cfg.get_value(eff, "tc_display", "none"));

    std::cout << "\n";

    int items_num = std::stoi(cfg.get_value(eff, "items_num", "0"));
    int items_begin = std::stoi(cfg.get_value(eff, "items_begin", "1"));
    int items_end = std::stoi(cfg.get_value(eff, "items_end", "1"));

    print_kv("items_num", std::to_string(items_num));
    print_kv("items_begin", std::to_string(items_begin));
    print_kv("items_end", std::to_string(items_end));

    for (int i = 1; i <= items_num; ++i) 
    {
        std::string key = "item_name_" + std::to_string(i);
        std::string val;

        if (cmd_style == "pipe")
        {
            std::string gkey = "item_gname_" + std::to_string(i);
            std::string gname = cfg.get_value(eff, gkey, "");
            gname = strip_brackets(gname);
            if (!gname.empty())
                val = "[" + gname + "]";
        }
        else if (cmd_style == "redirection")
        {
            std::string fkey = "item_fname_" + std::to_string(i);
            val = cfg.get_value(eff, fkey, "");
        }
        else if (cmd_style == "main_with_arguments") 
        {
            std::string akey = "item_args_" + std::to_string(i);
            val = cfg.get_value(eff, akey, "");
        }
        else 
        {
            val = "";
        }

        print_kv(key, val);
    }

    std::cout << sep << "\n";
}

// ����ӿڣ�Ĭ�ϲ������ݿ��
static void print_group_cfg(const Config& cfg, const std::string& group_name, bool with_db_extra = false)
{
    CfgGroup eff;
    eff.items.clear();
    if (!build_effective_group(cfg, group_name, eff, 0))
    {
        std::cout << "�����޷����������� [" << group_name << "]\n";
        return;
    }
    print_group_cfg_inner(cfg, eff, group_name, with_db_extra);
}

int do_check_only(const Config& cfg, const Options& opt)
{
    dbg_log(opt, DebugLevel::INFO, "checkcfg_only: group = " + opt.checkname);

    CfgGroup eff;
    eff.items.clear();

    if (!build_effective_group(cfg, opt.checkname, eff, 0))
    {
        dbg_log(opt, DebugLevel::WARN, "build_effective_group ʧ��, �鲻���ڻ� include ����");
        std::cout << "�����޷����������� [" << opt.checkname << "]\n";
        return 1;
    }

    dbg_log(opt, DebugLevel::DEBUG, "��Ч�����鹹�����, item �� = " + std::to_string(eff.items.size()));

    std::cout << "" << std::endl;

    // 1) �ռ� include ��
    std::vector<std::string> chain;
    std::string cur = opt.checkname;
    while (true)
    {
        const CfgGroup* g = cfg.find_group(cur);
        if (!g) 
            break;
        std::string inc_raw = cfg.get_value(*g, "include", "");
        std::string inc = strip_brackets(inc_raw);
        if (inc.empty()) 
            break;
        chain.push_back(inc);
        cur = inc;
    }

    // 2) �ȴ�ӡ include ���ϵĸ��飨���������ݿ�飩
    for (int i = (int)chain.size() - 1; i >= 0; --i) 
    {
        print_group_cfg(cfg, chain[i], false);
        std::cout << std::endl << std::endl;
    }

    // 3) ��ǰ�飺�Ƿ���Ҫ [���ݿ�] ���� exe_style/name_list ����
    std::string exe_style = cfg.get_value(eff, "exe_style", "none");
    std::string name_list = cfg.get_value(eff, "name_list", "");

    bool with_db_extra = (exe_style != "none" && name_list == "database");
    print_group_cfg(cfg, opt.checkname, with_db_extra);

    std::cout << "" << std::endl;
    dbg_log(opt, DebugLevel::INFO,"checkcfg_only finished, group = " + opt.checkname);
    return 0;
}

int run_demo(const Config& cfg, const Options& opt)
{
    CfgGroup eff;
    eff.items.clear();
    if (!build_effective_group(cfg, opt.checkname, eff, 0)) 
    {
        dbg_log(opt, DebugLevel::WARN, "run_demo: ����������ʧ��, group=" + opt.checkname);
        std::cout << "�޷����������� [" << opt.checkname << "]\n";
        return 1;
    }

    std::string demo_exe = cfg.get_value(eff, "demo_exe_name");
    std::string cmd_style = cfg.get_value(eff, "cmd_style");
    std::string pipe_get = cfg.get_value(eff, "pipe_get_input_data_exe_name");
    std::string pipe_file = cfg.get_value(eff, "pipe_data_file");
    std::string redir_dir = cfg.get_value(eff, "redirection_data_dirname");

    int timeout = std::stoi(cfg.get_value(eff, "timeout", "3"));
    int max_output_len = std::stoi(cfg.get_value(eff, "max_output_len", "256"));
    int items_begin = std::stoi(cfg.get_value(eff, "items_begin", "1"));
    int items_end = std::stoi(cfg.get_value(eff, "items_end", "1"));
    if (items_begin < 1) 
        items_begin = 1;
    if (items_end < items_begin) 
        items_end = items_begin;

    dbg_log(opt, DebugLevel::INFO,"run_demo: group=" + opt.checkname +", exe=" + demo_exe + ", cmd_style=" + cmd_style +", items=" + std::to_string(items_begin) + "-" + std::to_string(items_end));

    auto t_begin = std::chrono::system_clock::now();

    int ok_cnt = 0;
    int total = items_end - items_begin + 1;
    std::string exe_name = get_file_name(demo_exe);

    for (int item_index = items_begin; item_index <= items_end; ++item_index)
    {
        std::string full_cmd;

        if (cmd_style == "pipe")
        {
            std::string key_g = "item_gname_" + std::to_string(item_index);
            std::string gname = cfg.get_value(eff, key_g);
            full_cmd = pipe_get + " " + pipe_file + " [" + gname + "] | " + demo_exe;
        }
        else if (cmd_style == "redirection") 
        {
            std::string key_f = "item_fname_" + std::to_string(item_index);
            std::string fname = cfg.get_value(eff, key_f);
            full_cmd = demo_exe + " < " + redir_dir + "\\" + fname;
        }
        else if (cmd_style == "main_with_arguments") 
        {
            std::string key_a = "item_args_" + std::to_string(item_index);
            std::string args = cfg.get_value(eff, key_a, "");
            trim(args);
            full_cmd = args.empty() ? demo_exe : demo_exe + " " + args;
        }
        else 
        {
            full_cmd = demo_exe;
        }

        dbg_log(opt, DebugLevel::DEBUG,"run_demo case " + std::to_string(item_index) + " cmd: " + full_cmd);

        st_CheckExec runner(full_cmd, exe_name, max_output_len, timeout);
        runner.running();

        if (runner.get_errno() == CheckExec_Errno::ok) 
        {
            ++ok_cnt;
        }
        else
        {
            dbg_log(opt, DebugLevel::WARN,"run_demo case " + std::to_string(item_index) +" errno=" + std::to_string((int)runner.get_errno()));
        }
    }

    auto t_end = std::chrono::system_clock::now();
    std::string sep(70, '=');

    dbg_log(opt, DebugLevel::INFO, "run_demo finished: ok=" + std::to_string(ok_cnt) +"/" + std::to_string(total));

    std::cout << format_time(t_end) << " �ο����������\n";
    std::cout << sep << "\n";
    std::cout << "�ο�exe�ļ���" << demo_exe << "\n";
    std::cout << "���������������ȷ����=" << ok_cnt << "\n";
    std::cout << "ʱ�䣺" << format_time(t_begin) << " - " << format_time(t_end) << "\n";
    std::cout << sep << "\n\n";

    return 0;
}


int collect_demo_outputs(const Config& cfg,const Options& opt,std::vector<std::string>& std_outs,std::vector<CheckExec_Errno>& std_status)
{
    CfgGroup eff;
    eff.items.clear();
    if (!build_effective_group(cfg, opt.checkname, eff, 0)) 
    {
        std::cout << "�޷����������� [" << opt.checkname << "]\n";
        return 1;
    }

    std::string demo_exe = cfg.get_value(eff, "demo_exe_name");
    std::string cmd_style = cfg.get_value(eff, "cmd_style");
    std::string pipe_get = cfg.get_value(eff, "pipe_get_input_data_exe_name");
    std::string pipe_file = cfg.get_value(eff, "pipe_data_file");
    std::string redir_dir = cfg.get_value(eff, "redirection_data_dirname");

    int timeout = std::stoi(cfg.get_value(eff, "timeout", "3"));
    int max_output_len = std::stoi(cfg.get_value(eff, "max_output_len", "256"));

    int items_begin = std::stoi(cfg.get_value(eff, "items_begin", "1"));
    int items_end = std::stoi(cfg.get_value(eff, "items_end", "1"));
    if (items_begin < 1) 
        items_begin = 1;
    if (items_end < items_begin)
        items_end = items_begin;

    std::string exe_name = get_file_name(demo_exe);

    int item_count = items_end - items_begin + 1;
    std_outs.assign(item_count, std::string());
    std_status.assign(item_count, CheckExec_Errno::ok);

    for (int item_index = items_begin; item_index <= items_end; ++item_index)
    {
        std::string full_cmd;

        if (cmd_style == "pipe") 
        {
            std::string key_g = "item_gname_" + std::to_string(item_index);
            std::string gname = cfg.get_value(eff, key_g);
            full_cmd = pipe_get + " " + pipe_file + " [" + gname + "] | " + demo_exe;

        }
        else if (cmd_style == "redirection") 
        {
            std::string key_f = "item_fname_" + std::to_string(item_index);
            std::string fname = cfg.get_value(eff, key_f);
            full_cmd = demo_exe + " < " + redir_dir + "\\" + fname;

        }
        else if (cmd_style == "main_with_arguments") 
        {
            std::string key_a = "item_args_" + std::to_string(item_index);
            std::string args = cfg.get_value(eff, key_a, "");
            trim(args);
            if (args.empty())
                full_cmd = demo_exe;
            else
                full_cmd = demo_exe + " " + args;

        }
        else 
        { // normal
            full_cmd = demo_exe;
        }

        int idx = item_index - items_begin;

        st_CheckExec runner(full_cmd, exe_name, max_output_len, timeout);
        runner.running();

        std_status[idx] = runner.get_errno();
        if (runner.get_errno() == CheckExec_Errno::ok)
        {
            std_outs[idx] = runner.msg.str();   // �����׼���
        }
        else {
            std_outs[idx].clear();              
        }
    }

    return 0;
}


// ���ݿ�

// ��ӡһ��ѧ���Ľ����
static void print_student_result(size_t seq,
    const Student& stu,
    const std::string& exe_name,   // ���� "3-b3-2.cpp.vs.x86.debug.exe"
    bool          exe_exists,
    int           run_ok_count,    // �����������
    const std::string& bit_str,    // ������ȷ�ԣ�111...
    int           tc_ok_count,     // tc��ȷ����
    const std::chrono::system_clock::time_point& t_begin,
    const std::chrono::system_clock::time_point& t_end)
{
    std::string sep(70, '=');  // "======================================================================"

    // ��һ�У�ʱ�� + ѧ�����������
    std::cout << format_time(t_end) << " ѧ�����������\n";
    std::cout << sep << "\n";

    // �ڶ��У���� / ѧ�� / ���� / �κ�
    std::cout << "��ţ�" << seq<< " ѧ�ţ�" << stu.sno<< " / ������" << stu.sname<< " / �κţ� " << stu.cno << "\n";

    if (!exe_exists)
    {
        // exe �����ڵ������ֻ��ӡһ�� EXE�ļ���xxx������
        std::cout << "EXE�ļ���" << exe_name << "������\n";
        std::cout << sep << "\n\n";
        return;
    }

    // exe ���ڲ��Ѿ����ȫ�����Ե����
    std::cout << "���������������ȷ����=" << run_ok_count << "\n";
    std::cout << "������ȷ�ԣ�" << bit_str << "\n";
    std::cout << "tc��ȷ������" << tc_ok_count << "\n";
    std::cout << "ʱ�䣺" << format_time(t_begin) << " - " << format_time(t_end) << "\n";
    std::cout << sep << "\n\n";
}


// �Ҳ� trim��ȥ��ĩβ�ո�Tab��\r
static void trim_right(std::string& s)
{
    while (!s.empty() &&
        (s.back() == ' ' || s.back() == '\t' || s.back() == '\r'))
        s.pop_back();
}

// �ı��ȽϺ�����
// ����ֵ = ��ͬ��������0 ��ʾ��ȫһ�£��� trim right ֮��
static int txt_compare(const std::string& std_out, const std::string& stu_out)
{
    std::istringstream sa(std_out);
    std::istringstream sb(stu_out);

    std::string la, lb;
    int diff = 0;

    while (true)
    {
        bool ra = static_cast<bool>(std::getline(sa, la));
        bool rb = static_cast<bool>(std::getline(sb, lb));

        if (!ra && !rb) break;      // ���߶����� -> ����

        // ��ÿһ���� trim right
        if (ra) trim_right(la);
        if (rb) trim_right(lb);

        // ������ͬ �� �����ݲ�ͬ������һ�в���
        if (ra != rb || la != lb)
        {
            ++diff;
        }
    }
    return diff;
}

// �����ļ���/��ͷ��ʱ�䴮 "YYYY-MM-DD-HH-MM-SS"
static std::string format_time_filename(const std::chrono::system_clock::time_point& tp)
{
    using namespace std::chrono;
    std::time_t tt = system_clock::to_time_t(tp);
    std::tm tm{};
    localtime_s(&tm, &tt);

    char buf[32] = { 0 };
    std::strftime(buf, sizeof(buf), "%Y-%m-%d-%H-%M-%S", &tm);
    return std::string(buf);
}

// ���� xls����ʵ�� tab �ָ� txt��
static int save_result_xls(const Config& cfg,const CfgGroup& eff, const Options& opt, const std::vector<std::string>& item_names, const std::vector<StudentResult>& results,const std::chrono::system_clock::time_point& start_time_all)
{
    std::string exe_style = cfg.get_value(eff, "exe_style", "none");
    std::string cmd_style = cfg.get_value(eff, "cmd_style", "normal");
    std::string name_list = cfg.get_value(eff, "name_list", "");
    std::string stu_exe = cfg.get_value(eff, "stu_exe_name", "");

    std::string time_str = format_time_filename(start_time_all);
    const std::string MY_STUDENT_ID = "2453253";
    // �ļ�����check-result-ѧ��-ʱ��-exe_style-cmd_style-namelist-exe�ļ���.xls
    std::string filename = "check-result-" + MY_STUDENT_ID + "-" +time_str + "-" +exe_style + "-" + cmd_style + "-" + name_list + "-" +stu_exe + ".xls";

    std::ofstream fout(filename.c_str());
    if (!fout) 
    {
        std::cout << "�޷���������ļ�: " << filename << "\n";
        return 1;
    }

    // ��ͷ��ǰ���У�
    fout << "exe_style\t" << exe_style << "\n";
    fout << "cmd_style\t" << cmd_style << "\n";
    fout << "name_list\t" << name_list << "\n";
    fout << "stu_exe_name\t" << stu_exe << "\n";
    fout << "start_time\t" << time_str << "\n";
    fout << "\n";

    // �б�����
    fout << "���\t�κ�\tѧ��\t����\t"<< "��ȷ����\t��ʱ������ʧ��\t�ܵ���ʽ��ʧ��\t������ʱ��ʧ��\t��ʱ\t�����������\t��ѭ��\tTCͨ������";

    for (size_t i = 0; i < item_names.size(); ++i)
    {
        fout << "\t" << item_names[i];   // ���� [3-b3-01]
    }
    fout << "\n";

    // ������
    for (size_t i = 0; i < results.size(); ++i)
    {
        const StudentResult& r = results[i];

        fout << r.seq << '\t'<< r.cno << '\t' << r.sno << '\t'<< r.sname << '\t';

        // ��ȷ���� / ������� / tcͨ������
        if (!r.exe_exists) 
        {
            // exe �����ڣ�
            // ǰ 7 ���ȷ���� + 6 ������� "/"����ʾδ���ԣ�
            // ���һ�� TCͨ������ ���������֣�����ͳһд 0��
            fout << "/\t"  // ��ȷ����
                << "/\t"  // ��ʱ������ʧ��
                << "/\t"  // �ܵ���ʽ��ʧ��
                << "/\t"  // ������ʱ��ʧ��
                << "/\t"  // ��ʱ
                << "/\t"  // �����������
                << "/\t"  // ��ѭ��
                << 0 << "\t"; // TCͨ������=0
        }
        else 
        {
            //  exe ���ڣ�ȫ��д�������֣����� 0��
            fout << r.ok_count << "\t"<< r.create_timer_failed << "\t"<< r.popen_failed << "\t"<< r.start_timer_failed << "\t"  << r.timeout << "\t"<< r.max_output << "\t" << r.killed_by_callback << "\t" << r.tc_ok_total << "\t";
        }

        // ÿ�����Ե�һ��
        for (size_t j = 0; j < r.tc_ok_each.size(); ++j)
        {
            fout << r.tc_ok_each[j];
            if (j + 1 < r.tc_ok_each.size())
                fout << '\t';
        }
        fout << "\n";
    }

    fout.close();
    using Clock = std::chrono::system_clock;
    //ʱ�� + �ո� + "������ļ� [�ļ���]������"
    std::cout << format_time(Clock::now())<< " ������ļ� [" << filename << "]������\n";
    return 0;
}
int run_students(const Config& cfg, const Options& opt)
{
    // 1) ������Ч�� eff
    CfgGroup eff;
    eff.items.clear();
    if (!build_effective_group(cfg, opt.checkname, eff, 0)) 
    {
        std::cout << "�޷����������� [" << opt.checkname << "]\n";
        return 1;
    }

    // 2) ֻ֧�� name_list = database
    std::string namelist = cfg.get_value(eff, "name_list", "");
    if (namelist != "database")
    {
        dbg_log(opt, DebugLevel::WARN,"run_students: name_list != database, ʵ��Ϊ " + namelist);
        std::cout << "��ǰ���� name_list ���� database��run_students ��ֻ֧�� database\n";
        return 1;
    }

    // 3) �����ݿ�ȡѧ������
    DbConfig dbc;
    if (!load_db_config(cfg, dbc)) 
    {
        dbg_log(opt, DebugLevel::WARN, "run_students: ��ȡ[���ݿ�]����ʧ��");
        std::cout << "��ȡ[���ݿ�]����ʧ��\n";
        return 1;
    }

    std::vector<Student> students;
    if (!fetch_students_from_db(dbc, students))
    {
        dbg_log(opt, DebugLevel::WARN, "run_students: �����ݿ�ȡѧ������ʧ��");
        std::cout << "�����ݿ�ȡѧ������ʧ��\n";
        return 1;
    }

    dbg_log(opt, DebugLevel::INFO,"run_students: group=" + opt.checkname +", students=" + std::to_string(students.size()));

    // 4) ���ռ�һ�Ρ��ο��𰸡������
    std::vector<std::string> std_outs;
    std::vector<CheckExec_Errno> std_status;
    int ret = collect_demo_outputs(cfg, opt, std_outs, std_status);
    if (ret != 0) 
    {
        dbg_log(opt, DebugLevel::WARN, "run_students: ���ɲο���ʧ��");
        std::cout << "���ɲο���ʧ��\n";
        return ret;
    }

    std::string cmd_style = cfg.get_value(eff, "cmd_style", "normal");
    int timeout = std::stoi(cfg.get_value(eff, "timeout", "3"));
    int max_output_len = std::stoi(cfg.get_value(eff, "max_output_len", "256"));
    int items_begin = std::stoi(cfg.get_value(eff, "items_begin", "1"));
    int items_end = std::stoi(cfg.get_value(eff, "items_end", "1"));
    if (items_begin < 1)
        items_begin = 1;
    if (items_end < items_begin) 
        items_end = items_begin;
    int items_num = items_end - items_begin + 1;

    std::string pipe_get = cfg.get_value(eff, "pipe_get_input_data_exe_name", "");
    std::string pipe_file = cfg.get_value(eff, "pipe_data_file", "");
    std::string redir_dir = cfg.get_value(eff, "redirection_data_dirname", "");
    std::string exe_name = cfg.get_value(eff, "stu_exe_name", "");
    trim(exe_name);

    // 5) ׼��ÿ�����Ե������������ xls��
    std::vector<std::string> item_names;
    item_names.reserve(items_num);
    for (int item_index = items_begin; item_index <= items_end; ++item_index) 
    {
        if (cmd_style == "pipe") 
        {
            std::string key = "item_gname_" + std::to_string(item_index);
            std::string gname = cfg.get_value(eff, key, "");
            gname = strip_brackets(gname);
            if (!gname.empty()) 
                gname = "[" + gname + "]";
            item_names.push_back(gname);
        }
        else if (cmd_style == "redirection") 
        {
            std::string key = "item_fname_" + std::to_string(item_index);
            item_names.push_back(cfg.get_value(eff, key, ""));
        }
        else 
        {
            item_names.push_back("item_" + std::to_string(item_index));
        }
    }

    using Clock = std::chrono::system_clock;
    auto start_time_all = Clock::now();

    // 6) ��ÿ��ѧ�����Բ��ռ����
    std::vector<StudentResult> results;
    results.reserve(students.size());

    for (size_t i = 0; i < students.size(); ++i)
    {
        const Student& stu = students[i];

        StudentResult sr;
        sr.seq = static_cast<int>(i + 1);
        sr.cno = stu.cno;
        sr.sno = stu.sno;
        sr.sname = stu.sname;

        sr.ok_count = 0;
        sr.create_timer_failed = 0;
        sr.popen_failed = 0;
        sr.start_timer_failed = 0;
        sr.timeout = 0;
        sr.max_output = 0;
        sr.killed_by_callback = 0;
        sr.tc_ok_total = 0;
        sr.tc_ok_each.assign(items_num, 0);

        std::string exe_path = build_student_exe_path(cfg, eff, stu);
        bool exe_exists = path_exists(exe_path);
        sr.exe_exists = exe_exists;  

        auto t_begin = Clock::now();

        if (exe_exists) 
        {
            for (int item_index = items_begin; item_index <= items_end; ++item_index) 
            {
                int idx = item_index - items_begin;

                // ����������
                std::string full_cmd;
                if (cmd_style == "pipe") 
                {
                    std::string key_g = "item_gname_" + std::to_string(item_index);
                    std::string gname = cfg.get_value(eff, key_g);
                    full_cmd = pipe_get + " " + pipe_file + " [" + gname + "] | " + exe_path;
                }
                else if (cmd_style == "redirection") 
                {
                    std::string key_f = "item_fname_" + std::to_string(item_index);
                    std::string fname = cfg.get_value(eff, key_f);
                    full_cmd = exe_path + " < " + redir_dir + "\\" + fname;
                }
                else if (cmd_style == "main_with_arguments") 
                {
                    std::string key_a = "item_args_" + std::to_string(item_index);
                    std::string args = cfg.get_value(eff, key_a, "");
                    trim(args);
                    full_cmd = args.empty() ? exe_path : exe_path + " " + args;
                }
                else
                { // normal
                    full_cmd = exe_path;
                }

                st_CheckExec runner(full_cmd, exe_name, max_output_len, timeout);
                runner.running();

                CheckExec_Errno eno = runner.get_errno();
                // errno ͳ��
                switch (eno) 
                {
                case CheckExec_Errno::ok:
                    ++sr.ok_count;
                    break;
                case CheckExec_Errno::create_timer_id_failed:
                    ++sr.create_timer_failed;
                    break;
                case CheckExec_Errno::popen_faliled:
                    ++sr.popen_failed;
                    break;
                case CheckExec_Errno::start_timer_failed:
                    ++sr.start_timer_failed; 
                    break;
                case CheckExec_Errno::timeout:
                    ++sr.timeout; 
                    break;
                case CheckExec_Errno::max_output:
                    ++sr.max_output; 
                    break;
                case CheckExec_Errno::killed_by_callback:
                    ++sr.killed_by_callback; 
                    break;
                default:
                    break;
                }

                // Ĭ����һ�������ͨ��
                int ok_flag = 0;

                if (eno == CheckExec_Errno::ok &&std_status[idx] == CheckExec_Errno::ok)
                {
                    int diff = txt_compare(std_outs[idx], runner.msg.str());
                    if (diff == 0) 
                    {
                        ok_flag = 1;
                        ++sr.tc_ok_total;
                    }
                }

                sr.tc_ok_each[idx] = ok_flag;
            }
        }

        auto t_end = Clock::now();

        // ����̨��ʾ
        std::string bit_str;
        for (int v : sr.tc_ok_each) 
        {
            bit_str.push_back(v ? '1' : '0');  // 32 λ����Ӧÿ�����Ե�
        }
        bit_str.push_back('0');                // �� 33 λ�̶�Ϊ '0'

        print_student_result(
            i + 1,
            stu,
            exe_name,
            exe_exists,
            sr.ok_count,
            bit_str,
            sr.tc_ok_total,
            t_begin,
            t_end
        );

        results.push_back(sr);

    }

    // 7) ���� xls
    return save_result_xls(cfg, eff, opt, item_names, results, start_time_all);
}