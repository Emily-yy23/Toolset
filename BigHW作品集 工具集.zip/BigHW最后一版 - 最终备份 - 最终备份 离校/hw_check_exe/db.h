/* 2453253 ������ �Ű� */
#pragma once
#include <string>
#include <vector>
#include "config.h"
#include "student.h"

struct DbConfig 
{
    std::string host = "";
    unsigned    port = 0;
    std::string dbname = "";
    std::string user = "";
    std::string passwd = "";
    std::string term = "";
    std::string cno_list = "";
};

bool load_db_config(const Config& cfg, DbConfig& dbc);

bool fetch_students_from_db(const DbConfig& dbc,std::vector<Student>& students);