/* 2453253 ������ �Ű� */
#define _CRT_SECURE_NO_WARNINGS
#include "../include/check_exe.h"

using namespace std;

#if TIMER_NEW_VERSION
static void CALLBACK timeout_process(PVOID ExtParameter, BOOLEAN TimerOrWaitFired)
#else
static void CALLBACK timeout_process(UINT uTimerID, UINT uMsg, DWORD ExtParameter, DWORD dw1, DWORD dw2)
#endif
{
    st_CheckExec* my_exe = (st_CheckExec*)ExtParameter;

    if (++my_exe->time_count >= my_exe->cfg_timeout) 
    {
        my_exe->eno = CheckExec_Errno::timeout;

        int delta = my_exe->cfg_timeout < 5 ? my_exe->cfg_timeout * 2 : 5;
        if (my_exe->time_count >= my_exe->cfg_timeout + delta) 
        {
            my_exe->stop(CheckExec_Errno::killed_by_callback);
        }
    }
}

ostream& operator<<(ostream& out, const CheckExec_Errno& eno)
{
    switch (eno) 
    {
    case CheckExec_Errno::ok:                   
        out << "��ȷ����";        
        break;
    case CheckExec_Errno::create_timer_id_failed: 
        out << "��ʱ������ʧ��";
        break;
    case CheckExec_Errno::popen_faliled:        
        out << "�ܵ���ʽ��ʧ��";
        break;
    case CheckExec_Errno::start_timer_failed:   
        out << "������ʱ��ʧ��";  
        break;
    case CheckExec_Errno::timeout:              
        out << "��ʱ";           
        break;
    case CheckExec_Errno::max_output:           
        out << "�����������";    
        break;
    case CheckExec_Errno::killed_by_callback:   
        out << "��ѭ��";         
        break;
    default:                                    
        out << "δ֪�Ĵ���";       
        break;
    }
    return out;
}

st_CheckExec::st_CheckExec(const string& full_exec_cmd,const string& exec_name,int max_output_len,int timeout_second)
{
    this->full_exec_cmd = full_exec_cmd;
    this->exec_name = exec_name;
    this->max_output_len = max_output_len;
    this->cfg_timeout = timeout_second;

    this->time_count = 0;
    this->fp_exe = nullptr;
    this->timer_id = nullptr;
    this->eno = CheckExec_Errno::ok;
    this->msg.str("");
}

st_CheckExec::~st_CheckExec()
{
    if (this->timer_id != nullptr)
        this->stop_timer();

    if (this->eno != CheckExec_Errno::ok) 
    {
        char cmd_taskkill[512];
        sprintf(cmd_taskkill, "taskkill /f /t /im %s 1>nul 2>&1",this->exec_name.c_str());
        system(cmd_taskkill);
    }

    if (this->fp_exe)
    {
        _pclose(this->fp_exe);
        this->fp_exe = nullptr;
    }
}

int st_CheckExec::reset()
{
    this->time_count = 0;
    this->fp_exe = nullptr;
    this->timer_id = nullptr;
    this->eno = CheckExec_Errno::ok;
    this->msg.str("");
    return 0;
}

int st_CheckExec::start_timer()
{
#if TIMER_NEW_VERSION
    if (CreateTimerQueueTimer(&this->timer_id, NULL, timeout_process,this, 1000, 1000, 0) == 0) 
    {
        this->eno = CheckExec_Errno::create_timer_id_failed;
        return -1;
    }
#else
    this->timer_id = timeSetEvent(1000, 100, timeout_process,(DWORD_PTR)this, TIME_PERIODIC);
    if (timer_id == 0)
    {
        this->eno = CheckExec_Errno::create_timer_id_failed;
        return -1;
    }
#endif
    this->time_count = 0;
    QueryPerformanceFrequency(&this->time_tick);
    QueryPerformanceCounter(&this->begin_time);
    return 0;
}

void st_CheckExec::stop_timer()
{
#if TIMER_NEW_VERSION
    if (this->timer_id != nullptr) 
    {
        DeleteTimerQueueTimer(NULL, this->timer_id, NULL);
        this->timer_id = nullptr;
    }
#else
    if (this->timer_id != 0) 
    {
        timeKillEvent(this->timer_id);
        this->timer_id = 0;
    }
#endif
}

int st_CheckExec::stop(CheckExec_Errno no)
{
    this->stop_timer();
    QueryPerformanceCounter(&this->end_time);
    this->eno = no;

    if (this->eno != CheckExec_Errno::ok) 
    {
        char cmd_taskkill[512];
        sprintf(cmd_taskkill, "taskkill /f /t /im %s 1>nul 2>&1", this->exec_name.c_str());
        system(cmd_taskkill);
    }

    if (this->fp_exe) 
    {
        _pclose(this->fp_exe);
        this->fp_exe = nullptr;
    }
    return 0;
}

string st_CheckExec::get_full_cmd_exec() const
{
    return this->full_exec_cmd;
}

CheckExec_Errno st_CheckExec::get_errno() const
{
    return this->eno;
}

double st_CheckExec::get_running_time() const
{
    return double(this->end_time.QuadPart - this->begin_time.QuadPart) / double(time_tick.QuadPart);
}

int st_CheckExec::running()
{
    this->fp_exe = _popen(this->full_exec_cmd.c_str(), "rb");
    if (!this->fp_exe)
    {
        this->eno = CheckExec_Errno::popen_faliled;
        return -1;
    }

    if (this->start_timer() < 0)
    {
        this->msg << "������ʱ������" << endl;
        this->eno = CheckExec_Errno::start_timer_failed;
        return -1;
    }

    signed char ch;
    int ch_num = 0;

    while ((ch = fgetc(this->fp_exe)) != EOF) 
    {
        this->msg << ch;
        ++ch_num;

        if (this->eno == CheckExec_Errno::timeout) 
        {
            this->stop(CheckExec_Errno::timeout);
            return -1;
        }

        if (ch_num >= this->max_output_len)
        {
            this->stop(CheckExec_Errno::max_output);
            return -1;
        }
    }

    if (this->eno == CheckExec_Errno::killed_by_callback)
        return -1;

    this->stop(CheckExec_Errno::ok);
    return 0;
}