/* 2453253 ������ �Ű� */
#pragma once
#define TIMER_NEW_VERSION 1   // ʹ�� CreateTimerQueueTimer �°涨ʱ��

#include <string>
#include <sstream>
#include <ostream>
#include <windows.h>
#include <cstdio>

#if !TIMER_NEW_VERSION
#include <mmsystem.h>
#pragma comment(lib,"Winmm.lib")
#endif

enum class CheckExec_Errno 
{
    ok = 0,
    create_timer_id_failed,
    popen_faliled,
    start_timer_failed,
    timeout,
    max_output,
    killed_by_callback,
    max
};

std::ostream& operator<<(std::ostream& out, const CheckExec_Errno& eno);

class st_CheckExec 
{
protected:
    std::string   full_exec_cmd;   // ����������
    std::string   exec_name;       // �� exe �ļ���
    int           cfg_timeout;     // ��ʱʱ�䣨�룩
    int           max_output_len;  // �������ֽ���

    FILE* fp_exe;
    int           time_count;

#if TIMER_NEW_VERSION
    HANDLE        timer_id;
#else
    MMRESULT      timer_id;
#endif
    LARGE_INTEGER time_tick;
    LARGE_INTEGER begin_time;
    LARGE_INTEGER end_time;

    CheckExec_Errno eno;

    int  start_timer();
    void stop_timer();
    int  stop(CheckExec_Errno eno);

public:
    std::ostringstream msg;        // ����������

    st_CheckExec(const std::string& full_exec_cmd,
        const std::string& exec_name,
        int max_output_len,
        int timeout_second);
    ~st_CheckExec();

    int              running();
    double           get_running_time() const;
    std::string      get_full_cmd_exec() const;
    CheckExec_Errno  get_errno() const;
    int              reset();

#if TIMER_NEW_VERSION
    friend void CALLBACK timeout_process(PVOID lpParameter, BOOLEAN TimerOrWaitFired);
#else
    friend void CALLBACK timeout_process(UINT uTimerID, UINT uMsg, DWORD dwUser, DWORD dw1, DWORD dw2);
#endif
};