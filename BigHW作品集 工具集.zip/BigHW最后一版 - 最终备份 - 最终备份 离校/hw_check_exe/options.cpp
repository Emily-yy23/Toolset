/* 2453253 ������ �Ű� */
#include "options.h"
#include <iostream>
#include <iomanip>

using namespace std;

static DebugLevel parse_debug_level(const std::string& s, bool& ok)
{
    if (s == "warn") 
    {
        ok = true;
        return DebugLevel::WARN;
    }
    if (s == "info")
    { 
        ok = true; 
        return DebugLevel::INFO; 
    }
    if (s == "debug") 
    { 
        ok = true;
        return DebugLevel::DEBUG;
    }
    if (s == "trace") 
    { 
        ok = true;
        return DebugLevel::TRACE;
    }
    ok = false;
    return DebugLevel::WARN;
}

std::string debug_level_name(DebugLevel lvl)
{
    switch (lvl) 
    {
    case DebugLevel::WARN: 
        return "warn";
    case DebugLevel::INFO:  
        return "info";
    case DebugLevel::DEBUG: 
        return "debug";
    case DebugLevel::TRACE:
        return "trace";
    default:               
        return "warn";
    }
}

bool is_debug_enabled(const Options& opt, DebugLevel lvl)
{
    return static_cast<int>(opt.debug) >= static_cast<int>(lvl);
}

void print_usage(const Options& /*opt*/, const char* progname)
{
    const char* prog = progname ? progname : "hw_check_exe";

    cout << "args_list:\n";
    cout << "==========================================================================================\n";
    cout << " name            type                 default          exists value range/set\n";
    cout << "==========================================================================================\n";
    cout << " --help          Bool                 false            0      true  /\n";
    cout << " --debug         StringSETWithDefault warn             0      /     warn/info/debug/trace\n";
    cout << " --checkname     String               /                0      /     /\n";
    cout << " --checkcfg_only Bool                 false            0      /     /\n";
    cout << " --cfgfile       String               hw_check_exe.cfg 0      /     /\n";
    cout << "==========================================================================================\n\n";

    cout << "Usage: " << prog << " --��ѡ�� | --��ѡ��(���ִ�����)\n\n";

    cout << "��ѡ�ָ������\n";
    cout << "   --checkname : ��Ҫ������Ŀ��(�����ļ�������)\n\n";

    cout << "��ѡ��[--checkname]�Ŀ�ѡ������\n";
    cout << "   --checkcfg_only : ����ӡ�����ļ������\n\n";

    cout << "��ѡ�ָ������(��ѡ0~n��)\n";
    cout << "   --help    : ��ӡ������Ϣ\n";
    cout << "   --debug   : ����Debug�ȼ�(����ȼ� : warn/info/debug/trace���������ǰ��)\n";
    cout << "   --cfgfile : ָ�������ļ�\n\n";

    cout << "e.g.  :\n";
    cout << "   " << prog << " --checkname 3-b3\n";
    cout << "   " << prog << " --checkname 3-b3 --checkcfg_only\n";
    cout << "   " << prog << " --checkname 3-b3 --debug trace\n\n";
}

bool parse_args(int argc, char* argv[], Options& opt)
{
    std::string prog = (argc > 0 && argv[0]) ? argv[0] : "hw_check_exe";

    for (int i = 1; i < argc; ++i) 
    {
        std::string a = argv[i];

        if (a == "--help") 
        {
            opt.help = true;
        }
        else if (a == "--checkname") 
        {
            if (i + 1 >= argc) 
            {
                std::cerr << "����: ѡ�� --checkname ��Ҫһ������\n";
                return false;
            }
            opt.checkname = argv[++i];
        }
        else if (a == "--checkcfg_only" || a == "--check_only")
        {
            opt.checkcfg_only = true;
        }
        else if (a == "--cfgfile") 
        {
            if (i + 1 >= argc) 
            {
                std::cerr << "����: ѡ�� --cfgfile ��Ҫһ������\n";
                return false;
            }
            opt.cfgfile = argv[++i];
        }
        else if (a == "--debug") 
        {
            if (i + 1 >= argc) 
            {
                std::cerr << "����: ѡ�� --debug ��Ҫһ������(warn/info/debug/trace)\n";
                return false;
            }
            std::string lvl = argv[++i];
            bool ok = false;
            opt.debug = parse_debug_level(lvl, ok);
            if (!ok) 
            {
                std::cerr << "����: --debug ������Ч: " << lvl<< " (������ warn/info/debug/trace ֮һ)\n";
                return false;
            }
        }
        else 
        {
            std::cerr << "����: δ֪ѡ��: " << a << "\n";
            return false;
        }
    }

    if (!opt.help && opt.checkname.empty()) 
    {
        std::cerr << "����: ����ָ�� --checkname ѡ��\n";
        return false;
    }

    return true;
}