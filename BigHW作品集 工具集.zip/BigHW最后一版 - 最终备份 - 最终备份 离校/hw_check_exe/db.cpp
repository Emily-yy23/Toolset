/* 2453253 ������ �Ű� */
#include "db.h"
#include "../include_mariadb_x86/mysql/mysql.h"
#include <iostream>
#include <sstream>   

// �����ݿ��� (sno, sname, cno) ��� students ����
bool fetch_students_from_db(const DbConfig& dbc,
    std::vector<Student>& students)
{
    MYSQL* conn = mysql_init(nullptr);
    if (!conn) return false;

    if (!mysql_real_connect(conn,dbc.host.c_str(),dbc.user.c_str(), dbc.passwd.c_str(), dbc.dbname.c_str(),dbc.port,nullptr, 0))
    {
        std::cerr << "mysql_real_connect ʧ��: " << mysql_error(conn) << std::endl;
        mysql_close(conn);
        return false;
    }

    // ׼�� SQL���� cfg ��ע�͵Ĵ洢���̵���
    std::ostringstream oss;
    oss << "call proc_hwapp_get_stulist_from_view_student_cno('"<< dbc.term << "','"<< dbc.cno_list << "','sno',NULL);";

    std::string sql = oss.str();
    if (mysql_query(conn, sql.c_str()) != 0) 
    {
        std::cerr << "mysql_query ʧ��: " << mysql_error(conn) << std::endl;
        mysql_close(conn);
        return false;
    }

    MYSQL_RES* res = mysql_store_result(conn);
    if (!res) 
    {
        std::cerr << "mysql_store_result ʧ��: " << mysql_error(conn) << std::endl;
        mysql_close(conn);
        return false;
    }

    MYSQL_ROW row;
    students.clear();

    // �����е�˳��Ҫ�ο� test_mariadb.cpp �� row[0], row[1], row[2] �ĺ���
    //while ((row = mysql_fetch_row(res)) != nullptr) {
    //    Student s;
    //    s.sno = row[0] ? row[0] : "";   // ѧ��
    //    s.sname = row[1] ? row[1] : "";   // ����
    //    s.cno = row[2] ? row[2] : "";   // �κ�
    //    students.push_back(s);
    //}
    while ((row = mysql_fetch_row(res)) != nullptr)
    {
        Student s;

        // �洢���̷���
        s.sno = row[1] ? row[1] : "";   // ѧ��
        s.sname = row[2] ? row[2] : "";   // ����
        s.cno = row[10] ? row[10] : "";   // �κ�

        students.push_back(s);
    }

    mysql_free_result(res);
    mysql_close(conn);
    return true;
}

bool load_db_config(const Config& cfg, DbConfig& dbc)
{
    const CfgGroup* g = cfg.find_group("���ݿ�");
    if (!g) 
        return false;

    dbc.host = cfg.get_value(*g, "db_host", "");
    dbc.port = (unsigned)std::stoi(cfg.get_value(*g, "db_port", "3306"));
    dbc.dbname = cfg.get_value(*g, "db_name", "");
    dbc.user = cfg.get_value(*g, "db_username", "");
    dbc.passwd = cfg.get_value(*g, "db_passwd", "");
    dbc.term = cfg.get_value(*g, "db_curr_term", "");
    dbc.cno_list = cfg.get_value(*g, "db_cno_list", "");

    // ���Լ򵥼��һ���Ƿ�Ϊ��
    return !dbc.host.empty() && !dbc.dbname.empty() && !dbc.user.empty();
}