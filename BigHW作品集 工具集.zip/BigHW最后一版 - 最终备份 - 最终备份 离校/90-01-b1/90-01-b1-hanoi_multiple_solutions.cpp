/* 2453253 �Ű� ������ */
#include "90-01-b1-hanoi.h"
#include "../include/cmd_console_tools.h"
#include "../include/cmd_hdc_tools.h"

static int moveCount = 0;
static int towerADisks[10] = { 0 }, towerBDisks[10] = { 0 }, towerCDisks[10] = { 0 };
static int A = 0, B = 0, C = 0;
static int animationSpeed;

/*  ���ÿ���̨���ںͻ����� */
void setupConsole(int cols, int lines, int buffer_cols, int buffer_lines) 
{
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD buffer = { static_cast<SHORT>(buffer_cols > 0 ? buffer_cols : cols),
					static_cast<SHORT>(buffer_lines > 0 ? buffer_lines : lines) };
	SetConsoleScreenBufferSize(hOut, buffer);

	SMALL_RECT rect = { 0, 0, static_cast<SHORT>(cols - 1), static_cast<SHORT>(lines - 1) };
	SetConsoleWindowInfo(hOut, TRUE, &rect);
}

/* ѹ������ */
void addDiskToTower(char towerID, int diskSize) 
{
	switch (towerID)
	{
	case 'A': towerADisks[A++] = diskSize;
		break;
	case 'B': towerBDisks[B++] = diskSize;
		break;
	case 'C': towerCDisks[C++] = diskSize;
		break;
	}
}
/* �������� */
int removeDiskFromTower(char towerID)
{
	int diskSize = 0;
	switch (towerID) 
	{
	case 'A':
		diskSize = towerADisks[--A];
		towerADisks[A] = 0;
		break;
	case 'B':
		diskSize = towerBDisks[--B];
		towerBDisks[B] = 0;
		break;
	case 'C':
		diskSize = towerCDisks[--C];
		towerCDisks[C] = 0;
		break;
	}
	return diskSize;
}

void setTextColor(int bg, int fg) 
{
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hOut, bg * 16 + fg);
}

void displayBlock(int x, int y, char ch, int bg, int fg, int repeat) 
{
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD pos = { static_cast<SHORT>(x), static_cast<SHORT>(y) };
	DWORD written;

	setTextColor(bg, fg);
	FillConsoleOutputCharacter(hOut, ch, repeat, pos, &written);
	FillConsoleOutputAttribute(hOut, bg * 16 + fg, repeat, pos, &written);
}

/* 1. ������������ */
void drawBaseAndPoles() 
{
	// ����
	displayBlock(0, 15, ' ', COLOR_YELLOW, COLOR_YELLOW, 25);
	displayBlock(45, 15, ' ', COLOR_YELLOW, COLOR_YELLOW, 25);
	displayBlock(90, 15, ' ', COLOR_YELLOW, COLOR_YELLOW, 25);

	// ����
	for (int i = 0; i < 3; i++) 
	{
		for (int j = 14; j >= 5; j--) 
		{
			displayBlock(i * 45 + 12, j, ' ', COLOR_YELLOW, COLOR_YELLOW, 1);
			Sleep(20);
		}
	}
}

/* 2. ��ʼ���������� */
void initDisks(int n, char srcTower) 
{
	for (int i = n; i >= 1; i--) 
	{
		animationSpeed = 5;
		applyAnimationDelay();
		displayBlock((srcTower - 'A') * 45 + 12 - i, 14 - (n - i), ' ', i, i, 2 * i + 1);
	}
}

/* 3. �����ӡջ״̬ */
void showTowerStatus(char choice)
{
	setTextColor();

	if (choice == '4') 
	{
		cct_gotoxy(20, 17);
	}
	if (choice == '8' || choice == '7' || choice == '9') 
	{
		cct_gotoxy(20, 32);
	}

	cout << " A:";
	for (int i = 0; i < 10; i++) 
	{
		if (towerADisks[i] == 10)
			cout << 10;
		else if (towerADisks[i] > 0)
			cout << " " << towerADisks[i];
		else 
			cout << "  ";
	}
	cout << " ";

	cout << "B:";
	for (int i = 0; i < 10; i++) 
	{
		if (towerBDisks[i] == 10) 
			cout << 10;
		else if (towerBDisks[i] > 0) 
			cout << " " << towerBDisks[i];
		else 
			cout << "  ";
	}
	cout << " ";

	cout << "C:";
	for (int i = 0; i < 10; i++) 
	{
		if (towerCDisks[i] == 10) 
			cout << 10;
		else if (towerCDisks[i] > 0) 
			cout << " " << towerCDisks[i];
		else 
			cout << "  ";
	}
	cout << endl;

	if (choice == '4') 
	{
		applyAnimationDelay();
	}
}

/* 4. ��ӡ���� */
void logMovement(int n, char srcTower, char dst, char choice)
{
	setTextColor();

	if (choice == '4') 
	{
		cct_gotoxy(0, 17);
	}
	if (choice == '8' || choice == '7' || choice == '9')
	{
		cct_gotoxy(0, 32);
	}

	cout << "��" << setfill(' ') << setw(4) << moveCount << " ��(";
	if (n < 10) 
		cout << " ";
	    cout << n << "): " << srcTower << "-->" << dst;
	    addDiskToTower(dst, removeDiskFromTower(srcTower));
}

/* 5. �����ӡջ״̬ */
void showVerticalStatus(char choice) 
{
	setTextColor();

	int x = 11;
	int y = 11;

	if (choice == '8' || choice == '7' || choice == '9') 
	{
		y += 15;
	}

	for (int i = 0; i < 10; i++)
	{
		cct_gotoxy(x, y - i);
		if (towerADisks[i] != 0)
			cout << towerADisks[i];
		else 
			cout << " ";
	}
	for (int i = 0; i < 10; i++)
	{
		cct_gotoxy(x + 10, y - i);
		if (towerBDisks[i] != 0) 
			cout << towerBDisks[i];
		else 
			cout << " ";
	}
	for (int i = 0; i < 10; i++) 
	{
		cct_gotoxy(x + 20, y - i);
		if (towerCDisks[i] != 0) 
			cout << towerCDisks[i];
		else 
			cout << " ";
	}
	applyAnimationDelay();
}

/* �����ƶ����� */
/* 1.ˮƽ�ƶ� */
void animateHorizontalMove(int n, char srcTower, char tmp, char dst, char way)
{
	int start_x = (srcTower - 'A') * 45 + 12;
	int end_x = (dst - 'A') * 45 + 12;
	int direction = (dst - srcTower > 0) ? 1 : -1;

	for (int i = start_x; i != end_x; i += direction) 
	{
		displayBlock(i - n, 4, ' ', n, n, 2 * n + 1);
		Sleep(10);
		if (i != end_x) 
		{
			displayBlock(i - n, 4, ' ', COLOR_BLACK, COLOR_WHITE, 2 * n + 1);
			displayBlock(i, 4, ' ', COLOR_YELLOW, COLOR_WHITE, 1);
		}
	}
}

/* 2. ��ֱ�ƶ� */
void animateVerticalMove(int n, char srcTower, char tmp, char dst, char way, int up) 
{
	if (up == 1) 
	{
		int start_x = (srcTower - 'A') * 45 + 12;
		int start_y = 14 - A;
		int end_y = 4;

		for (int i = start_y; i >= end_y; i--) 
		{
			displayBlock(start_x - n, i, ' ', n, n, 2 * n + 1);
			Sleep(30);
			if (i > end_y) 
			{
				displayBlock(start_x - n, i, ' ', COLOR_BLACK, COLOR_WHITE, 2 * n + 1);
				if (i != 4) 
				{
					displayBlock(start_x, i, ' ', COLOR_YELLOW, COLOR_WHITE, 1);
				}
			}
		}
	}
	else
	{
		int end_x = (dst - 'A') * 45 + 12;
		int start_y = 4;
		int end_y = 15 - C;

		for (int i = start_y; i <= end_y; i++) 
		{
			displayBlock(end_x - n, i, ' ', n, n, 2 * n + 1);
			Sleep(30);
			if (i < end_y) 
			{
				displayBlock(end_x - n, i, ' ', COLOR_BLACK, COLOR_WHITE, 2 * n + 1);
				if (i != 4) 
				{
					displayBlock(end_x, i, ' ', COLOR_YELLOW, COLOR_WHITE, 1);
				}
			}
		}
	}
}

/* ������Ϸȫ��״̬ */
void resetGameState() 
{
	moveCount = 0;

	for (int i = 0; i < 10; i++) 
	{
		towerADisks[i] = 0;
		towerBDisks[i] = 0;
		towerCDisks[i] = 0;
	}

	A = 0;
	B = 0;
	C = 0;
}

void applyAnimationDelay() 
	{
		if (animationSpeed == 0)
		{
			_getch();
		}
		else if (animationSpeed == 1)
		{
			Sleep(2000);
		}
		else if (animationSpeed == 2)
		{
			Sleep(1000);
		}
		else if (animationSpeed == 3)
		{
			Sleep(500);
		}
		else if (animationSpeed == 4)
		{
			Sleep(200);
		}
		else if (animationSpeed == 5)
		{
			Sleep(50);
		}
	}

	//����
	void requestUserInput(int* n, char* srcTower, char* tmp, char* dst, int* display_stack, char choice)
	{
		char c;
		while (1) 
		{
			cout << "�����뺺ŵ���Ĳ���(1-10)��" << endl;
			cin >> *n;

			if (cin.fail()) 
			{
				cin.clear();
				while ((c = getchar()) != '\n' && c != EOF);
				continue;
			}
			else if (*n < 1 || *n>10)
			{
				while ((c = getchar()) != '\n' && c != EOF);
				continue;
			}
			else 
			{
				while ((c = getchar()) != '\n' && c != EOF);
				break;
			}

		}

		while (1) 
		{
			cout << "��������ʼ��(A-C)��" << endl;
			cin >> *srcTower;

			//תΪ��д
			if (*srcTower == 'a' || *srcTower == 'b' || *srcTower == 'c') 
			{
				*srcTower -= 0x20;
			}

			if (cin.fail()) 
			{
				cin.clear();
				while ((c = getchar()) != '\n' && c != EOF);
				continue;
			}
			else if (*srcTower < 'A' || *srcTower>'C') 
			{
				while ((c = getchar()) != '\n' && c != EOF);
				continue;
			}
			else
			{
				while ((c = getchar()) != '\n' && c != EOF);
				break;
			}
		}

		while (1) 
		{
			cout << "������Ŀ����(A-C)��" << endl;
			cin >> *dst;

			//תΪ��д
			if (*dst == 'a' || *dst == 'b' || *dst == 'c') 
			{
				*dst -= 0x20;
			}

			if (cin.fail()) 
			{
				cin.clear();
				while ((c = getchar()) != '\n' && c != EOF);
				continue;
			}

			else if (*dst < 'A' || *dst>'C') 
			{
				while ((c = getchar()) != '\n' && c != EOF);
				continue;
			}
			else if (*dst == *srcTower)
			{
				cout << "Ŀ����(" << *dst << ")��������ʼ��(" << *srcTower << ")��ͬ" << endl;
				while ((c = getchar()) != '\n' && c != EOF);
				continue;
			}
			else
			{
				while ((c = getchar()) != '\n' && c != EOF);
				break;
			}
		}


		//��������� 
		if (choice == '4') 
		{
			while (1)
			{
				cout << "�������ƶ��ٶ�(0-5: 0-���س�������ʾ 1-��ʱ� 5-��ʱ���)" << endl;
				cin >> animationSpeed;
				if (cin.fail()) 
				{
					cin.clear();
					while ((c = getchar()) != '\n' && c != EOF);
					continue;
				}
				else if (animationSpeed < 0 || animationSpeed > 5)
				{
					while ((c = getchar()) != '\n' && c != EOF);
					continue;
				}
				else 
				{
					while ((c = getchar()) != '\n' && c != EOF);
					break;
				}
			}

			while (1) 
			{
				cout << "�������Ƿ���ʾ�ڲ�����ֵ(0-����ʾ 1-��ʾ)" << endl;
				cin >> *display_stack;
				if (cin.fail())
				{
					cin.clear();
					while ((c = getchar()) != '\n' && c != EOF);
					continue;
				}
				else if (*display_stack < 0 || *display_stack > 1) 
				{
					while ((c = getchar()) != '\n' && c != EOF);
					continue;
				}
				else 
				{
					while ((c = getchar()) != '\n' && c != EOF);
					break;
				}
			}
		}


		*tmp = 3 * 'B' - *srcTower - *dst;

		//��ʼ��
		if (*srcTower == 'A') 
		{
			for (int i = 0; i < *n; i++)
			{
				towerADisks[i] = *n - i;
			}
			A = *n;
		}
		if (*srcTower == 'B') 
		{
			for (int i = 0; i < *n; i++) 
			{
				towerBDisks[i] = *n - i;
			}
			B = *n;
		}
		if (*srcTower == 'C') 
		{
			for (int i = 0; i < *n; i++) 
			{
				towerCDisks[i] = *n - i;
			}
			C = *n;
		}
	}


void executeMove(int n, char srcTower, char tmp, char dst, int display_stack, char way)
{
	moveCount++;
	if (way == '1') 
	{
		cout << n << "# " << srcTower << "---->" << dst << endl;
	}
	if (way == '2') 
	{
		cout << "��" << setfill(' ') << setw(4) << moveCount << " ��(" << setw(2) << n << "#: " << srcTower << "-->" << dst << ")" << endl;
	}
	if (way == '3') 
	{
		logMovement(n, srcTower, dst, way);
		showTowerStatus(way);
	}

	if (way == '4') 
	{
		logMovement(n, srcTower, dst, way);
		if (display_stack)
			showTowerStatus(way);
		showVerticalStatus(way);
	}
	if (way == '8' || way == '7' || way == '9')
	{

		logMovement(n, srcTower, dst, way);
		if (display_stack)
			showTowerStatus(way);
		showVerticalStatus(way);

		animateVerticalMove(n, srcTower, tmp, dst, way, 1);
		animateHorizontalMove(n, srcTower, tmp, dst, way);
		animateVerticalMove(n, srcTower, tmp, dst, way, 0);

	}
}

/* ���ĵݹ麯�� */
void solveTower(int n, char srcTower, char tmp, char dst, int display_stack, char way)
{
	if (n == 1) 
	{
		executeMove(n, srcTower, tmp, dst, display_stack, way);
	}
	else 
	{
		solveTower(n - 1, srcTower, dst, tmp, display_stack, way);
		if (way == '7') 
		{
			return;
		}
		executeMove(n, srcTower, tmp, dst, display_stack, way);
		solveTower(n - 1, tmp, srcTower, dst, display_stack, way);
	}
}

/*�����ܵ��ú��� */
void runHanoiMode(char choice)
{
	int n;
	char srcTower, tmp, dst;
	int display_stack;

	resetGameState();

	if (choice != '5')
	{
		requestUserInput(&n, &srcTower, &tmp, &dst, &display_stack, choice);
	}

	if (choice == '1' || choice == '2' || choice == '3')
	{
		solveTower(n, srcTower, tmp, dst, display_stack, choice);
	}

	if (choice == '4') 
	{
		cct_cls();
		cout << "�� " << srcTower << " �ƶ��� " << dst << "���� " << n << " �㣬��ʱ����Ϊ " << animationSpeed << "��" << (display_stack ? "" : "��") << "��ʾ�ڲ�����ֵ" << endl;
		cout << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl;
		cout << "         =========================" << endl;
		cout << "           A         B         C" << endl;
		cout << endl << endl << endl;

		cct_gotoxy(0, 17);


		if (display_stack) 
		{
			cout << "��ʼ:                ";
			showTowerStatus(choice);
		}

		showVerticalStatus(choice);
		solveTower(n, srcTower, tmp, dst, display_stack, choice);
	}

	if (choice == '5')
	{
		cct_cls();
		drawBaseAndPoles();
		cct_gotoxy(0, 30);
	}

	if (choice == '6') 
	{
		cct_cls();
		drawBaseAndPoles();

		initDisks(n, srcTower);
		cct_gotoxy(0, 30);
	}

	if (choice == '8' || choice == '7')
	{
		cct_cls();
		drawBaseAndPoles();

		cct_gotoxy(0, 27);
		setTextColor();
		cout << "         =========================" << endl;
		cout << "           A         B         C" << endl;

		initDisks(n, srcTower);

		solveTower(n, srcTower, tmp, dst, 1, choice);
		cct_gotoxy(0, 37);
	}

	if (choice == '9') 
	{
		cct_cls();
		drawBaseAndPoles();

		cct_gotoxy(0, 27);
		setTextColor();
		cout << "         =========================" << endl;
		cout << "           A         B         C" << endl;

		initDisks(n, srcTower);
		showVerticalStatus(choice);



		char temp[1000];

		while (1) 
		{
			cct_gotoxy(0, 35);
			setTextColor();
			cout << "�������ƶ�������(������ʽ��AC=A���˵������ƶ���C��Q=�˳�) ��                 ";

			int current_n = INT_MAX;
			int to_n = INT_MAX;
			cct_gotoxy(60, 35);
			cin.getline(temp, 1000);
			if (temp[0] == 'q' || temp[0] == 'Q') 
			{
				break;
			}
			if (temp[0] >= 'a' && temp[0] <= 'c') 
			{
				temp[0] -= 0x20;
			}
			if (temp[1] >= 'a' && temp[1] <= 'c') 
			{
				temp[1] -= 0x20;
			}
			if (temp[0] >= 'A' && temp[0] <= 'C' && temp[1] >= 'A' && temp[1] <= 'C') 
			{

				if (temp[0] == 'A' && A > 0) 
				{
					current_n = towerADisks[A - 1];
				}
				else if (temp[0] == 'B' && B > 0)
				{
					current_n = towerBDisks[B - 1];
				}
				else if (temp[0] == 'C' && C > 0) 
				{
					current_n = towerCDisks[C - 1];
				}
				else 
				{
					cct_gotoxy(0, 36);
					setTextColor();
					cout << "�Ƿ��ƶ�����ʼ��Ϊ�գ�       ";
					continue;
				}

				if (temp[1] == 'A' && A > 0) 
				{
					to_n = towerADisks[A - 1];
				}
				if (temp[1] == 'B' && B > 0) 
				{
					to_n = towerBDisks[B - 1];
				}
				if (temp[1] == 'C' && C > 0) 
				{
					to_n = towerCDisks[C - 1];
				}

				if (to_n < current_n) 
				{
					cct_gotoxy(0, 36);
					setTextColor();
					cout << "�Ƿ��ƶ�������ѹС�̣�        ";
					continue;
				}
				else 
				{
					cct_gotoxy(0, 36);
					setTextColor();
					cout << "                                                      ";
					executeMove(current_n, temp[0], tmp, temp[1], display_stack, choice);
				}

			}



		}

	}

	setTextColor();
	cout << endl;
	system("pause");
}