/* 2453253 ������ �Ű� */
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <Windows.h>
#include "../include/cmd_hdc_tools.h"
using namespace std;

void hdc_draw_cartoon_2453253(const int base_x, const int base_y)
{
    // �׾��������
    hdc_cls();

    // ��ɫ����
    const int MAIN_YELLOW = RGB(250, 230, 60);    // �����ɫ
    const int FILL_WHITE = RGB(255, 255, 255);   // ��ɫ
    const int LINE_BLACK = RGB(0, 0, 0);         // ������ɫ
    const int EYE_BLUE = RGB(70, 160, 255);    // ��ɫ
    const int TIE_RED = RGB(255, 60, 60);     // �����
    const int TONGUE_PINK = RGB(255, 180, 200);   // ����

    // ����
    const int body_width = 160;
    const int body_height = 200;
    const int eyes_width = 30;
    const int eyes_height = 18;

    int body_x = base_x - body_width / 2;
    int body_y = base_y - body_height / 2;
    int body_x2 = body_x;
    int body_y2 = body_y + body_height;
    int body_x3 = body_x + body_width;
    int body_y3 = body_y;
    int body_x4 = body_x + body_width;
    int body_y4 = body_y + body_height;
    int body_x5 = body_x + body_width - eyes_width;

    // 1. ���ƶ�����Բ
    int half_circle_radius = body_width / 2;  
    int half_circle_center_x = body_x + half_circle_radius;  
    int half_circle_center_y = body_y;  

    hdc_circle(half_circle_center_x, half_circle_center_y, half_circle_radius, true, 2, MAIN_YELLOW);
    hdc_circle(half_circle_center_x, half_circle_center_y, half_circle_radius, false, 5, LINE_BLACK);

    // 2. ���ƾ�������
    hdc_rectangle(body_x, body_y, body_width, body_height, 0, true, 2, MAIN_YELLOW);
    hdc_line(body_x, body_y, body_x2, body_y2, 2, LINE_BLACK);
    hdc_line(body_x3, body_y3, body_x4, body_y4, 2, LINE_BLACK);

    //3.�۴�
    hdc_rectangle(body_x, body_y, eyes_width, eyes_height, 0, true, 2, LINE_BLACK);
    hdc_rectangle(body_x5, body_y, eyes_width, eyes_height, 0, true, 2, LINE_BLACK);

    //4.���
    int mouth_y = body_y + 70;
    int mouth_x1 = base_x - 30;
    int mouth_y1 = mouth_y;
    int mouth_x2 = base_x + 30;
    int mouth_y2 = mouth_y;

    hdc_sector(base_x, mouth_y, 30, 180, 360, true, 2, FILL_WHITE);
    hdc_arc(base_x, mouth_y, 30, 180, 360, 4, LINE_BLACK);
    hdc_line(mouth_x1, mouth_y1, mouth_x2, mouth_y2, 2, LINE_BLACK);

    // 5.����
    int face_x1 = base_x + 50;
    int face_y1 = base_y + 56;
    int face_x2 = base_x - 50;
    int face_y2 = base_y - 56;
    hdc_circle(face_x1, face_y2, 15, true, 1, TONGUE_PINK);
    hdc_circle(face_x2, face_y2, 15, true, 1, TONGUE_PINK);

    // 6.�۾���������ɫԲ + ��ͫ�� + �ڵ㣩
    int eye_radius = 25;
    int eye_gap = 25;
    int eye_y = body_y + 15;

    // ����
    hdc_circle(base_x - eye_gap, eye_y, eye_radius, true, 1, FILL_WHITE);
    hdc_circle(base_x - eye_gap, eye_y, 10, true, 1, LINE_BLACK);
    hdc_circle(base_x - eye_gap, eye_y, 4, true, 1, FILL_WHITE);

    // ����
    hdc_circle(base_x + eye_gap, eye_y, eye_radius, true, 1, FILL_WHITE);
    hdc_circle(base_x + eye_gap, eye_y, 10, true, 1, LINE_BLACK);
    hdc_circle(base_x + eye_gap, eye_y, 4, true, 1, FILL_WHITE);

    // �۾��߿�
    hdc_circle(base_x - eye_gap, eye_y, eye_radius, false, 7, LINE_BLACK);
    hdc_circle(base_x + eye_gap, eye_y, eye_radius, false, 7, LINE_BLACK);

    //7.ͷ��
    int hair_x1 = half_circle_center_x + 60;
    int hair_y1 = half_circle_center_y - 40;
    int hair_x2 = half_circle_center_x - 50;
    int hair_y2 = half_circle_center_y - 50;
    int hair_x3 = half_circle_center_x - 60;
    int hair_y3 = half_circle_center_y - 40;
    int hair_x4 = half_circle_center_x + 70;
    int hair_y4 = half_circle_center_y - 40;
    hdc_arc(hair_x1, hair_y1, 50, 15, 110, 4, LINE_BLACK);
    hdc_arc(hair_x2, hair_y2, 50, 80, 170, 4, LINE_BLACK);
    hdc_arc(hair_x3, hair_y3, 40, 70, 160, 4, LINE_BLACK);
    hdc_arc(hair_x4, hair_y4, 36, 15, 100, 4, LINE_BLACK);

    //8. ���Ӻͳ���
    //����
    int pants_height = 60;
    int pants_y = body_y + body_height - pants_height;
    hdc_rectangle(body_x, pants_y, body_width, pants_height, 0, true, 1, EYE_BLUE);
    hdc_rectangle(body_x, pants_y, body_width, pants_height, 0, false, 2, LINE_BLACK);

    // ����
    int shirt_height = 35;
    hdc_rectangle(body_x, pants_y - shirt_height, body_width, shirt_height, 0, true, 1, FILL_WHITE);
    hdc_rectangle(body_x, pants_y - shirt_height, body_width, shirt_height, 0, false, 2, LINE_BLACK);

    // 9.�첲
    int arm_y = body_y + 100;
    int arm_x1 = body_x - 17;
    int arm_y1 = arm_y;
    int arm_x2 = body_x + body_width + 20;
    int arm_y2 = arm_y;
    hdc_line(body_x - 20, arm_y, body_x, arm_y, 22, MAIN_YELLOW);  // ���
    hdc_line(body_x + body_width, arm_y, body_x + body_width + 20, arm_y, 22, MAIN_YELLOW); // �ұ�
    hdc_circle(arm_x1, arm_y1, 15, true, 2, MAIN_YELLOW);
    hdc_circle(arm_x2, arm_y2, 15, true, 2, MAIN_YELLOW);
    hdc_circle(arm_x1, arm_y1, 16, false, 4, LINE_BLACK);
    hdc_circle(arm_x2, arm_y2, 16, false, 4, LINE_BLACK);

    // 10.��
    int leg_y_start = body_y + body_height;
    int leg_length = 25;
    hdc_line(base_x - 25, leg_y_start, base_x - 25, leg_y_start + leg_length, 20, MAIN_YELLOW);
    hdc_line(base_x + 25, leg_y_start, base_x + 25, leg_y_start + leg_length, 20, MAIN_YELLOW);

    // 11.Ь�ӣ���ɫС���Σ�
    hdc_rectangle(base_x - 40, leg_y_start + leg_length, 30, 12, 0, true, 1, LINE_BLACK);
    hdc_rectangle(base_x + 10, leg_y_start + leg_length, 30, 12, 0, true, 1, LINE_BLACK);

    // 12.����
    hdc_rectangle(base_x - 10, mouth_y, 10, 10, 0, true, 1, FILL_WHITE);
    hdc_rectangle(base_x - 10, mouth_y, 20, 10, 0, false, 2, LINE_BLACK);

    // 14.���
    int tie_top_x = base_x;
    int tie_top_y = pants_y - 20;
    int tie_x1 = body_x + 60;
    int tie_y1 = pants_y - shirt_height + 2;
    int tie_x2 = body_x + 100;
    int tie_y2 = pants_y - shirt_height + 2;
    int tie_x3 = body_x + 80;
    int tie_y3 = pants_y - 10;
    int tie_x4 = body_x + 70;
    int tie_y4 = pants_y +22;
    int tie_x5 = body_x + 90;
    int tie_y5 = pants_y +22;
    int tie_x6 = body_x + 80;
    int tie_y6 = pants_y -18;

    hdc_triangle(tie_x1, tie_y1, tie_x2, tie_y2, tie_x3, tie_y3, true, 1, TIE_RED);
    hdc_triangle(tie_x4, tie_y4, tie_x5, tie_y5, tie_x6, tie_y6, true, 1, TIE_RED);
}
    