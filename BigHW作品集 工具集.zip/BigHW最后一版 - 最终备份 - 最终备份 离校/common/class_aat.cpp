/* 2453253 ������ �Ű� */
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <algorithm>
#include <cctype>
#include <cmath>
#include "../include/class_aat.h"
using namespace std;

#if !ENABLE_LIB_COMMON_TOOLS //��ʹ��lib����Ч

/* ---------------------------------------------------------------
     ��������������Ҫstatic�������ڲ������ã�
   ---------------------------------------------------------------- */

   // �ַ����ָ��
static void split_string(const string& str, char delimiter, string parts[], int& part_count)
{
    part_count = 0;
    string token;
    istringstream tokenStream(str);

    while (getline(tokenStream, token, delimiter) && part_count < 4) 
    {
        parts[part_count++] = token;
    }
}

//���ֵvalue�Ƿ���int������
bool args_analyse_tools::is_in_int_set(int value) const 
{
    if (!extargs_int_set)
        return false;

    for (int i = 0; extargs_int_set[i] != INVALID_INT_VALUE_OF_SET; i++) 
    {
        if (extargs_int_set[i] == value) 
        {
            return true;
        }
    }
    return false;
}

//���ֵvalue�Ƿ���double������
bool args_analyse_tools::is_in_double_set(double value) const 
{
    if (!extargs_double_set) 
        return false;

    for (int i = 0; fabs(extargs_double_set[i] - INVALID_DOUBLE_VALUE_OF_SET) > DOUBLE_DELTA; i++) 
    {
        if (fabs(extargs_double_set[i] - value) < DOUBLE_DELTA)
        {
            return true;
        }
    }
    return false;
}

//���ֵvalue�Ƿ���string������
bool args_analyse_tools::is_in_string_set(const string& value) const 
{
    if (!extargs_string_set) 
        return false;

    for (int i = 0; !extargs_string_set[i].empty(); i++) 
    {
        if (extargs_string_set[i] == value) 
        {
            return true;
        }
    }
    return false;
}

//���IP��ַ�Ƿ���Ч
bool args_analyse_tools::is_valid_ipaddr(const string& ip) const 
{
    string parts[4];
    int part_count = 0;
    split_string(ip, '.', parts, part_count);

    if (part_count != 4) 
        return false;

    for (int i = 0; i < 4; i++)
    {
        if (parts[i].empty())
            return false;
        for (char c : parts[i]) 
        {
            if (!isdigit(c)) 
                return false;
        }
        try
        {
            int num = stoi(parts[i]);
            if (num < 0 || num > 255) 
                return false;
        }
        catch (...) 
        {
            return false;
        }
    }
    return true;
}

//IP�ַ���תunsigned int
u_int args_analyse_tools::ip_to_uint(const string& ip) const 
{
    string parts[4];
    int part_count = 0;
    split_string(ip, '.', parts, part_count);

    if (part_count != 4) return 0;

    return (stoi(parts[0]) << 24) | (stoi(parts[1]) << 16) |(stoi(parts[2]) << 8) | stoi(parts[3]);
}

//unsigned intתIP�ַ���
string args_analyse_tools::uint_to_ip(u_int ip) const 
{
    char buffer[16];
    snprintf(buffer, sizeof(buffer), "%d.%d.%d.%d",(ip >> 24) & 0xFF,(ip >> 16) & 0xFF,(ip >> 8) & 0xFF,ip & 0xFF);
    return string(buffer);
}

//��int�����в���ֵvalue������
int args_analyse_tools::find_int_set_index(int value) const 
{
    if (!extargs_int_set) return -1;

    for (int i = 0; extargs_int_set[i] != INVALID_INT_VALUE_OF_SET; i++) 
    {
        if (extargs_int_set[i] == value) 
        {
            return i;
        }
    }
    return -1;
}

//��double�����в���ֵvalue������
int args_analyse_tools::find_double_set_index(double value) const 
{
    if (!extargs_double_set) 
        return -1;

    for (int i = 0; fabs(extargs_double_set[i] - INVALID_DOUBLE_VALUE_OF_SET) > DOUBLE_DELTA; i++) 
    {
        if (fabs(extargs_double_set[i] - value) < DOUBLE_DELTA) 
        {
            return i;
        }
    }
    return -1;
}

//��string�����в���ֵvalue������
int args_analyse_tools::find_string_set_index(const string& value) const
{
    if (!extargs_string_set) 
        return -1;

    for (int i = 0; !extargs_string_set[i].empty(); i++) 
    {
        if (extargs_string_set[i] == value) 
        {
            return i;
        }
    }
    return -1;
}

//Ĭ�Ϲ��캯�� ��ʼ�����г�Ա����
args_analyse_tools::args_analyse_tools()
{
    args_name = "";
    extargs_type = ST_EXTARGS_TYPE::null;
    extargs_num = 0;

    extargs_bool_default = false;

    extargs_int_default = 0;
    extargs_int_min = 0;
    extargs_int_max = 0;
    extargs_int_set = nullptr;

    extargs_double_default = 0.0;
    extargs_double_min = 0.0;
    extargs_double_max = 0.0;
    extargs_double_set = nullptr;

    extargs_string_default = "";
    extargs_string_set = nullptr;

    extargs_ipaddr_default = 0;

    args_existed = 0;
    extargs_int_value = 0;
    extargs_double_value = 0.0;
    extargs_string_value = "";
    extargs_ipaddr_value = 0;
}

//bool���͹��캯�� ��ʼ��bool���Ͳ���
args_analyse_tools::args_analyse_tools(const char* name, const ST_EXTARGS_TYPE type, const int ext_num, const bool def)
{
    args_name = name;
    extargs_type = type;
    extargs_num = ext_num;

    extargs_bool_default = def;

    // ��ʼ��������Ա
    extargs_int_default = 0;
    extargs_int_min = 0;
    extargs_int_max = 0;
    extargs_int_set = nullptr;

    extargs_double_default = 0.0;
    extargs_double_min = 0.0;
    extargs_double_max = 0.0;
    extargs_double_set = nullptr;

    extargs_string_default = "";
    extargs_string_set = nullptr;

    extargs_ipaddr_default = 0;

    args_existed = 0;
    extargs_int_value = 0;
    extargs_double_value = 0.0;
    extargs_string_value = "";
    extargs_ipaddr_value = 0;
}

//int���͹��캯�� ��ʼ��int���Ͳ���
args_analyse_tools::args_analyse_tools(const char* name, const ST_EXTARGS_TYPE type, const int ext_num, const int def, const int _min, const int _max)
{
    args_name = name;
    extargs_type = type;
    extargs_num = ext_num;

    extargs_bool_default = false;

    extargs_int_default = def;
    extargs_int_min = _min;
    extargs_int_max = _max;
    extargs_int_set = nullptr;

    extargs_double_default = 0.0;
    extargs_double_min = 0.0;
    extargs_double_max = 0.0;
    extargs_double_set = nullptr;

    extargs_string_default = "";
    extargs_string_set = nullptr;

    extargs_ipaddr_default = 0;

    args_existed = 0;
    extargs_int_value = def;
    extargs_double_value = 0.0;
    extargs_string_value = "";
    extargs_ipaddr_value = 0;
}

//int�������͹��캯�� ��ʼ��int�������Ͳ���
args_analyse_tools::args_analyse_tools(const char* name, const enum ST_EXTARGS_TYPE type, const int ext_num, const int def_of_set_pos, const int* const set)
{
    args_name = name;
    extargs_type = type;
    extargs_num = ext_num;

    extargs_bool_default = false;

    // ���Ƽ���
    if (set) 
    {
        int count = 0;
        while (set[count] != INVALID_INT_VALUE_OF_SET) 
            count++;
        extargs_int_set = new int[count + 1];
        for (int i = 0; i <= count; i++) 
        {
            extargs_int_set[i] = set[i];
        }

        // ����Ĭ��ֵ
        if (def_of_set_pos >= 0 && def_of_set_pos < count)
        {
            extargs_int_default = set[def_of_set_pos];
            extargs_int_value = set[def_of_set_pos];
        }
        else 
        {
            extargs_int_default = (count > 0) ? set[0] : 0;
            extargs_int_value = (count > 0) ? set[0] : 0;
        }
    }
    else 
    {
        extargs_int_set = nullptr;
        extargs_int_default = 0;
        extargs_int_value = 0;
    }

    extargs_int_min = 0;
    extargs_int_max = 0;

    extargs_double_default = 0.0;
    extargs_double_min = 0.0;
    extargs_double_max = 0.0;
    extargs_double_set = nullptr;

    extargs_string_default = "";
    extargs_string_set = nullptr;

    extargs_ipaddr_default = 0;

    args_existed = 0;
    extargs_double_value = 0.0;
    extargs_string_value = "";
    extargs_ipaddr_value = 0;
}

//double���͹��캯�� ��ʼ��double���Ͳ���
args_analyse_tools::args_analyse_tools(const char* name, const ST_EXTARGS_TYPE type, const int ext_num, const double def, const double _min, const double _max)
{
    args_name = name;
    extargs_type = type;
    extargs_num = ext_num;

    extargs_bool_default = false;

    extargs_int_default = 0;
    extargs_int_min = 0;
    extargs_int_max = 0;
    extargs_int_set = nullptr;

    extargs_double_default = def;
    extargs_double_min = _min;
    extargs_double_max = _max;
    extargs_double_set = nullptr;

    extargs_string_default = "";
    extargs_string_set = nullptr;

    extargs_ipaddr_default = 0;

    args_existed = 0;
    extargs_int_value = 0;
    extargs_double_value = def;
    extargs_string_value = "";
    extargs_ipaddr_value = 0;
}

//double�������͹��캯�� ��ʼ��double�������Ͳ���
args_analyse_tools::args_analyse_tools(const char* name, const enum ST_EXTARGS_TYPE type, const int ext_num, const int def_of_set_pos, const double* const set)
{
    args_name = name;
    extargs_type = type;
    extargs_num = ext_num;

    extargs_bool_default = false;

    extargs_int_default = 0;
    extargs_int_min = 0;
    extargs_int_max = 0;
    extargs_int_set = nullptr;

    // ���Ƽ���
    if (set) 
    {
        int count = 0;
        while (fabs(set[count] - INVALID_DOUBLE_VALUE_OF_SET) > DOUBLE_DELTA) 
            count++;
        extargs_double_set = new double[count + 1];
        for (int i = 0; i <= count; i++)
        {
            extargs_double_set[i] = set[i];
        }

        // ����Ĭ��ֵ
        if (def_of_set_pos >= 0 && def_of_set_pos < count) 
        {
            extargs_double_default = set[def_of_set_pos];
            extargs_double_value = set[def_of_set_pos];
        }
        else 
        {
            extargs_double_default = (count > 0) ? set[0] : 0.0;
            extargs_double_value = (count > 0) ? set[0] : 0.0;
        }
    }
    else 
    {
        extargs_double_set = nullptr;
        extargs_double_default = 0.0;
        extargs_double_value = 0.0;
    }

    extargs_double_min = 0.0;
    extargs_double_max = 0.0;

    extargs_string_default = "";
    extargs_string_set = nullptr;

    extargs_ipaddr_default = 0;

    args_existed = 0;
    extargs_int_value = 0;
    extargs_string_value = "";
    extargs_ipaddr_value = 0;
}

//string���͹��캯�� ��ʼ��string���Ͳ���
args_analyse_tools::args_analyse_tools(const char* name, const ST_EXTARGS_TYPE type, const int ext_num, const string def)
{
    args_name = name;
    extargs_type = type;
    extargs_num = ext_num;

    extargs_bool_default = false;

    extargs_int_default = 0;
    extargs_int_min = 0;
    extargs_int_max = 0;
    extargs_int_set = nullptr;

    extargs_double_default = 0.0;
    extargs_double_min = 0.0;
    extargs_double_max = 0.0;
    extargs_double_set = nullptr;

    extargs_string_default = def;
    extargs_string_set = nullptr;

    if (type == ST_EXTARGS_TYPE::ipaddr_with_default || type == ST_EXTARGS_TYPE::ipaddr_with_error) 
    {
        if (is_valid_ipaddr(def)) 
        {
            extargs_ipaddr_default = ip_to_uint(def);
            extargs_ipaddr_value = ip_to_uint(def);
        }
        else 
        {
            extargs_ipaddr_default = 0;
            extargs_ipaddr_value = 0;
        }
    }
    else 
    {
        extargs_ipaddr_default = 0;
        extargs_ipaddr_value = 0;
    }

    args_existed = 0;
    extargs_int_value = 0;
    extargs_double_value = 0.0;
    extargs_string_value = def;
}

//string�������͹��캯�� ��ʼ��string�������Ͳ���
args_analyse_tools::args_analyse_tools(const char* name, const ST_EXTARGS_TYPE type, const int ext_num, const int def_of_set_pos, const string* const set)
{
    args_name = name;
    extargs_type = type;
    extargs_num = ext_num;

    extargs_bool_default = false;

    extargs_int_default = 0;
    extargs_int_min = 0;
    extargs_int_max = 0;
    extargs_int_set = nullptr;

    extargs_double_default = 0.0;
    extargs_double_min = 0.0;
    extargs_double_max = 0.0;
    extargs_double_set = nullptr;

    // ���Ƽ���
    if (set) 
    {
        int count = 0;
        while (!set[count].empty()) 
            count++;
        extargs_string_set = new string[count + 1];
        for (int i = 0; i <= count; i++) 
        {
            extargs_string_set[i] = set[i];
        }

        // ����Ĭ��ֵ
        if (def_of_set_pos >= 0 && def_of_set_pos < count)
        {
            extargs_string_default = set[def_of_set_pos];
            extargs_string_value = set[def_of_set_pos];
        }
        else 
        {
            extargs_string_default = (count > 0) ? set[0] : "";
            extargs_string_value = (count > 0) ? set[0] : "";
        }
    }
    else 
    {
        extargs_string_set = nullptr;
        extargs_string_default = "";
        extargs_string_value = "";
    }

    extargs_ipaddr_default = 0;

    args_existed = 0;
    extargs_int_value = 0;
    extargs_double_value = 0.0;
    extargs_ipaddr_value = 0;
}

//���������ͷŶ�̬������ڴ�
args_analyse_tools::~args_analyse_tools()
{
    if (extargs_int_set) 
    {
        delete[] extargs_int_set;
        extargs_int_set = nullptr;
    }
    if (extargs_double_set) 
    {
        delete[] extargs_double_set;
        extargs_double_set = nullptr;
    }
    if (extargs_string_set) 
    {
        delete[] extargs_string_set;
        extargs_string_set = nullptr;
    }
}

/* ---------------------------------------------------------------
     ����AAT���Զ����Ա������ʵ�֣�private��
   ---------------------------------------------------------------- */

   /***************************************************************************
     �������ƣ�get_name
     ��    �ܣ����ز�����
     �����������
     �� �� ֵ���������ַ���
     ˵    ������ʵ�֣���Ҫ��
    ***************************************************************************/
const string args_analyse_tools::get_name() const
{
    return this->args_name;
}

/***************************************************************************
  �������ƣ�existed
  ��    �ܣ��жϲ����Ƿ����
  �����������
  �� �� ֵ���Ƿ���ڣ�0/1��
  ˵    ������!!��ֻ����0/1
            ��ʵ�֣���Ҫ��
 ***************************************************************************/
const int args_analyse_tools::existed() const
{
    return !!this->args_existed;
}

/***************************************************************************
  �������ƣ�get_int
  ��    �ܣ�����int����ֵ
  �����������
  �� �� ֵ��intֵ
  ˵    ������ʵ�֣���Ҫ��
 ***************************************************************************/
const int args_analyse_tools::get_int() const
{
    return this->extargs_int_value;
}

/***************************************************************************
  �������ƣ�get_double
  ��    �ܣ�����double����ֵ
  �����������
  �� �� ֵ��doubleֵ
  ˵    ������ʵ�֣���Ҫ��
 ***************************************************************************/
const double args_analyse_tools::get_double() const
{
    return this->extargs_double_value;
}

/***************************************************************************
  �������ƣ�get_string
  ��    �ܣ�����string����ֵ
  �����������
  �� �� ֵ��stringֵ
  ˵    ������ʵ�֣���Ҫ��
 ***************************************************************************/
const string args_analyse_tools::get_string() const
{
    return this->extargs_string_value;
}

/***************************************************************************
  �������ƣ�get_ipaddr
  ��    �ܣ�����IP��ַ��unsigned int��ʽ
  �����������
  �� �� ֵ��unsigned int��ʽ��IP��ַ
  ˵    ������ʵ�֣���Ҫ��
 ***************************************************************************/
const unsigned int args_analyse_tools::get_ipaddr() const
{
    return this->extargs_ipaddr_value;
}

/***************************************************************************
  �������ƣ�get_str_ipaddr
  ��    �ܣ���IP��ַת��Ϊ�ַ�����ʽ
  �����������
  �� �� ֵ���ַ�����ʽ��IP��ַ
  ˵    ������ extargs_ipaddr_value ��ֵ�� 0x7f000001 תΪ "127.0.0.1"
 ***************************************************************************/
const string args_analyse_tools::get_str_ipaddr() const
{
    return uint_to_ip(this->extargs_ipaddr_value);
}

/***************************************************************************
  �������ƣ�args_analyse_process
  ��    �ܣ����������в���
  ���������argc ��������, argv �������� �û�����, args ������������ �Լ���ʼ��, follow_up_args �Ƿ��к�������
  �� �� ֵ���ɹ������Ѵ����Ĳ���������ʧ�ܷ���-1
  ˵    ������Ԫ����
***************************************************************************/
int args_analyse_process(const int argc, const char* const* const argv, args_analyse_tools* const args, const int follow_up_args)
{
    if (argc <= 0 || !argv || !args) 
    {
        return -1;
    }

    int i = 1;
    while (i < argc) 
    {
        string current_arg = argv[i];
        if (current_arg.find("--") == 0) 
        {
            int arg_index = 0;
            while (args[arg_index].extargs_type != ST_EXTARGS_TYPE::null) 
            {
                if (args[arg_index].args_name == current_arg) 
                {
                    break;
                }
                arg_index++;
            }

            if (args[arg_index].extargs_type == ST_EXTARGS_TYPE::null) 
            {
                cout << "����δ֪���� " << current_arg << endl;
                return -1;
            }

            if (args[arg_index].args_existed)
            {
                cout << "���󣺲��� " << current_arg << " �ظ�����" << endl;
                return -1;
            }

            args[arg_index].args_existed = 1;

            if (args[arg_index].extargs_num > 0) 
            {
                i++; // �ƶ�������ֵ
                if (i >= argc) 
                {
                    cout << "���󣺲��� " << current_arg << " ��Ҫ����ֵ" << endl;
                    return -1;
                }

                string value_str = argv[i];
                switch (args[arg_index].extargs_type) 
                {
                case ST_EXTARGS_TYPE::int_with_default:
                case ST_EXTARGS_TYPE::int_with_error:
                {
                    try 
                    {
                        int value = stoi(value_str);
                        if (value >= args[arg_index].extargs_int_min && value <= args[arg_index].extargs_int_max) 
                        {
                            args[arg_index].extargs_int_value = value;
                        }
                        else 
                        {
                            if (args[arg_index].extargs_type == ST_EXTARGS_TYPE::int_with_default) 
                            {
                                args[arg_index].extargs_int_value = args[arg_index].extargs_int_default;
                                cout << "���棺���� " << current_arg << " ��ֵ " << value << " ������Χ ["<< args[arg_index].extargs_int_min << ", " << args[arg_index].extargs_int_max<< "]��ʹ��Ĭ��ֵ " << args[arg_index].extargs_int_default << endl;
                            }
                            else 
                            {
                                cout << "���󣺲��� " << current_arg << " ��ֵ " << value << " ������Χ ["<< args[arg_index].extargs_int_min << ", " << args[arg_index].extargs_int_max << "]" << endl;
                                return -1;
                            }
                        }
                    }
                    catch (...) 
                    {
                        if (args[arg_index].extargs_type == ST_EXTARGS_TYPE::int_with_default) 
                        {
                            args[arg_index].extargs_int_value = args[arg_index].extargs_int_default;
                            cout << "���棺���� " << current_arg << " ��ֵ��ʽ����ʹ��Ĭ��ֵ " << args[arg_index].extargs_int_default << endl;
                        }
                        else 
                        {
                            cout << "���󣺲��� " << current_arg << " ��ֵ��ʽ����" << endl;
                            return -1;
                        }
                    }
                    break;
                }

                case ST_EXTARGS_TYPE::int_with_set_default:
                case ST_EXTARGS_TYPE::int_with_set_error: 
                {
                    try 
                    {
                        int value = stoi(value_str);
                        if (args[arg_index].is_in_int_set(value))
                        {
                            args[arg_index].extargs_int_value = value;
                        }
                        else
                        {
                            if (args[arg_index].extargs_type == ST_EXTARGS_TYPE::int_with_set_default)
                            {
                                args[arg_index].extargs_int_value = args[arg_index].extargs_int_default;
                                cout << "���棺���� " << current_arg << " ��ֵ " << value << " ���������ļ����У�ʹ��Ĭ��ֵ " << args[arg_index].extargs_int_default << endl;
                            }
                            else 
                            {
                                cout << "���󣺲��� " << current_arg << " ��ֵ " << value << " ���������ļ�����" << endl;
                                return -1;
                            }
                        }
                    }
                    catch (...) 
                    {
                        if (args[arg_index].extargs_type == ST_EXTARGS_TYPE::int_with_set_default) 
                        {
                            args[arg_index].extargs_int_value = args[arg_index].extargs_int_default;
                            cout << "���棺���� " << current_arg << " ��ֵ��ʽ����ʹ��Ĭ��ֵ " << args[arg_index].extargs_int_default << endl;
                        }
                        else 
                        {
                            cout << "���󣺲��� " << current_arg << " ��ֵ��ʽ����" << endl;
                            return -1;
                        }
                    }
                    break;
                }

                case ST_EXTARGS_TYPE::double_with_default:
                case ST_EXTARGS_TYPE::double_with_error:
                {
                    try 
                    {
                        double value = stod(value_str);
                        if (value >= args[arg_index].extargs_double_min && value <= args[arg_index].extargs_double_max)
                        {
                            args[arg_index].extargs_double_value = value;
                        }
                        else 
                        {
                            if (args[arg_index].extargs_type == ST_EXTARGS_TYPE::double_with_default)
                            {
                                args[arg_index].extargs_double_value = args[arg_index].extargs_double_default;
                                cout << "���棺���� " << current_arg << " ��ֵ " << value << " ������Χ ["<< args[arg_index].extargs_double_min << ", " << args[arg_index].extargs_double_max<< "]��ʹ��Ĭ��ֵ " << args[arg_index].extargs_double_default << endl;
                            }
                            else 
                            {
                                cout << "���󣺲��� " << current_arg << " ��ֵ " << value << " ������Χ ["<< args[arg_index].extargs_double_min << ", " << args[arg_index].extargs_double_max << "]" << endl;
                                return -1;
                            }
                        }
                    }
                    catch (...) 
                    {
                        if (args[arg_index].extargs_type == ST_EXTARGS_TYPE::double_with_default) 
                        {
                            args[arg_index].extargs_double_value = args[arg_index].extargs_double_default;
                            cout << "���棺���� " << current_arg << " ��ֵ��ʽ����ʹ��Ĭ��ֵ " << args[arg_index].extargs_double_default << endl;
                        }
                        else 
                        {
                            cout << "���󣺲��� " << current_arg << " ��ֵ��ʽ����" << endl;
                            return -1;
                        }
                    }
                    break;
                }

                case ST_EXTARGS_TYPE::double_with_set_default:
                case ST_EXTARGS_TYPE::double_with_set_error:
                {
                    try 
                    {
                        double value = stod(value_str);
                        if (args[arg_index].is_in_double_set(value)) 
                        {
                            args[arg_index].extargs_double_value = value;
                        }
                        else 
                        {
                            if (args[arg_index].extargs_type == ST_EXTARGS_TYPE::double_with_set_default) 
                            {
                                args[arg_index].extargs_double_value = args[arg_index].extargs_double_default;
                                cout << "���棺���� " << current_arg << " ��ֵ " << value << " ���������ļ����У�ʹ��Ĭ��ֵ " << args[arg_index].extargs_double_default << endl;
                            }
                            else 
                            {
                                cout << "���󣺲��� " << current_arg << " ��ֵ " << value << " ���������ļ�����" << endl;
                                return -1;
                            }
                        }
                    }
                    catch (...) 
                    {
                        if (args[arg_index].extargs_type == ST_EXTARGS_TYPE::double_with_set_default)
                        {
                            args[arg_index].extargs_double_value = args[arg_index].extargs_double_default;
                            cout << "���棺���� " << current_arg << " ��ֵ��ʽ����ʹ��Ĭ��ֵ " << args[arg_index].extargs_double_default << endl;
                        }
                        else 
                        {
                            cout << "���󣺲��� " << current_arg << " ��ֵ��ʽ����" << endl;
                            return -1;
                        }
                    }
                    break;
                }

                case ST_EXTARGS_TYPE::str: 
                {
                    args[arg_index].extargs_string_value = value_str;
                    break;
                }

                case ST_EXTARGS_TYPE::str_with_set_default:
                case ST_EXTARGS_TYPE::str_with_set_error: 
                {
                    if (args[arg_index].is_in_string_set(value_str)) 
                    {
                        args[arg_index].extargs_string_value = value_str;
                    }
                    else 
                    {
                        if (args[arg_index].extargs_type == ST_EXTARGS_TYPE::str_with_set_default)
                        {
                            args[arg_index].extargs_string_value = args[arg_index].extargs_string_default;
                            cout << "���棺���� " << current_arg << " ��ֵ " << value_str << " ���������ļ����У�ʹ��Ĭ��ֵ " << args[arg_index].extargs_string_default << endl;
                        }
                        else 
                        {
                            cout << "���󣺲��� " << current_arg << " ��ֵ " << value_str << " ���������ļ�����" << endl;
                            return -1;
                        }
                    }
                    break;
                }

                case ST_EXTARGS_TYPE::ipaddr_with_default:
                case ST_EXTARGS_TYPE::ipaddr_with_error: 
                {
                    if (args[arg_index].is_valid_ipaddr(value_str)) 
                    {
                        args[arg_index].extargs_ipaddr_value = args[arg_index].ip_to_uint(value_str);
                        args[arg_index].extargs_string_value = value_str;
                    }
                    else 
                    {
                        if (args[arg_index].extargs_type == ST_EXTARGS_TYPE::ipaddr_with_default) 
                        {
                            args[arg_index].extargs_ipaddr_value = args[arg_index].extargs_ipaddr_default;
                            args[arg_index].extargs_string_value = args[arg_index].uint_to_ip(args[arg_index].extargs_ipaddr_default);
                            cout << "���棺���� " << current_arg << " ��ֵ " << value_str << " ������Ч��IP��ַ��ʹ��Ĭ��ֵ " << args[arg_index].uint_to_ip(args[arg_index].extargs_ipaddr_default) << endl;
                        }
                        else
                        {
                            cout << "���󣺲��� " << current_arg << " ��ֵ " << value_str << " ������Ч��IP��ַ" << endl;
                            return -1;
                        }
                    }
                    break;
                }

                default:
                    break;
                }
            }
            else 
            {
                // �޸���ֵ��bool���ͣ�����ֵΪtrue
                if (args[arg_index].extargs_type == ST_EXTARGS_TYPE::boolean) 
                {
                }
            }
        }
        else 
        {
            break;
        }
        i++;
    }

    // ����Ƿ���Ҫ�̶�����
    if (follow_up_args && i == argc) 
    {
        cout << "������Ҫ�̶�������δ�ṩ" << endl;
        return -1;
    }

    return i; 
}

/***************************************************************************
  �������ƣ�args_analyse_print
  ��    �ܣ���ӡ�����������
  ���������args - ������������
  �� �� ֵ���ɹ�����0
  ˵    ������Ԫ����
***************************************************************************/
int args_analyse_print(const args_analyse_tools* const args)
{
    if (!args) 
        return -1;

    // ����ÿ�е�������
    int max_name_width = 4;    
    int max_type_width = 4;    
    int max_default_width = 7; 
    int max_exists_width = 6;  
    int max_value_width = 5;   
    int max_range_width = 11; 

    // ��һ�α�����������е�������
    for (int i = 0; args[i].extargs_type != ST_EXTARGS_TYPE::null; i++) 
    {
        max_name_width = max(max_name_width, (int)args[i].get_name().length());

        string type_str;
        switch (args[i].extargs_type) 
        {
        case ST_EXTARGS_TYPE::boolean:
            type_str = "Bool";
            break;
        case ST_EXTARGS_TYPE::int_with_default: 
            type_str = "IntWithDefault"; 
            break;
        case ST_EXTARGS_TYPE::int_with_error:
            type_str = "IntWithError";
            break;
        case ST_EXTARGS_TYPE::int_with_set_default: 
            type_str = "IntSETWithDefault"; 
            break;
        case ST_EXTARGS_TYPE::int_with_set_error: 
            type_str = "IntSETWithError"; 
            break;
        case ST_EXTARGS_TYPE::double_with_default: 
            type_str = "DoubleWithDefault"; 
            break;
        case ST_EXTARGS_TYPE::double_with_error: 
            type_str = "DoubleWithError"; 
            break;
        case ST_EXTARGS_TYPE::double_with_set_default: 
            type_str = "DoubleSETWithDefault"; 
            break;
        case ST_EXTARGS_TYPE::double_with_set_error: 
            type_str = "DoubleSETWithError"; 
            break;
        case ST_EXTARGS_TYPE::str: 
            type_str = "String"; 
            break;
        case ST_EXTARGS_TYPE::str_with_set_default: 
            type_str = "StringSETWithDefault"; 
            break;
        case ST_EXTARGS_TYPE::str_with_set_error: 
            type_str = "StringSETWithError"; 
            break;
        case ST_EXTARGS_TYPE::ipaddr_with_default: 
            type_str = "IPAddrWithDefault"; 
            break;
        case ST_EXTARGS_TYPE::ipaddr_with_error: 
            type_str = "IPAddrWithError";
            break;
        default: 
            type_str = "Unknown"; 
            break;
        }
        max_type_width = max(max_type_width, (int)type_str.length());

        string default_str = "/";
        switch (args[i].extargs_type)
        {
        case ST_EXTARGS_TYPE::boolean:
            default_str = args[i].extargs_bool_default ? "true" : "false";
            break;
        case ST_EXTARGS_TYPE::int_with_default:
        case ST_EXTARGS_TYPE::int_with_set_default:
            default_str = to_string(args[i].extargs_int_default);
            break;
        case ST_EXTARGS_TYPE::int_with_error:
        case ST_EXTARGS_TYPE::int_with_set_error:
            default_str = "/";  
            break;
        case ST_EXTARGS_TYPE::double_with_default:
        case ST_EXTARGS_TYPE::double_with_set_default:
        {
            ostringstream oss;
            oss << fixed << setprecision(6) << args[i].extargs_double_default;
            default_str = oss.str();
        }
        break;
        case ST_EXTARGS_TYPE::double_with_error:
        case ST_EXTARGS_TYPE::double_with_set_error:
            default_str = "/";  
            break;
        case ST_EXTARGS_TYPE::str:
            default_str = args[i].extargs_string_default.empty() ? "/" : args[i].extargs_string_default;
            break;
        case ST_EXTARGS_TYPE::str_with_set_default:
            default_str = args[i].extargs_string_default;
            break;
        case ST_EXTARGS_TYPE::str_with_set_error:
            default_str = "/";  
            break;
        case ST_EXTARGS_TYPE::ipaddr_with_default:
            default_str = args[i].uint_to_ip(args[i].extargs_ipaddr_default);
            break;
        case ST_EXTARGS_TYPE::ipaddr_with_error:
            default_str = "/";  
            break;
        default:
            break;
        }
        max_default_width = max(max_default_width, (int)default_str.length());

        // exists��
        string exists_str = to_string(args[i].existed());
        max_exists_width = max(max_exists_width, (int)exists_str.length());

        // ��ǰֵ�ַ���
        string value_str = "/";
        if (args[i].existed())
        {
            switch (args[i].extargs_type) 
            {
            case ST_EXTARGS_TYPE::boolean:
                value_str = "true";
                break;
            case ST_EXTARGS_TYPE::int_with_default:
            case ST_EXTARGS_TYPE::int_with_error:
            case ST_EXTARGS_TYPE::int_with_set_default:
            case ST_EXTARGS_TYPE::int_with_set_error:
                value_str = to_string(args[i].get_int());
                break;
            case ST_EXTARGS_TYPE::double_with_default:
            case ST_EXTARGS_TYPE::double_with_error:
            case ST_EXTARGS_TYPE::double_with_set_default:
            case ST_EXTARGS_TYPE::double_with_set_error:
            {
                ostringstream oss;
                oss << fixed << setprecision(6) << args[i].get_double();
                value_str = oss.str();
            }
            break;
            case ST_EXTARGS_TYPE::str:
            case ST_EXTARGS_TYPE::str_with_set_default:
            case ST_EXTARGS_TYPE::str_with_set_error:
                value_str = args[i].get_string();
                break;
            case ST_EXTARGS_TYPE::ipaddr_with_default:
            case ST_EXTARGS_TYPE::ipaddr_with_error:
                value_str = args[i].get_str_ipaddr();
                break;
            default:
                break;
            }
        }
        max_value_width = max(max_value_width, (int)value_str.length());

        // ��Χ/�����ַ���
        string range_str = "/";
        switch (args[i].extargs_type) 
        {
        case ST_EXTARGS_TYPE::int_with_default:
        case ST_EXTARGS_TYPE::int_with_error:
            range_str = "[" + to_string(args[i].extargs_int_min) + ".." +to_string(args[i].extargs_int_max) + "]";
            break;
        case ST_EXTARGS_TYPE::int_with_set_default:
        case ST_EXTARGS_TYPE::int_with_set_error:
            if (args[i].extargs_int_set) 
            {
                range_str = "";
                for (int j = 0; args[i].extargs_int_set[j] != INVALID_INT_VALUE_OF_SET; j++) 
                {
                    if (j > 0) 
                        range_str += "/";
                    range_str += to_string(args[i].extargs_int_set[j]);
                }
            }
            break;
        case ST_EXTARGS_TYPE::double_with_default:
        case ST_EXTARGS_TYPE::double_with_error:
        {
            ostringstream min_oss, max_oss;
            min_oss << fixed << setprecision(6) << args[i].extargs_double_min;
            max_oss << fixed << setprecision(6) << args[i].extargs_double_max;
            range_str = "[" + min_oss.str() + ".." + max_oss.str() + "]";
        }
        break;
        case ST_EXTARGS_TYPE::double_with_set_default:
        case ST_EXTARGS_TYPE::double_with_set_error:
            if (args[i].extargs_double_set) 
            {
                range_str = "";
                for (int j = 0; fabs(args[i].extargs_double_set[j] - INVALID_DOUBLE_VALUE_OF_SET) > DOUBLE_DELTA; j++) 
                {
                    if (j > 0)
                        range_str += "/";
                    ostringstream oss;
                    oss << fixed << setprecision(6) << args[i].extargs_double_set[j];
                    range_str += oss.str();
                }
            }
            break;
        case ST_EXTARGS_TYPE::str_with_set_default:
        case ST_EXTARGS_TYPE::str_with_set_error:
            if (args[i].extargs_string_set) 
            {
                range_str = "";
                for (int j = 0; !args[i].extargs_string_set[j].empty(); j++) 
                {
                    if (j > 0)
                        range_str += "/";
                    range_str += args[i].extargs_string_set[j];
                }
            }
            break;
        default:
            range_str = "/";
            break;
        }
        max_range_width = max(max_range_width, (int)range_str.length());
    }

    // �����ܿ���
    int total_width = max_name_width + max_type_width + max_default_width +max_exists_width + max_value_width + max_range_width + 5;

    // ��ͷ
    cout << string(total_width, '=') << endl;
    cout << " " << setw(max_name_width) << left << "name"<< " " << setw(max_type_width) << left << "type"<< " " << setw(max_default_width) << left << "default" << " " << setw(max_exists_width) << left << "exists"<< " " << setw(max_value_width) << left << "value"<< " " << setw(max_range_width) << left << "range/set" << endl;
    cout << string(total_width, '=') << endl;

    // ÿһ������
    for (int i = 0; args[i].extargs_type != ST_EXTARGS_TYPE::null; i++) 
    {
        string type_str;
        switch (args[i].extargs_type)
        {
        case ST_EXTARGS_TYPE::boolean: 
            type_str = "Bool";
            break;
        case ST_EXTARGS_TYPE::int_with_default:
            type_str = "IntWithDefault"; 
            break;
        case ST_EXTARGS_TYPE::int_with_error:
            type_str = "IntWithError"; 
            break;
        case ST_EXTARGS_TYPE::int_with_set_default:
            type_str = "IntSETWithDefault"; 
            break;
        case ST_EXTARGS_TYPE::int_with_set_error: 
            type_str = "IntSETWithError"; 
            break;
        case ST_EXTARGS_TYPE::double_with_default: 
            type_str = "DoubleWithDefault"; 
            break;
        case ST_EXTARGS_TYPE::double_with_error:
            type_str = "DoubleWithError"; 
            break;
        case ST_EXTARGS_TYPE::double_with_set_default:
            type_str = "DoubleSETWithDefault"; 
            break;
        case ST_EXTARGS_TYPE::double_with_set_error:
            type_str = "DoubleSETWithError"; 
            break;
        case ST_EXTARGS_TYPE::str:
            type_str = "String"; 
            break;
        case ST_EXTARGS_TYPE::str_with_set_default: 
            type_str = "StringSETWithDefault"; 
            break;
        case ST_EXTARGS_TYPE::str_with_set_error: 
            type_str = "StringSETWithError";
            break;
        case ST_EXTARGS_TYPE::ipaddr_with_default: 
            type_str = "IPAddrWithDefault";
            break;
        case ST_EXTARGS_TYPE::ipaddr_with_error: 
            type_str = "IPAddrWithError"; 
            break;
        default: 
            type_str = "Unknown";
            break;
        }

        string default_str = "/";
        switch (args[i].extargs_type) 
        {
        case ST_EXTARGS_TYPE::boolean:
            default_str = args[i].extargs_bool_default ? "true" : "false";
            break;
        case ST_EXTARGS_TYPE::int_with_default:
        case ST_EXTARGS_TYPE::int_with_set_default:
            default_str = to_string(args[i].extargs_int_default);
            break;
        case ST_EXTARGS_TYPE::int_with_error:
        case ST_EXTARGS_TYPE::int_with_set_error:
            default_str = "/";  
            break;
        case ST_EXTARGS_TYPE::double_with_default:
        case ST_EXTARGS_TYPE::double_with_set_default:
        {
            ostringstream oss;
            oss << fixed << setprecision(6) << args[i].extargs_double_default;
            default_str = oss.str();
        }
        break;
        case ST_EXTARGS_TYPE::double_with_error:
        case ST_EXTARGS_TYPE::double_with_set_error:
            default_str = "/";  
            break;
        case ST_EXTARGS_TYPE::str:
            default_str = args[i].extargs_string_default.empty() ? "/" : args[i].extargs_string_default;
            break;
        case ST_EXTARGS_TYPE::str_with_set_default:
            default_str = args[i].extargs_string_default;
            break;
        case ST_EXTARGS_TYPE::str_with_set_error:
            default_str = "/"; 
            break;
        case ST_EXTARGS_TYPE::ipaddr_with_default:
            default_str = args[i].uint_to_ip(args[i].extargs_ipaddr_default);
            break;
        case ST_EXTARGS_TYPE::ipaddr_with_error:
            default_str = "/";  
            break;
        default:
            break;
        }

        // exists��
        string exists_str = to_string(args[i].existed());

        // ��ǰֵ�ַ���
        string value_str = "/";
        if (args[i].existed()) 
        {
            switch (args[i].extargs_type) 
            {
            case ST_EXTARGS_TYPE::boolean:
                value_str = "true";
                break;
            case ST_EXTARGS_TYPE::int_with_default:
            case ST_EXTARGS_TYPE::int_with_error:
            case ST_EXTARGS_TYPE::int_with_set_default:
            case ST_EXTARGS_TYPE::int_with_set_error:
                value_str = to_string(args[i].get_int());
                break;
            case ST_EXTARGS_TYPE::double_with_default:
            case ST_EXTARGS_TYPE::double_with_error:
            case ST_EXTARGS_TYPE::double_with_set_default:
            case ST_EXTARGS_TYPE::double_with_set_error:
            {
                ostringstream oss;
                oss << fixed << setprecision(6) << args[i].get_double();
                value_str = oss.str();
            }
            break;
            case ST_EXTARGS_TYPE::str:
            case ST_EXTARGS_TYPE::str_with_set_default:
            case ST_EXTARGS_TYPE::str_with_set_error:
                value_str = args[i].get_string();
                break;
            case ST_EXTARGS_TYPE::ipaddr_with_default:
            case ST_EXTARGS_TYPE::ipaddr_with_error:
                value_str = args[i].get_str_ipaddr();
                break;
            default:
                break;
            }
        }

        // ��Χ/�����ַ���
        string range_str = "/";
        switch (args[i].extargs_type) 
        {
        case ST_EXTARGS_TYPE::int_with_default:
        case ST_EXTARGS_TYPE::int_with_error:
            range_str = "[" + to_string(args[i].extargs_int_min) + ".." +to_string(args[i].extargs_int_max) + "]";
            break;
        case ST_EXTARGS_TYPE::int_with_set_default:
        case ST_EXTARGS_TYPE::int_with_set_error:
            if (args[i].extargs_int_set)
            {
                range_str = "";
                for (int j = 0; args[i].extargs_int_set[j] != INVALID_INT_VALUE_OF_SET; j++) 
                {
                    if (j > 0) 
                        range_str += "/";
                    range_str += to_string(args[i].extargs_int_set[j]);
                }
            }
            break;
        case ST_EXTARGS_TYPE::double_with_default:
        case ST_EXTARGS_TYPE::double_with_error:
        {
            ostringstream min_oss, max_oss;
            min_oss << fixed << setprecision(6) << args[i].extargs_double_min;
            max_oss << fixed << setprecision(6) << args[i].extargs_double_max;
            range_str = "[" + min_oss.str() + ".." + max_oss.str() + "]";
        }
        break;
        case ST_EXTARGS_TYPE::double_with_set_default:
        case ST_EXTARGS_TYPE::double_with_set_error:
            if (args[i].extargs_double_set) 
            {
                range_str = "";
                for (int j = 0; fabs(args[i].extargs_double_set[j] - INVALID_DOUBLE_VALUE_OF_SET) > DOUBLE_DELTA; j++)
                {
                    if (j > 0)
                        range_str += "/";
                    ostringstream oss;
                    oss << fixed << setprecision(6) << args[i].extargs_double_set[j];
                    range_str += oss.str();
                }
            }
            break;
        case ST_EXTARGS_TYPE::str_with_set_default:
        case ST_EXTARGS_TYPE::str_with_set_error:
            if (args[i].extargs_string_set) 
            {
                range_str = "";
                for (int j = 0; !args[i].extargs_string_set[j].empty(); j++) 
                {
                    if (j > 0) 
                        range_str += "/";
                    range_str += args[i].extargs_string_set[j];
                }
            }
            break;
        default:
            range_str = "/";
            break;
        }

        // ��ӡ��
        cout << " " << setw(max_name_width) << left << args[i].get_name()<< " " << setw(max_type_width) << left << type_str<< " " << setw(max_default_width) << left << default_str<< " " << setw(max_exists_width) << left << exists_str << " " << setw(max_value_width) << left << value_str<< " " << setw(max_range_width) << left << range_str << endl;
    }

    cout << string(total_width, '=') << endl;
    return 0;
}

#endif // !ENABLE_LIB_COMMON_TOOLS