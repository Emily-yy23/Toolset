/* 2453253 ������ �Ű� */
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstring>
#include <cctype>
#include "../include/class_cft.h"
using namespace std;

// ȥ���ַ�����β�հ��ַ�
static string trim(const string& str) 
{
    size_t first = str.find_first_not_of(" \t");
    if (string::npos == first)
        return "";
    size_t last = str.find_last_not_of(" \t");
    return str.substr(first, (last - first + 1));
}

// �����ִ�Сд�Ƚ��ַ���
static bool case_insensitive_compare(const string& str1, const string& str2) 
{
    if (str1.length() != str2.length()) 
        return false;
    for (size_t i = 0; i < str1.length(); ++i) 
    {
        if (tolower(str1[i]) != tolower(str2[i])) 
            return false;
    }
    return true;
}

// ����Ƿ���ע��
static bool is_comment_line(const string& line) 
{
    string trimmed = trim(line);
    return trimmed.empty() ||trimmed[0] == '#' ||(trimmed.length() > 1 && trimmed.substr(0, 2) == "//")|| trimmed[0] == ';';
}

// �ҵ��ָ���λ��
static size_t find_separator(const string& line, BREAK_CTYPE bctype) 
{
    if (bctype == BREAK_CTYPE::Equal) 
    {
        return line.find('=');
    }
    else 
    { 
        size_t space_pos = line.find(' ');
        size_t tab_pos = line.find('\t');
        if (space_pos == string::npos) 
            return tab_pos;
        if (tab_pos == string::npos) 
            return space_pos;
        return min(space_pos, tab_pos);
    }
}

// ��IP��ַת��Ϊ32λ����
static unsigned int ip_to_uint(const string& ip) 
{
    unsigned int result = 0;
    string part;
    istringstream iss(ip);
    int shift = 24;

    while (getline(iss, part, '.')) 
    {
        int num = stoi(part);
        result |= (num << shift);
        shift -= 8;
    }
    return result;
}

// ��֤IP��ַ��ʽ
static bool is_valid_ip(const string& ip) 
{
    int count = 0;
    string part;
    istringstream iss(ip);

    while (getline(iss, part, '.'))
    {
        if (part.empty()) 
            return false;
        for (char c : part) 
        {
            if (!isdigit(c)) 
                return false;
        }
        try 
        {
            int num = stoi(part);
            if (num < 0 || num > 255) 
                return false;
        }
        catch (...) 
        {
            return false;
        }
        count++;
    }
    return count == 4;
}

/* ���������Զ��庯����ʵ�֣��Ѹ��������ݲ�ȫ�� */

//���캯��:��ȡ�����������ļ�
config_file_tools::config_file_tools(const char* const _cfgname, const enum BREAK_CTYPE _ctype)
    : cfgname(_cfgname ? _cfgname : ""),
    item_separate_character_type(_ctype),
    read_success(false)
{
    ifstream file(cfgname);
    if (!file.is_open())
    {
        return;
    }

    string current_group = "";  
    string line;
    int line_num = 0;

    while (getline(file, line)) 
    {
        line_num++;

        // 1.����г���
        if (line.length() > MAX_LINE) 
        {
            read_success = false;
            return;
        }

        // 2.ȥ����β��\r(win)
        if (!line.empty() && line[line.size() - 1] == '\r') 
        {
            line = line.substr(0, line.size() - 1);
        }

        // 3.�Ƴ�ע�Ͳ���
        size_t comment_pos = string::npos;
        comment_pos = line.find('#');
        if (comment_pos != string::npos) 
            line = line.substr(0, comment_pos);

        comment_pos = line.find("//");
        if (comment_pos != string::npos) 
            line = line.substr(0, comment_pos);

        comment_pos = line.find(';');
        if (comment_pos != string::npos)
            line = line.substr(0, comment_pos);

        // 4.ȥ����β�հ�
        line = trim(line);
        if (line.empty()) 
            continue;  

        // 5.�ж�����
        if (line[0] == '[' && line[line.length() - 1] == ']')     
        {
            string group_name = line.substr(1, line.length() - 2);
            current_group = trim(group_name);

            bool found = false;//�����������
            for (auto& group : groups) 
            {
                if (group.group_name == current_group)
                {
                    found = true;
                    break;
                }
            }

            if (!found) 
            {
                ConfigGroup new_group;
                new_group.group_name = current_group;
                groups.push_back(new_group);
            }
        }
        else 
        {  
            size_t sep_pos = string::npos;
            if (item_separate_character_type == BREAK_CTYPE::Equal) 
            {
                sep_pos = line.find('=');
            }
            else 
            {
                sep_pos = line.find_first_of(" \t");
            }

            ConfigItem item;
            item.raw_line = line;

            if (sep_pos != string::npos) 
            {
                // �зָ�������ȡ��������ֵ
                item.item_name = trim(line.substr(0, sep_pos));

                size_t value_start = sep_pos + 1;
                if (item_separate_character_type == BREAK_CTYPE::Equal) 
                {
                    while (value_start < line.length() && (line[value_start] == ' ' || line[value_start] == '\t')) 
                    {
                        value_start++;
                    }
                }
                item.item_value = line.substr(value_start);
                item.item_value = trim(item.item_value);
            }
            else 
            {
                // �޷ָ�������������Ϊ��������ֵΪ��
                item.item_name = line;
                item.item_value = "";
            }

            if (item.item_name.empty()) 
            {
                continue;
            }

            // �ҵ���Ӧ����
            bool group_found = false;
            for (auto& group : groups) 
            {
                if (group.group_name == current_group) 
                {
                    group.items.push_back(item);
                    group_found = true;
                    break;
                }
            }

            if (!group_found && current_group.empty()) 
            {
                ConfigGroup new_group;
                new_group.group_name = "";
                new_group.items.push_back(item);
                groups.push_back(new_group);
            }
        }
    }
    read_success = true;
    file.close();
}

config_file_tools::config_file_tools(const string& _cfgname, const enum BREAK_CTYPE _ctype)
    : config_file_tools(_cfgname.c_str(), _ctype)
{
}

//��������
config_file_tools::~config_file_tools() 
{
    // vector���Զ��ͷ��ڴ棬�����ֶ��ͷ�
}

//�ж϶������ļ��Ƿ�ɹ�
bool config_file_tools::is_read_succeeded() const 
{
    return read_success;
}

//���������ļ��е�������
int config_file_tools::get_all_group(vector <string>& ret) 
{
    ret.clear();
    for (const auto& group : groups) 
    {
        ret.push_back(group.group_name);
    }
    return static_cast<int>(ret.size());
}

//����ָ�����������
int config_file_tools::get_all_item(const char* const group_name, vector <string>& ret, const bool is_case_sensitive) 
{
    ret.clear();
    string target_group = group_name ? group_name : "";

    if (!target_group.empty() && target_group[0] == '[' && target_group[target_group.length() - 1] == ']')
    {
        target_group = target_group.substr(1, target_group.length() - 2);
    }
    target_group = trim(target_group);

    for (const auto& group : groups) 
    {
        bool match = false;
        if (is_case_sensitive) 
        {
            match = (group.group_name == target_group);
        }
        else 
        {
            match = case_insensitive_compare(group.group_name, target_group);
        }

        if (match) 
        {
            for (const auto& item : group.items)
            {
                if (!item.item_name.empty()) 
                {
                    ret.push_back(item.raw_line);
                }
            }
            return static_cast<int>(ret.size());
        }
    }
    return 0;
}

int config_file_tools::get_all_item(const string& group_name, vector <string>& ret, const bool is_case_sensitive) 
{
    return get_all_item(group_name.c_str(), ret, is_case_sensitive);
}

//ȡĳ���ԭʼ����
int config_file_tools::item_get_raw(const char* const group_name, const char* const item_name, string& ret, const bool group_is_case_sensitive, const bool item_is_case_sensitive)
{
    string target_group = group_name ? group_name : "";
    string target_item = item_name ? item_name : "";

    if (!target_group.empty() && target_group[0] == '[' && target_group[target_group.length() - 1] == ']') 
    {
        target_group = target_group.substr(1, target_group.length() - 2);
        target_group = trim(target_group);
    }

    for (const auto& group : groups) 
    {
        bool group_match = false;
        if (group_is_case_sensitive) 
        {
            group_match = (group.group_name == target_group);
        }
        else 
        {
            group_match = case_insensitive_compare(group.group_name, target_group);
        }

        if (group_match)
        {
            for (const auto& item : group.items) 
            {

                bool item_match = false;
                if (item_is_case_sensitive) 
                {
                    item_match = (item.item_name == target_item);
                }
                else 
                {
                    item_match = case_insensitive_compare(item.item_name, target_item);
                }

                if (item_match && !item.item_value.empty()) 
                {
                    ret = item.item_value;
                    return 1;
                }
            }
        }
    }
    return 0;
}

int config_file_tools::item_get_raw(const string& group_name, const string& item_name, string& ret,const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    return item_get_raw(group_name.c_str(), item_name.c_str(), ret, group_is_case_sensitive, item_is_case_sensitive);
}

//�ж�ĳ���Ƿ����
int config_file_tools::item_get_null(const char* const group_name, const char* const item_name,const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    string dummy;
    return item_get_raw(group_name, item_name, dummy, group_is_case_sensitive, item_is_case_sensitive);
}

int config_file_tools::item_get_null(const string& group_name, const string& item_name,const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    return item_get_null(group_name.c_str(), item_name.c_str(), group_is_case_sensitive, item_is_case_sensitive);
}

//char���Ͷ�ȡ������
int config_file_tools::item_get_char(const char* const group_name, const char* const item_name, char& value,const char* const choice_set, const char def_value,const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    string str_value;
    if (!item_get_raw(group_name, item_name, str_value, group_is_case_sensitive, item_is_case_sensitive)) //������
     {
        if (def_value != DEFAULT_CHAR_VALUE) 
        {
            value = def_value;
            return 1; 
        }
        return 0; 
    }

    if (str_value.empty()) //���ڵ�Ϊ��
    {
        if (def_value != DEFAULT_CHAR_VALUE)
        {
            value = def_value;
            return 1;
        }
        return 0;  
    }

    istringstream iss(str_value);//��ȡ��һ���ַ�
    char c;
    iss >> c;

    if (iss.fail() || iss.eof())
    {
        for (size_t i = 0; i < str_value.length(); i++) 
        {
            if (!isspace(str_value[i]))
            {
                c = str_value[i];
                iss.clear(); 
                break;
            }
        }

        if (iss.fail())
        {
            if (def_value != DEFAULT_CHAR_VALUE) 
            {
                value = def_value;
                return 1;  
            }
            return 0;  
        }
    }

    // ����Ƿ��ڿ�ѡ������
    if (choice_set != nullptr) 
    {
        bool found = false;
        for (int i = 0; choice_set[i] != '\0'; i++) 
        {
            if (choice_set[i] == c) 
            {
                found = true;
                break;
            }
        }
        if (!found) 
        {
            if (def_value != DEFAULT_CHAR_VALUE) 
            {
                value = def_value;
                return 1;  
            }
            return 0; 
        }
    }
    value = c;
    return 1;  
}

int config_file_tools::item_get_char(const string& group_name, const string& item_name, char& value,const char* const choice_set, const char def_value,const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    return item_get_char(group_name.c_str(), item_name.c_str(), value, choice_set, def_value,group_is_case_sensitive, item_is_case_sensitive);
}

//int���Ͷ�ȡ������
int config_file_tools::item_get_int(const char* const group_name, const char* const item_name, int& value,const int min_value, const int max_value, const int def_value,const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    string str_value;
    if (!item_get_raw(group_name, item_name, str_value, group_is_case_sensitive, item_is_case_sensitive)) // �����
    { 
        if (def_value != DEFAULT_INT_VALUE)
        {
            value = def_value;
            return 1;  
        }
        return 0; 
    }

    if (str_value.empty())// ����ڵ�Ϊ��
    {
        if (def_value != DEFAULT_INT_VALUE) 
        {
            value = def_value;
            return 1;  
        }
        return 0;  
    }

    istringstream iss(str_value);
    int val;
    iss >> val;

    if (iss.fail()) 
    {    
        if (def_value != DEFAULT_INT_VALUE) 
        {
            value = def_value;
            return 1;  
        }
        return 0;  
    }

    if (val >= min_value && val <= max_value)
    {
        value = val;
        return 1;  
    }
    else 
    {
        if (def_value != DEFAULT_INT_VALUE) 
        {
            value = def_value;
            return 1;  
        }
        return 0;  
    }
}

int config_file_tools::item_get_int(const string& group_name, const string& item_name, int& value, const int min_value, const int max_value, const int def_value,const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    return item_get_int(group_name.c_str(), item_name.c_str(), value, min_value, max_value, def_value, group_is_case_sensitive, item_is_case_sensitive);
}

//double���Ͷ�ȡ������
int config_file_tools::item_get_double(const char* const group_name, const char* const item_name, double& value,const double min_value, const double max_value, const double def_value,const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    string str_value;
    if (!item_get_raw(group_name, item_name, str_value, group_is_case_sensitive, item_is_case_sensitive)) 
    {
        if (def_value != DEFAULT_DOUBLE_VALUE)
        {
            value = def_value;
            return 1;  
        }
        return 0;  
    }

    if (str_value.empty()) 
    {
        if (def_value != DEFAULT_DOUBLE_VALUE) 
        {
            value = def_value;
            return 1;  
        }
        return 0;  
    }

    istringstream iss(str_value);
    double val;
    iss >> val;

    if (iss.fail()) 
    {
        if (def_value != DEFAULT_DOUBLE_VALUE) 
        {
            value = def_value;
            return 1; 
        }
        return 0;  
    }

    const double DOUBLE_EPSILON = 1e-9;
    if (val > min_value - DOUBLE_EPSILON && val < max_value + DOUBLE_EPSILON)
    {
        value = val;
        return 1;  
    }
    else 
    {
        if (def_value != DEFAULT_DOUBLE_VALUE) 
        {
            value = def_value;
            return 1;
        }
        return 0; 
    }
}

int config_file_tools::item_get_double(const string& group_name, const string& item_name, double& value,const double min_value, const double max_value, const double def_value,const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    return item_get_double(group_name.c_str(), item_name.c_str(), value, min_value, max_value, def_value,group_is_case_sensitive, item_is_case_sensitive);
}

//C�ַ������Ͷ�ȡ������
int config_file_tools::item_get_cstring(const char* const group_name, const char* const item_name, char* const value,const int str_maxlen, const char* const def_value,const bool group_is_case_sensitive, const bool item_is_case_sensitive)
{
    if (!value || str_maxlen <= 0) 
    {
        return 0;
    }

    // ��ʹ�� item_get_string ��ȡ�ַ���ֵ
    string str_value;
    if (!item_get_string(group_name, item_name, str_value, DEFAULT_STRING_VALUE,group_is_case_sensitive, item_is_case_sensitive)) 
    {
        if (def_value != DEFAULT_CSTRING_VALUE) 
        {
            size_t copy_len = min(strlen(def_value), (size_t)str_maxlen - 1);
            copy_len = min(copy_len, (size_t)MAX_STRLEN - 1);
            strncpy(value, def_value, copy_len);
            value[copy_len] = '\0';
            return 1;  
        }
        return 0;  
    }

    size_t max_copy_len = min(str_value.length(), (size_t)str_maxlen - 1);
    max_copy_len = min(max_copy_len, (size_t)MAX_STRLEN - 1);
    strncpy(value, str_value.c_str(), max_copy_len);
    value[max_copy_len] = '\0';
    return 1;  
}

int config_file_tools::item_get_cstring(const string& group_name, const string& item_name, char* const value,const int str_maxlen, const char* const def_value,const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    return item_get_cstring(group_name.c_str(), item_name.c_str(), value, str_maxlen, def_value,group_is_case_sensitive, item_is_case_sensitive);
}

//string���Ͷ�ȡ������
int config_file_tools::item_get_string(const char* const group_name, const char* const item_name, string& value,const string& def_value, const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    string str_value;
    if (!item_get_raw(group_name, item_name, str_value, group_is_case_sensitive, item_is_case_sensitive)) 
    {
        if (def_value != DEFAULT_STRING_VALUE) 
        {
            value = def_value;
            return 1; 
        }
        return 0; 
    }

    if (str_value.empty()) 
    {
        if (def_value != DEFAULT_STRING_VALUE) 
        {
            value = def_value;
            return 1;  
        }
        return 0; 
    }

    istringstream iss(str_value);
    string val;
    iss >> val;

    if (iss.fail() || val.empty()) 
    {
        if (def_value != DEFAULT_STRING_VALUE) 
        {
            value = def_value;
            return 1;  
        }
        return 0; 
    }
    value = val;
    return 1;  
}

int config_file_tools::item_get_string(const string& group_name, const string& item_name, string& value,const string& def_value, const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    return item_get_string(group_name.c_str(), item_name.c_str(), value, def_value, group_is_case_sensitive, item_is_case_sensitive);
}

//IP��ַ���Ͷ�ȡ������
int config_file_tools::item_get_ipaddr(const char* const group_name, const char* const item_name, unsigned int& value,const unsigned int& def_value, const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    string str_value;
    if (!item_get_raw(group_name, item_name, str_value, group_is_case_sensitive, item_is_case_sensitive)) {
        if (def_value != DEFAULT_IPADDR_VALUE) 
        {
            value = def_value;
            return 1;  
        }
        return 0;  
    }

    if (str_value.empty())
    {
        if (def_value != DEFAULT_IPADDR_VALUE) 
        {
            value = def_value;
            return 1; 
        }
        return 0;  
    }

    istringstream iss(str_value);
    string ip_str;
    iss >> ip_str;  

    if (iss.fail() || ip_str.empty())
    {
        if (def_value != DEFAULT_IPADDR_VALUE) 
        {
            value = def_value;
            return 1;  
        }
        return 0; 
    }

    // ��֤��ʽ ת��
    if (is_valid_ip(ip_str))
    {
        value = ip_to_uint(ip_str);
        return 1;  
    }
    else
    {
        if (def_value != DEFAULT_IPADDR_VALUE) 
        {
            value = def_value;
            return 1;  
        }
        return 0;  
    }
}

int config_file_tools::item_get_ipaddr(const string& group_name, const string& item_name, unsigned int& value,const unsigned int& def_value, const bool group_is_case_sensitive, const bool item_is_case_sensitive) 
{
    return item_get_ipaddr(group_name.c_str(), item_name.c_str(), value, def_value,group_is_case_sensitive, item_is_case_sensitive);
}