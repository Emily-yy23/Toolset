/* 2453253 �Ű� ������ */
#include "90-01-b2-pullze.h"

// ������ɫ��������
#ifndef COLOR_BLACK
#define COLOR_BLACK   0
#endif

#ifndef COLOR_WHITE  
#define COLOR_WHITE   15
#endif

#ifndef COLOR_YELLOW
#define COLOR_YELLOW  14
#endif

#ifndef COLOR_HBLUE
#define COLOR_HBLUE   153
#endif

#ifndef COLOR_HWHITE
#define COLOR_HWHITE  15  // ������ɫ��ͨ�����ɫ��ͬ
#endif

#ifndef COLOR_HRED
#define COLOR_HRED    12  // ������ɫ
#endif

void print_submission_D(GameData& game) 
{
    cct_cls();
    std::cout << "�����������С��5/10/15��: ";
    int input_size = 0;
    std::cin >> input_size;
    while (input_size != 5 && input_size != 10 && input_size != 15) 
    {
        std::cout << "�����������С��5/10/15��: ";
        std::cin >> input_size;
    }
    init_game_inner_array(game, input_size); // ֮���ʼ���ڲ�����
    cct_setfontsize("������", 32, 16);
    cct_cls();

    // ������Ϸ�߿�
    cct_setcolor(COLOR_BLACK, COLOR_WHITE);

    // ����
    int leftSpace = 2;
    int topSpace = 2;

    int start = leftSpace + 3;  // ��ĸ��û�б߿�
    // ��һ����ĸ��
    for (int i = 0; i < game.size; ++i)
    {
        cct_showch(start + 2 * i, 1, 'a' + i, COLOR_BLACK, COLOR_WHITE);
    }

    // �ϱ߽�
    cct_showstr(leftSpace, topSpace, "�X", COLOR_HWHITE, COLOR_BLACK);
    start = leftSpace + 2;
    for (int i = 0; i < game.size; i++)
    {
        cct_showstr(start + 2 * i, topSpace, "�T", COLOR_HWHITE, COLOR_BLACK);
        Sleep(20);
    }
    cct_showstr(start + game.size * 2, topSpace, "�[", COLOR_HWHITE, COLOR_BLACK);
    Sleep(20);

    // ��ʼ����
    for (int i = 0; i < game.size; i++) 
    {
        // ÿһ���ȴ�ӡ����ĸ�ͱ߿�
        cct_showch(0, 3 + i, 'A' + i, COLOR_BLACK, COLOR_WHITE);  // ����ĸ
        Sleep(20);
        cct_showstr(leftSpace, 3 + i, "�U", COLOR_HWHITE, COLOR_BLACK);
        for (int j = 0; j < game.size; j++) 
        {
            cct_showstr(leftSpace + 2 + 2 * j, 3 + i, "  ", COLOR_HWHITE, COLOR_BLACK);
            Sleep(20);
        }
        cct_showstr(leftSpace + 2 + 2 * game.size, 3 + i, "�U", COLOR_HWHITE, COLOR_BLACK);
        Sleep(20);
    }

    // �±߽�
    cct_showstr(leftSpace, topSpace + 1 + game.size, "�^", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.size; i++)
    {
        cct_showstr(start + 2 * i, topSpace + game.size + 1, "�T", COLOR_HWHITE, COLOR_BLACK);
        Sleep(20);
    }
    cct_showstr(start + 2 * game.size, topSpace + game.size + 1, "�a", COLOR_HWHITE, COLOR_BLACK);
    Sleep(20);
    // ������
    for (int i = 0; i < game.size; i++)
    {
        for (int j = 0; j < game.size; j++)
        {
            if (game.board[i][j])
            {
                cct_showstr(leftSpace + 2 + 2 * j, topSpace + 1 + i, "��", COLOR_HBLUE, COLOR_BLACK);
            }
            else 
            {
                cct_showstr(leftSpace + 2 + 2 * j, topSpace + 1 + i, "  ", COLOR_HWHITE, COLOR_WHITE);
            }
        }
        Sleep(20);
    }
    cct_gotoxy(0, topSpace + 4 + game.size);
    cct_setcolor(COLOR_BLACK, COLOR_WHITE);
}

void print_submission_E(GameData& game, bool tooltip = false)
{
    cct_cls();
    std::cout << "�����������С��5/10/15��: ";
    int input_size = 0;
    std::cin >> input_size;
    while (input_size != 5 && input_size != 10 && input_size != 15)
    {
        std::cout << "�����������С��5/10/15��: ";
        std::cin >> input_size;
    }
    init_game_inner_array(game, input_size); // ֮���ʼ���ڲ�����
    cct_setfontsize("������", 32, 16);
    cct_cls();
    if (tooltip) 
        std::cout << "���Լ���/������/�Ҽ����س��˳� \n";
    cct_setcolor(COLOR_HWHITE, COLOR_BLACK);
    int top_margin = 2;

    // ��ӡ�ϱ߽�
    int top_border_left_space = game.rowMax * 2 + 2 * 3;
    cct_showstr(top_border_left_space, top_margin, "�X", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.size; i++)
    {
        cct_showstr(top_border_left_space + 2 + 2 * i, top_margin, "�T", COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(top_border_left_space + 2 * game.size + 2, top_margin, "�[", COLOR_HWHITE, COLOR_BLACK);

    // ����ʾ
    for (int i = 0; i < game.colMax; i++)
    {
        cct_showstr(top_border_left_space, top_margin + 1 + i, "�U", COLOR_HWHITE, COLOR_BLACK);
        for (int j = 0; j < game.size; j++)
        {
            if (game.colHints[j][game.colMax - 1 - i] > 0)
            {
                if (game.colHints[j][i] >= 10) 
                    std::cout << game.colHints[j][game.colMax - 1 - i];
                else
                {
                    std::cout << " ";
                    std::cout << game.colHints[j][game.colMax - 1 - i];
                }
            }
            else 
            {
                std::cout << "  ";
            }
        }
        cct_showstr(top_border_left_space + 2 + 2 * game.size, top_margin + 1 + i, "�U", COLOR_HWHITE, COLOR_BLACK);
        std::cout << "\n";
    }
    // ��ӡ�߽�
    cct_showstr(top_border_left_space, top_margin + 1 + game.colMax, "�d", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.size; i++)
    {
        cct_showstr(top_border_left_space + 2 + 2 * i, top_margin + 1 + game.colMax, "�T", COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(top_border_left_space + 2 + 2 * game.size, top_margin + 1 + game.colMax, "�g", COLOR_HWHITE, COLOR_BLACK);

    int top_padding_xiaoxie = top_margin + 2 + game.colMax;
    // ��ӡСд��ĸ
    cct_showstr(top_border_left_space, top_padding_xiaoxie, "�U", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.size; i++) 
    {
        std::cout << " ";
        cct_showch(top_border_left_space + 3 + 2 * i, top_padding_xiaoxie, 'a' + i, COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(top_border_left_space + 2 + 2 * game.size, top_padding_xiaoxie, "�U", COLOR_HWHITE, COLOR_BLACK);
    cct_showstr(top_border_left_space, top_padding_xiaoxie + 1, "�p", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.size; i++)
    {
        cct_showstr(top_border_left_space + 2 + 2 * i, top_padding_xiaoxie + 1, "�T", COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(top_border_left_space + 2 + 2 * game.size, top_padding_xiaoxie + 1, "�g", COLOR_HWHITE, COLOR_BLACK);

    cct_showstr(0, top_padding_xiaoxie + 1, "�X", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.rowMax; i++) 
    {
        cct_showstr(2 + 2 * i, top_padding_xiaoxie + 1, "�T", COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(2 + 2 * game.rowMax, top_padding_xiaoxie + 1, "�j", COLOR_HWHITE, COLOR_BLACK);
    cct_showstr(4 + 2 * game.rowMax, top_padding_xiaoxie + 1, "�T", COLOR_HWHITE, COLOR_BLACK);

    // ��ӡ�б������
    int top_start = top_padding_xiaoxie + 2;
    for (int i = 0; i < game.size; i++)
    {
        cct_showstr(0, top_start + i, "�U", COLOR_HWHITE, COLOR_BLACK);
        // ǰ�벿��
        for (int j = game.rowMax - 1; j >= 0; j--)
        {
            if (game.rowHints[i][j] > 0)
            {
                if (game.rowHints[i][j] >= 10) std::cout << game.rowHints[i][j];
                else std::cout << " " << game.rowHints[i][j];
            }
            else
            {
                std::cout << "  ";
            }
        }
        cct_showstr(2 + 2 * game.rowMax, top_start + i, "�U", COLOR_HWHITE, COLOR_BLACK);
        // ��ӡ��ĸ
        std::cout << " ";
        cct_showch(5 + 2 * game.rowMax, top_start + i, 'A' + i, COLOR_HWHITE, COLOR_BLACK);
        cct_showstr(6 + 2 * game.rowMax, top_start + i, "�U", COLOR_HWHITE, COLOR_BLACK);

        int map_row_start = 6 + 2 * game.rowMax;

        // ��ӡ����
        for (int j = 0; j < game.size; j++)
        {
            if (game.board[i][j])
            {
                cct_showstr(map_row_start + 2 + 2 * j, top_start + i, "��", COLOR_HBLUE, COLOR_BLACK);
            }
            else 
            {
                cct_showstr(map_row_start + 2 + 2 * j, top_start + i, "  ", COLOR_HWHITE, COLOR_WHITE);
            }
        }
        cct_showstr(map_row_start + 2 + 2 * game.size, top_start + i, "�U", COLOR_HWHITE, COLOR_BLACK);
        std::cout << "\n";

    }

    // ��ӡ�ͱ߽�
    int bottom_top = top_start + game.size;
    cct_showstr(0, bottom_top, "�^", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.rowMax; i++) 
    {
        cct_showstr(2 + 2 * i, bottom_top, "�T", COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(2 + 2 * game.rowMax, bottom_top, "�m", COLOR_HWHITE, COLOR_BLACK);
    cct_showstr(4 + 2 * game.rowMax, bottom_top, "�T", COLOR_HWHITE, COLOR_BLACK);
    cct_showstr(6 + 2 * game.rowMax, bottom_top, "�m", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.size; i++) 
    {
        cct_showstr(8 + 2 * game.rowMax + 2 * i, bottom_top, "�T", COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(8 + 2 * game.rowMax + 2 * game.size, bottom_top, "�a", COLOR_HWHITE, COLOR_BLACK);

    cct_setcolor(COLOR_BLACK, COLOR_WHITE);
    cct_gotoxy(0, top_margin + 6 + game.size + game.colMax);
}

bool get_pos(int mouseX, int mouseY, GameData& game, char& row, char& col)
{
    int top_border = 3 + game.colMax + 3;
    int bottom_border = top_border + game.size - 1;

    int left_border = 4 * 2 + game.rowMax * 2;
    int right_border = left_border + game.size * 2 - 1;

    if (mouseX < left_border || mouseX > right_border) 
        return false;
    if (mouseY < top_border || mouseY > bottom_border) 
        return false;

    if (mouseY >= top_border && mouseY <= bottom_border)
    {
        int offsetY = mouseY - top_border;
        row = char('A' + offsetY);
    }

    if (mouseX >= left_border && mouseX <= right_border) 
    {
        int offsetX = (mouseX - left_border) / 2;
        col = char('a' + offsetX);
    }

    return true;
}

void print_submission_F(GameData& game) 
{
    print_submission_E(game, true);
    int display_x = 10;
    int display_y = 8 + game.size + game.colMax;
    cct_gotoxy(display_x, display_y);
    cct_enable_mouse();
    int mouseX = -1, mouseY = -1;
    int mouse_action = -1;
    int keycode1 = -1;
    int keycode2 = -1;
    while (1) 
    {
        // ��ȡ���ͼ����¼�
        int event_type = cct_read_keyboard_and_mouse(mouseX, mouseY, mouse_action, keycode1, keycode2);
        char pos_row, pos_col;
        bool right_pos = get_pos(mouseX, mouseY, game, pos_row, pos_col);

        // ����Ǽ����¼�
        if (event_type == CCT_KEYBOARD_EVENT) 
        {
            // ����Ƿ����˻س���
            if (keycode1 == 0x0D) 
            {
                cct_gotoxy(display_x, display_y);
                std::cout << "                     ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [�����س���] ";
                return;
            }
        }

        // ���������¼�
        if (event_type == CCT_MOUSE_EVENT)
        {
            // ����
            if (mouse_action == MOUSE_LEFT_BUTTON_CLICK && right_pos) 
            {
                cct_gotoxy(0, 0);
                std::cout << "                                               ";
                cct_gotoxy(0, 0);
                // ����µ�������¼�����
                std::cout << "���ڣ� " << mouseX << "�� " << mouseY << "��";


                cct_gotoxy(display_x, display_y);
                std::cout << "                     ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [�������] " << pos_row << "��" << pos_col << "��";
                return;
            }
            else if (mouse_action == MOUSE_RIGHT_BUTTON_CLICK && right_pos) 
            {
                cct_gotoxy(0, 0);
                std::cout << "                                               ";
                cct_gotoxy(0, 0);
                // ����µ�������¼�����
                std::cout << "���ڣ� " << mouseX << "�� " << mouseY << "��";

                cct_gotoxy(display_x, display_y);
                std::cout << "                     ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [�����Ҽ�] " << pos_row << "��" << pos_col << "��";
                return;
            }

            cct_gotoxy(display_x, display_y);
            std::cout << "                    ";
            cct_gotoxy(display_x, display_y);

            if (right_pos)
                std::cout << " [��ǰ���] " << pos_row << "��" << pos_col << "��";
            else   
                std::cout << " [��ǰ���] λ�÷Ƿ�";
        }
    }
}

void print_map_without_answer(GameData& game)
{
    cct_cls();
    std::cout << "�����������С��5/10/15��: ";
    int input_size = 0;
    std::cin >> input_size;
    while (input_size != 5 && input_size != 10 && input_size != 15) 
    {
        std::cout << "�����������С��5/10/15��: ";
        std::cin >> input_size;
    }
    init_game_inner_array(game, input_size); // ֮���ʼ���ڲ�����
    cct_setfontsize("������", 32, 16);
    cct_cls();
    std::cout << "���ѡ��/�Ҽ�ѡX���س��ύ��Q/q���� \n";
    // ��ӡ�ϱ߽�
    int top_border_left_space = game.rowMax * 2 + 2 * 3;
    int top_margin = 2;
    cct_showstr(top_border_left_space, top_margin, "�X", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.size; i++) 
    {
        cct_showstr(top_border_left_space + 2 + 2 * i, top_margin, "�T", COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(top_border_left_space + 2 * game.size + 2, top_margin, "�[", COLOR_HWHITE, COLOR_BLACK);

    // ����ʾ
    for (int i = 0; i < game.colMax; i++)
    {
        cct_showstr(top_border_left_space, top_margin + 1 + i, "�U", COLOR_HWHITE, COLOR_BLACK);
        for (int j = 0; j < game.size; j++)
        {
            if (game.colHints[j][game.colMax - 1 - i] > 0) 
            {
                if (game.colHints[j][i] >= 10) 
                    std::cout << game.colHints[j][game.colMax - 1 - i];
                else 
                {
                    std::cout << " ";
                    std::cout << game.colHints[j][game.colMax - 1 - i];
                }
            }
            else 
            {
                std::cout << "  ";
            }
        }
        cct_showstr(top_border_left_space + 2 + 2 * game.size, top_margin + 1 + i, "�U", COLOR_HWHITE, COLOR_BLACK);
        std::cout << "\n";
    }
    // ��ӡ�߽�
    cct_showstr(top_border_left_space, top_margin + 1 + game.colMax, "�d", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.size; i++)
    {
        cct_showstr(top_border_left_space + 2 + 2 * i, top_margin + 1 + game.colMax, "�T", COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(top_border_left_space + 2 + 2 * game.size, top_margin + 1 + game.colMax, "�g", COLOR_HWHITE, COLOR_BLACK);

    int top_padding_xiaoxie = top_margin + 2 + game.colMax;
    // ��ӡСд��ĸ
    cct_showstr(top_border_left_space, top_padding_xiaoxie, "�U", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.size; i++) 
    {
        std::cout << " ";
        cct_showch(top_border_left_space + 3 + 2 * i, top_padding_xiaoxie, 'a' + i, COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(top_border_left_space + 2 + 2 * game.size, top_padding_xiaoxie, "�U", COLOR_HWHITE, COLOR_BLACK);
    cct_showstr(top_border_left_space, top_padding_xiaoxie + 1, "�p", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.size; i++) 
    {
        cct_showstr(top_border_left_space + 2 + 2 * i, top_padding_xiaoxie + 1, "�T", COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(top_border_left_space + 2 + 2 * game.size, top_padding_xiaoxie + 1, "�g", COLOR_HWHITE, COLOR_BLACK);

    cct_showstr(0, top_padding_xiaoxie + 1, "�X", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.rowMax; i++)
    {
        cct_showstr(2 + 2 * i, top_padding_xiaoxie + 1, "�T", COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(2 + 2 * game.rowMax, top_padding_xiaoxie + 1, "�j", COLOR_HWHITE, COLOR_BLACK);
    cct_showstr(4 + 2 * game.rowMax, top_padding_xiaoxie + 1, "�T", COLOR_HWHITE, COLOR_BLACK);

    // ��ӡ�б������
    int top_start = top_padding_xiaoxie + 2;
    for (int i = 0; i < game.size; i++)
    {
        cct_showstr(0, top_start + i, "�U", COLOR_HWHITE, COLOR_BLACK);
        // ǰ�벿��
        for (int j = game.rowMax - 1; j >= 0; j--)
        {
            if (game.rowHints[i][j] > 0)
            {
                if (game.rowHints[i][j] >= 10) 
                    std::cout << game.rowHints[i][j];
                else
                    std::cout << " " << game.rowHints[i][j];
            }
            else
            {
                std::cout << "  ";
            }
        }
        cct_showstr(2 + 2 * game.rowMax, top_start + i, "�U", COLOR_HWHITE, COLOR_BLACK);
        // ��ӡ��ĸ
        std::cout << " ";
        cct_showch(5 + 2 * game.rowMax, top_start + i, 'A' + i, COLOR_HWHITE, COLOR_BLACK);
        cct_showstr(6 + 2 * game.rowMax, top_start + i, "�U", COLOR_HWHITE, COLOR_BLACK);

        int map_row_start = 6 + 2 * game.rowMax;

        // ��ӡ����
        for (int j = 0; j < game.size; j++)
        {
            cct_showstr(map_row_start + 2 + 2 * j, top_start + i, "  ", COLOR_HWHITE, COLOR_WHITE);
        }
        cct_showstr(map_row_start + 2 + 2 * game.size, top_start + i, "�U", COLOR_HWHITE, COLOR_BLACK);
        std::cout << "\n";

    }

    // ��ӡ�ͱ߽�
    int bottom_top = top_start + game.size;
    cct_showstr(0, bottom_top, "�^", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.rowMax; i++) 
    {
        cct_showstr(2 + 2 * i, bottom_top, "�T", COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(2 + 2 * game.rowMax, bottom_top, "�m", COLOR_HWHITE, COLOR_BLACK);
    cct_showstr(4 + 2 * game.rowMax, bottom_top, "�T", COLOR_HWHITE, COLOR_BLACK);
    cct_showstr(6 + 2 * game.rowMax, bottom_top, "�m", COLOR_HWHITE, COLOR_BLACK);
    for (int i = 0; i < game.size; i++) 
    {
        cct_showstr(8 + 2 * game.rowMax + 2 * i, bottom_top, "�T", COLOR_HWHITE, COLOR_BLACK);
    }
    cct_showstr(8 + 2 * game.rowMax + 2 * game.size, bottom_top, "�a", COLOR_HWHITE, COLOR_BLACK);

    cct_setcolor(COLOR_BLACK, COLOR_WHITE);
    cct_gotoxy(0, top_margin + 6 + game.size + game.colMax);
}

void print_submission_G(GameData& game)
{
    print_map_without_answer(game);
    int display_x = 10;
    int display_y = 8 + game.size + game.colMax;
    cct_gotoxy(display_x, display_y);
    cct_enable_mouse();
    int mouseX = -1, mouseY = -1;
    int mouse_action = -1;
    int keycode1 = -1;
    int keycode2 = -1;
    while (1) 
    {
        // ��ȡ���ͼ����¼�
        int event_type = cct_read_keyboard_and_mouse(mouseX, mouseY, mouse_action, keycode1, keycode2);
        char pos_row, pos_col;
        bool right_pos = get_pos(mouseX, mouseY, game, pos_row, pos_col);

        // ����Ǽ����¼�
        if (event_type == CCT_KEYBOARD_EVENT) 
        {
            // ����Ƿ����˻س���
            if (keycode1 == 0x0D) 
            {
                cct_gotoxy(display_x, display_y);
                std::cout << "                                                    ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [�����س���] ";
                Sleep(100);
                // �����ύ �ɹ���return ʧ����continue
                cct_gotoxy(display_x, display_y);
                std::cout << "                                                      ";
                cct_gotoxy(display_x, display_y);
                if (!check_answer(game)) 
                {
                    Sleep(500);
                    cct_gotoxy(display_x, display_y);
                    std::cout << "                                                   ";
                    cct_gotoxy(display_x, display_y);
                    if (right_pos) std::cout << " [��ǰ���] " << pos_row << "��" << pos_col << "��";
                    else   std::cout << " [��ǰ���] λ�÷Ƿ�";
                    continue;
                }
                else 
                {
                    cct_gotoxy(display_x, display_y);
                    std::cout << "                                                ";
                    cct_gotoxy(display_x, display_y);
                    std::cout << " [�ύ�ɹ�] ";
                    return;
                }

            }
            // ����Ƿ����� Q �� q ��
            if (keycode1 == 0x51 || keycode1 == 0x71)
            { // Q �� q �� ASCII ��
                cct_gotoxy(display_x, display_y);
                std::cout << "                     ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [����Q/q����Ϸ����] ";
                return; // �˳�����
            }
        }

        // ���������¼�
        if (event_type == CCT_MOUSE_EVENT) 
        {
            // �����ӡ��
            int top_border = 3 + game.colMax + 3;
            int left_border = 4 * 2 + game.rowMax * 2;
            // ����
            if (mouse_action == MOUSE_LEFT_BUTTON_CLICK && right_pos)
            {
                cct_gotoxy(display_x, display_y);
                std::cout << "                     ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [�������] " << pos_row << "��" << pos_col << "��";
                int row_index = int(pos_row - 'A');
                int col_index = int(pos_col - 'a');
                int circle_y = top_border + row_index;
                int circle_x = left_border + col_index * 2;
                // ��X��
                if (game.marked[row_index][col_index])
                {
                    game.marked[row_index][col_index] = !game.marked[row_index][col_index];
                    game.operations[row_index][col_index] = !game.operations[row_index][col_index];
                    cct_showstr(circle_x, circle_y, "��", COLOR_HBLUE, COLOR_BLACK);
                }
                else
                {
                    game.operations[row_index][col_index] = !game.operations[row_index][col_index];
                    if (game.operations[row_index][col_index]) 
                        cct_showstr(circle_x, circle_y, "��", COLOR_HBLUE, COLOR_BLACK);
                    else 
                        cct_showstr(circle_x, circle_y, "  ", COLOR_HWHITE, COLOR_BLACK);
                }
                cct_gotoxy(display_x, display_y);
                cct_setcolor(COLOR_BLACK, COLOR_WHITE);
            }
            else if (mouse_action == MOUSE_RIGHT_BUTTON_CLICK && right_pos) 
            {
                cct_gotoxy(display_x, display_y);
                std::cout << "                     ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [�����Ҽ�] " << pos_row << "��" << pos_col << "��";
                int row_index = int(pos_row - 'A');
                int col_index = int(pos_col - 'a');
                int circle_y = top_border + row_index;
                int circle_x = left_border + col_index * 2;
                // ��O��
                if (game.operations[row_index][col_index]) 
                {
                    game.operations[row_index][col_index] = !game.operations[row_index][col_index];
                    game.marked[row_index][col_index] = !game.marked[row_index][col_index];
                    cct_showstr(circle_x, circle_y, "��", COLOR_HRED, COLOR_BLACK);
                }
                else 
                {
                    game.marked[row_index][col_index] = !game.marked[row_index][col_index];
                    if (game.marked[row_index][col_index])
                        cct_showstr(circle_x, circle_y, "��", COLOR_HRED, COLOR_BLACK);
                    else 
                        cct_showstr(circle_x, circle_y, "  ", COLOR_HWHITE, COLOR_BLACK);
                }
                cct_gotoxy(display_x, display_y);
                cct_setcolor(COLOR_BLACK, COLOR_WHITE);
            }


            Sleep(200);
            cct_gotoxy(display_x, display_y);
            std::cout << "                                                        ";
            cct_gotoxy(display_x, display_y);

            if (right_pos) 
                std::cout << " [��ǰ���] " << pos_row << "��" << pos_col << "��";
            else   
                std::cout << " [��ǰ���] λ�÷Ƿ�";
        }
    }
}

/*	   ˫�߿�ܣ�"�X", "�^", "�[", "�a", "�T", "�U", "�j", "�m", "�d", "�g", "�p"
       ���߿�ܣ�"��", "��", "��", "��", "��", "��", "��", "��", "��", "��", "��"
       ��˫����: "�V", "�\", "�Y", "�_", "�T", "��", "�h", "�k", "�b", "�e", "�n"
       �ᵥ��˫��"�W", "�]", "�Z", "�`", "��", "�U", "�i", "�l", "�c", "�f", "�o"
*/

void print_0_with_border(int row_index, int col_index) 
{
    // ����Բ   ����left   ����top
    cct_showstr(col_index, row_index, "��", COLOR_HBLUE, COLOR_BLACK);
    // topleft
    cct_showstr(col_index - 2, row_index - 1, "�X", COLOR_HBLUE, COLOR_BLACK);
    // left
    cct_showstr(col_index - 2, row_index, "�U", COLOR_HBLUE, COLOR_BLACK);
    // bottomleft
    cct_showstr(col_index - 2, row_index + 1, "�^", COLOR_HBLUE, COLOR_BLACK);
    // top 
    cct_showstr(col_index, row_index - 1, "�T", COLOR_HBLUE, COLOR_BLACK);
    // bottom
    cct_showstr(col_index, row_index + 1, "�T", COLOR_HBLUE, COLOR_BLACK);
    // topright
    cct_showstr(col_index + 2, row_index - 1, "�[", COLOR_HBLUE, COLOR_BLACK);
    // right
    cct_showstr(col_index + 2, row_index, "�U", COLOR_HBLUE, COLOR_BLACK);
    // bottomright
    cct_showstr(col_index + 2, row_index + 1, "�a", COLOR_HBLUE, COLOR_BLACK);
}
void print_0_not_choose(int row_index, int col_index)
{
    // ����Բ   ����left   ����top
    cct_showstr(col_index, row_index, "��", COLOR_WHITE, COLOR_BLACK);
    // topleft
    cct_showstr(col_index - 2, row_index - 1, "�X", COLOR_WHITE, COLOR_BLACK);
    // left
    cct_showstr(col_index - 2, row_index, "�U", COLOR_WHITE, COLOR_BLACK);
    // bottomleft
    cct_showstr(col_index - 2, row_index + 1, "�^", COLOR_WHITE, COLOR_BLACK);
    // top 
    cct_showstr(col_index, row_index - 1, "�T", COLOR_WHITE, COLOR_BLACK);
    // bottom
    cct_showstr(col_index, row_index + 1, "�T", COLOR_WHITE, COLOR_BLACK);
    // topright
    cct_showstr(col_index + 2, row_index - 1, "�[", COLOR_WHITE, COLOR_BLACK);
    // right
    cct_showstr(col_index + 2, row_index, "�U", COLOR_WHITE, COLOR_BLACK);
    // bottomright
    cct_showstr(col_index + 2, row_index + 1, "�a", COLOR_WHITE, COLOR_BLACK);
}

void print_0_wrong_choose(int row_index, int col_index)
{
    // ����Բ   ����left   ����top
    cct_showstr(col_index, row_index, "��", COLOR_HRED, COLOR_BLACK);
    // topleft
    cct_showstr(col_index - 2, row_index - 1, "�X", COLOR_HRED, COLOR_BLACK);
    // left
    cct_showstr(col_index - 2, row_index, "�U", COLOR_HRED, COLOR_BLACK);
    // bottomleft
    cct_showstr(col_index - 2, row_index + 1, "�^", COLOR_HRED, COLOR_BLACK);
    // top 
    cct_showstr(col_index, row_index - 1, "�T", COLOR_HRED, COLOR_BLACK);
    // bottom
    cct_showstr(col_index, row_index + 1, "�T", COLOR_HRED, COLOR_BLACK);
    // topright
    cct_showstr(col_index + 2, row_index - 1, "�[", COLOR_HRED, COLOR_BLACK);
    // right
    cct_showstr(col_index + 2, row_index, "�U", COLOR_HRED, COLOR_BLACK);
    // bottomright
    cct_showstr(col_index + 2, row_index + 1, "�a", COLOR_HRED, COLOR_BLACK);
}

void print_x_wrong_marked(int row_index, int col_index) 
{
    // ����Բ   ����left   ����top
    cct_showstr(col_index, row_index, "��", COLOR_HBLUE, COLOR_BLACK);
    // topleft
    cct_showstr(col_index - 2, row_index - 1, "�X", COLOR_HBLUE, COLOR_BLACK);
    // left
    cct_showstr(col_index - 2, row_index, "�U", COLOR_HBLUE, COLOR_BLACK);
    // bottomleft
    cct_showstr(col_index - 2, row_index + 1, "�^", COLOR_HBLUE, COLOR_BLACK);
    // top 
    cct_showstr(col_index, row_index - 1, "�T", COLOR_HBLUE, COLOR_BLACK);
    // bottom
    cct_showstr(col_index, row_index + 1, "�T", COLOR_HBLUE, COLOR_BLACK);
    // topright
    cct_showstr(col_index + 2, row_index - 1, "�[", COLOR_HBLUE, COLOR_BLACK);
    // right
    cct_showstr(col_index + 2, row_index, "�U", COLOR_HBLUE, COLOR_BLACK);
    // bottomright
    cct_showstr(col_index + 2, row_index + 1, "�a", COLOR_HBLUE, COLOR_BLACK);
}

void print_x_with_border(int row_index, int col_index) 
{
    // ����Բ   ����left   ����top
    cct_showstr(col_index, row_index, "��", COLOR_HRED, COLOR_BLACK);
    // topleft
    cct_showstr(col_index - 2, row_index - 1, "�X", COLOR_HRED, COLOR_BLACK);
    // left
    cct_showstr(col_index - 2, row_index, "�U", COLOR_HRED, COLOR_BLACK);
    // bottomleft
    cct_showstr(col_index - 2, row_index + 1, "�^", COLOR_HRED, COLOR_BLACK);
    // top 
    cct_showstr(col_index, row_index - 1, "�T", COLOR_HRED, COLOR_BLACK);
    // bottom
    cct_showstr(col_index, row_index + 1, "�T", COLOR_HRED, COLOR_BLACK);
    // topright
    cct_showstr(col_index + 2, row_index - 1, "�[", COLOR_HRED, COLOR_BLACK);
    // right
    cct_showstr(col_index + 2, row_index, "�U", COLOR_HRED, COLOR_BLACK);
    // bottomright
    cct_showstr(col_index + 2, row_index + 1, "�a", COLOR_HRED, COLOR_BLACK);
}

void clear_item_with_border(int row_index, int col_index)
{
    // ����Բ   ����left   ����top
    cct_showstr(col_index, row_index, "  ", COLOR_HWHITE, COLOR_BLACK);
    // topleft
    cct_showstr(col_index - 2, row_index - 1, "  ", COLOR_HWHITE, COLOR_BLACK);
    // left
    cct_showstr(col_index - 2, row_index, "  ", COLOR_HWHITE, COLOR_BLACK);
    // bottomleft
    cct_showstr(col_index - 2, row_index + 1, "  ", COLOR_HWHITE, COLOR_BLACK);
    // top 
    cct_showstr(col_index, row_index - 1, "  ", COLOR_HWHITE, COLOR_BLACK);
    // bottom
    cct_showstr(col_index, row_index + 1, "  ", COLOR_HWHITE, COLOR_BLACK);
    // topright
    cct_showstr(col_index + 2, row_index - 1, "  ", COLOR_HWHITE, COLOR_BLACK);
    // right
    cct_showstr(col_index + 2, row_index, "  ", COLOR_HWHITE, COLOR_BLACK);
    // bottomright
    cct_showstr(col_index + 2, row_index + 1, "  ", COLOR_HWHITE, COLOR_BLACK);
}


void print_map_with_border(GameData& game, bool with_hint, bool show_answer)
{
    if (game.size == 5)
    {
        cct_setfontsize("������", 24, 12);
    }
    else if (game.size == 10)
    {
        cct_setfontsize("������", 16, 8);
    }
    else cct_setfontsize("������", 12, 6);

    int top_margin = 2;
    if (!with_hint) 
    {
        // ��һ��Сд��ĸ
        int left_space = 3 * 2;
        for (int i = 0; i < game.size; i++)
        {
            cct_showch(left_space + 4 * 2 * i, top_margin, char('a' + i), COLOR_BLACK, COLOR_WHITE);
        }
        //�ϱ߽�
        left_space = 2;
        cct_showstr(left_space, top_margin + 1, "�X", COLOR_HWHITE, COLOR_BLACK);

        for (int i = 0; i < game.size; i++) 
        {
            left_space = 4 + i * 8;
            for (int j = 0; j < 3; j++) 
            {
                cct_showstr(left_space + j * 2, top_margin + 1, "�T", COLOR_HWHITE, COLOR_BLACK);
            }
            if (i != game.size - 1) 
                cct_showstr(left_space + 6, top_margin + 1, "�j", COLOR_HWHITE, COLOR_BLACK);
            else
                cct_showstr(left_space + 6, top_margin + 1, "�[", COLOR_HWHITE, COLOR_BLACK);
        }

        top_margin = 4;

        // ��ӡÿһ��
        for (int i = 0; i < game.size; i++) 
        {  // ����ÿһ����ĸ
            // ÿһ����д��ĸ����Ӧ����
            for (int j = 0; j < 4; j++) 
            {
                top_margin = 4 + i * 4 + j;
                if (j == 1) 
                {
                    cct_showch(0, top_margin, char('A' + i), COLOR_BLACK, COLOR_WHITE);
                }
                for (int k = 0; k < game.size; k++) 
                {
                    left_space = 2 + k * 8;
                    if (i != game.size - 1)
                    {
                        if (j != 3) 
                            cct_showstr(left_space, top_margin, "�U", COLOR_HWHITE, COLOR_BLACK);
                        if (j == 3 && k == 0) 
                            cct_showstr(left_space, top_margin, "�d", COLOR_HWHITE, COLOR_BLACK);
                        if (j == 3 && k != 0) 
                            cct_showstr(left_space, top_margin, "�p", COLOR_HWHITE, COLOR_BLACK);
                    }
                    else 
                    {
                        if (j != 3) 
                            cct_showstr(left_space, top_margin, "�U", COLOR_HWHITE, COLOR_BLACK);
                        if (j == 3 && k == 0) 
                            cct_showstr(left_space, top_margin, "�^", COLOR_HWHITE, COLOR_BLACK);
                        if (j == 3 && k != 0) 
                            cct_showstr(left_space, top_margin, "�m", COLOR_HWHITE, COLOR_BLACK);
                    }
                    for (int m = 1; m <= 4; m++) 
                    {
                        if (j == 3) 
                            cct_showstr(left_space + 2 * m, top_margin, "�T", COLOR_HWHITE, COLOR_BLACK);
                        else 
                            cct_showstr(left_space + 2 * m, top_margin, "  ", COLOR_HWHITE, COLOR_BLACK);
                    }
                }
                if (i != game.size - 1) 
                {
                    if (j == 3) 
                        cct_showstr(left_space + 8, top_margin, "�g", COLOR_HWHITE, COLOR_BLACK);
                    else 
                        cct_showstr(left_space + 8, top_margin, "�U", COLOR_HWHITE, COLOR_BLACK);
                }
                else
                {
                    if (j == 3) 
                        cct_showstr(left_space + 8, top_margin, "�a", COLOR_HWHITE, COLOR_BLACK);
                    else 
                        cct_showstr(left_space + 8, top_margin, "�U", COLOR_HWHITE, COLOR_BLACK);
                }
            }
        }

        // ��ӡ����
        if (show_answer)
        {
            for (int i = 1; i <= game.size; i++) 
            {
                for (int j = 1; j <= game.size; j++) 
                {
                    if (game.board[i][j]) 
                    {
                        // ������������
                        int row_index = 1 + 4 * i;
                        int col_index = 4 * j * 2 - 2;
                        print_0_with_border(row_index, col_index);
                    }
                }
            }
        }
    }

    else 
    {
        // ��ʾ���ϱ߽�
        int left_space = 3 * 2 + 2 * game.rowMax;
        top_margin = 2;
        cct_showstr(left_space, top_margin + 1, "�X", COLOR_HWHITE, COLOR_BLACK);
        left_space += 2;
        for (int i = 0; i < game.size; i++)
        {
            for (int j = 0; j < 4; j++) 
            {
                if (i != game.size - 1) 
                    cct_showstr(left_space + j * 2, top_margin + 1, "�T", COLOR_HWHITE, COLOR_BLACK);
                else
                {
                    if (j == 3) 
                        cct_showstr(left_space + j * 2, top_margin + 1, "�[", COLOR_HWHITE, COLOR_BLACK);
                    else 
                        cct_showstr(left_space + j * 2, top_margin + 1, "�T", COLOR_HWHITE, COLOR_BLACK);
                }
            }
            left_space += 8;
        }
        // ��ӡ����ʾ
        top_margin = top_margin + 2;
        for (int i = 0; i < game.colMax; i++) 
        {
            left_space = 3 * 2 + 2 * game.rowMax;
            cct_showstr(left_space, top_margin + i, "�U", COLOR_HWHITE, COLOR_BLACK);
            left_space += 2;
            for (int j = 0; j < game.size; j++)
            {
                if (game.colHints[j][game.colMax - 1 - i] > 0)
                {
                    if (game.colHints[j][game.colMax - 1 - i] < 10) 
                    {
                        for (int k = 0; k < 4; k++) 
                        {
                            if (k != 1) 
                                cct_showstr(left_space + 2 * k, top_margin + i, "  ", COLOR_HWHITE, COLOR_BLACK);
                            else
                            {
                                cct_showint(left_space + 2 * k, top_margin + i, game.colHints[j][game.colMax - 1 - i], COLOR_HWHITE, COLOR_BLACK);
                                cct_showstr(left_space + 2 * k + 1, top_margin + i, " ", COLOR_HWHITE, COLOR_BLACK);
                            }
                        }
                    }
                    else 
                    {
                        for (int k = 0; k < 4; k++) 
                        {
                            if (k != 1)  
                                cct_showstr(left_space + 2 * k, top_margin + i, "  ", COLOR_HWHITE, COLOR_BLACK);
                            else  
                                cct_showint(left_space + 2 * k, top_margin + i, game.colHints[j][game.colMax - 1 - i], COLOR_HWHITE, COLOR_BLACK);
                        }
                    }

                }
                else 
                {
                    for (int k = 0; k < 4; k++)  
                        cct_showstr(left_space + 2 * k, top_margin + i, "  ", COLOR_HWHITE, COLOR_BLACK);
                }
                if (j == game.size - 1) 
                    cct_showstr(left_space + 2 * 3, top_margin + i, "�U", COLOR_HWHITE, COLOR_BLACK);
                left_space += 8;
            }
        }
        // ��ӡ�ָ���
        top_margin = top_margin + game.colMax;
        left_space = 3 * 2 + 2 * game.rowMax;
        cct_showstr(left_space, top_margin, "�d", COLOR_HWHITE, COLOR_BLACK);
        left_space += 2;
        for (int i = 0; i < game.size; i++) 
        {

            for (int j = 0; j < 4; j++)
            {
                if (i == game.size - 1 && j == 3) 
                    cct_showstr(left_space + 2 * j, top_margin, "�g", COLOR_HWHITE, COLOR_BLACK);
                else
                    cct_showstr(left_space + 2 * j, top_margin, "�T", COLOR_HWHITE, COLOR_BLACK);
            }
            left_space += 8;
        }

        // Сд��ĸ��
        top_margin += 1;
        left_space = 3 * 2 + 2 * game.rowMax;
        cct_showstr(left_space, top_margin, "�U", COLOR_HWHITE, COLOR_BLACK);
        left_space += 2;
        for (int i = 0; i < game.size; i++)
        {
            for (int j = 0; j < 4; j++) 
            {
                if (j != 1) 
                    cct_showstr(left_space + 2 * j, top_margin, "  ", COLOR_HWHITE, COLOR_BLACK);
                else 
                {
                    cct_showch(left_space + 2 * j, top_margin, char('a' + i), COLOR_HWHITE, COLOR_BLACK);
                    cct_showstr(left_space + 2 * j + 1, top_margin, " ", COLOR_HWHITE, COLOR_BLACK);
                }
                if (i == game.size - 1 && j == 3)  
                    cct_showstr(left_space + 2 * j, top_margin, "�U", COLOR_HWHITE, COLOR_BLACK);
            }
            left_space += 8;
        }

        // �ָ���
        top_margin += 1;
        left_space = 0;
        cct_showstr(left_space, top_margin, "�X", COLOR_HWHITE, COLOR_BLACK);
        for (int i = 0; i < game.rowMax; ++i) 
        {
            left_space += 2;
            cct_showstr(left_space, top_margin, "�T", COLOR_HWHITE, COLOR_BLACK);
        }
        left_space += 2;
        cct_showstr(left_space, top_margin, "�j", COLOR_HWHITE, COLOR_BLACK);
        left_space += 2;
        cct_showstr(left_space, top_margin, "�T", COLOR_HWHITE, COLOR_BLACK);
        left_space += 2;
        cct_showstr(left_space, top_margin, "�p", COLOR_HWHITE, COLOR_BLACK);
        left_space += 2;
        for (int i = 0; i < game.size; i++) 
        {
            for (int j = 0; j < 4; j++)
            {
                if (j != 3)
                    cct_showstr(left_space + 2 * j, top_margin, "�T", COLOR_HWHITE, COLOR_BLACK);
                else 
                    cct_showstr(left_space + 2 * j, top_margin, "�j", COLOR_HWHITE, COLOR_BLACK);

                if (i == game.size - 1 && j == 3) 
                    cct_showstr(left_space + 2 * j, top_margin, "�g", COLOR_HWHITE, COLOR_BLACK);
            }
            left_space += 8;
        }
        top_margin += 1;

        // ��ӡÿһ������
        for (int i = 0; i < game.size; i++) 
        {
            for (int j = 0; j < 4; j++)
            {
                left_space = 0;
                // ������ʾ��
                if (j == 0 || j == 2) 
                {
                    cct_showstr(left_space, top_margin + j, "�U", COLOR_HWHITE, COLOR_BLACK);
                    for (int k = 0; k < game.rowMax; k++) 
                    {
                        left_space += 2;
                        cct_showstr(left_space, top_margin + j, "  ", COLOR_HWHITE, COLOR_BLACK);
                    }
                    left_space += 2;
                    cct_showstr(left_space, top_margin + j, "�U  �U", COLOR_HWHITE, COLOR_BLACK);
                    left_space += 6;
                    for (int k = 0; k < game.size; k++) 
                    {
                        cct_showstr(left_space, top_margin + j, "      �U", COLOR_HWHITE, COLOR_BLACK);
                        left_space += 8;
                    }
                }
                // ��ʾ��
                else if (j == 1) 
                {
                    cct_showstr(left_space, top_margin + j, "�U", COLOR_HWHITE, COLOR_BLACK);
                    for (int k = game.rowMax - 1; k >= 0; k--)
                    {
                        left_space += 2;
                        if (game.rowHints[i][k] > 0)
                        {
                            if (game.rowHints[i][k] >= 10) 
                                std::cout << game.rowHints[i][k];
                            else 
                            {
                                std::cout << game.rowHints[i][k] << " ";
                            }
                        }
                        else
                        {
                            cct_showstr(left_space, top_margin + j, "  ", COLOR_HWHITE, COLOR_BLACK);
                        }
                    }
                    left_space += 2;
                    cct_showstr(left_space, top_margin + j, "�U", COLOR_HWHITE, COLOR_BLACK);
                    left_space += 2;
                    cct_showch(left_space, top_margin + j, char('A' + i), COLOR_HWHITE, COLOR_BLACK);
                    cct_showstr(left_space + 1, top_margin + j, " ", COLOR_HWHITE, COLOR_BLACK);
                    left_space += 2;
                    for (int k = 0; k < game.size; k++)
                    {
                        cct_showstr(left_space, top_margin + j, "�U      ", COLOR_HWHITE, COLOR_BLACK);
                        left_space += 8;
                    }
                    cct_showstr(left_space, top_margin + j, "�U", COLOR_HWHITE, COLOR_BLACK);
                }
                else 
                {
                    if (i != game.size - 1) 
                    {
                        cct_showstr(left_space, top_margin + j, "�U", COLOR_HWHITE, COLOR_BLACK);
                        for (int k = 0; k < game.rowMax; k++) 
                        {
                            left_space += 2;
                            cct_showstr(left_space, top_margin + j, "  ", COLOR_HWHITE, COLOR_BLACK);
                        }
                        left_space += 2;
                        cct_showstr(left_space, top_margin + j, "�U  ", COLOR_HWHITE, COLOR_BLACK);
                        left_space += 4;
                        for (int k = 0; k < game.size; k++) 
                        {
                            if (k == 0) 
                                cct_showstr(left_space, top_margin + j, "�d�T�T�T", COLOR_HWHITE, COLOR_BLACK);
                            else 
                                cct_showstr(left_space, top_margin + j, "�p�T�T�T", COLOR_HWHITE, COLOR_BLACK);
                            left_space += 8;
                        }
                        cct_showstr(left_space, top_margin + j, "�g", COLOR_HWHITE, COLOR_BLACK);
                    }
                    else 
                    {
                        // �ױ߽�
                        cct_showstr(left_space, top_margin + j, "�^", COLOR_HWHITE, COLOR_BLACK);
                        for (int k = 0; k < game.rowMax; k++) 
                        {
                            left_space += 2;
                            cct_showstr(left_space, top_margin + j, "�T", COLOR_HWHITE, COLOR_BLACK);
                        }
                        left_space += 2;
                        cct_showstr(left_space, top_margin + j, "�m�T", COLOR_HWHITE, COLOR_BLACK);
                        left_space += 4;
                        for (int k = 0; k < game.size; k++) 
                        {
                            cct_showstr(left_space, top_margin + j, "�m�T�T�T", COLOR_HWHITE, COLOR_BLACK);
                            left_space += 8;
                        }
                        cct_showstr(left_space, top_margin + j, "�a", COLOR_HWHITE, COLOR_BLACK);
                    }
                }
            }
            top_margin += 4;
        }
        //��ӡ����
        if (show_answer)
        {
            for (int i = 0; i < game.size; i++) 
            {
                for (int j = 0; j < game.size; j++) 
                {
                    if (game.board[i][j]) 
                    {
                        // ������������
                        int row_index = 2 + 6 + game.colMax + 4 * i;
                        int col_index = 5 * 2 + game.rowMax * 2 + 4 * j * 2;
                        print_0_with_border(row_index, col_index);
                    }
                }
            }
        }

    }


    cct_setcolor(COLOR_BLACK, COLOR_WHITE);
    cct_gotoxy(0, top_margin + 1);
}

void print_submission_H(GameData& game) 
{
    cct_cls();
    std::cout << "�����������С��5/10/15��: ";
    int input_size = 0;
    std::cin >> input_size;
    while (input_size != 5 && input_size != 10 && input_size != 15)
    {
        std::cout << "�����������С��5/10/15��: ";
        std::cin >> input_size;
    }
    init_game_inner_array(game, input_size); // ֮���ʼ���ڲ�����
    cct_setfontsize("������", 32, 16);
    cct_cls();
    print_map_with_border(game, false, true);
}
void print_submission_I(GameData& game)
{
    cct_cls();
    std::cout << "�����������С��5/10/15��: ";
    int input_size = 0;
    std::cin >> input_size;
    while (input_size != 5 && input_size != 10 && input_size != 15) 
    {
        std::cout << "�����������С��5/10/15��: ";
        std::cin >> input_size;
    }
    init_game_inner_array(game, input_size); // ֮���ʼ���ڲ�����
    cct_setfontsize("������", 32, 16);
    cct_cls();
    print_map_with_border(game, true, true);
}

bool get_pos_with_border(int mouseX, int mouseY, GameData& game, char& row, char& col) 
{
    int top_border = 2 + 4 + game.colMax;
    int bottom_border = top_border + 4 * game.size;
    int left_border = 4 * 2 + game.rowMax * 2 - 1;
    int right_border = left_border + 4 * game.size * 2;

    if (mouseX <= left_border || mouseX >= right_border) 
        return false;
    if (mouseY <= top_border || mouseY >= bottom_border) 
        return false;

    int offset_x = mouseX - left_border;
    int offset_y = mouseY - top_border;

    if ((offset_x % 8 == 0) || (offset_x % 8 == 7)) 
        return false;
    if (offset_y % 4 == 0) 
        return false;

    row = char('A' + (offset_y / 4));
    col = char('a' + (offset_x / 8));

    return true;
}

void print_submission_J(GameData& game) 
{
    cct_cls();
    std::cout << "�����������С��5/10/15��: ";
    int input_size = 0;
    std::cin >> input_size;
    while (input_size != 5 && input_size != 10 && input_size != 15)
    {
        std::cout << "�����������С��5/10/15��: ";
        std::cin >> input_size;
    }
    init_game_inner_array(game, input_size); // ֮���ʼ���ڲ�����
    cct_setfontsize("������", 32, 16);
    cct_cls();
    std::cout << "���Լ���/������/�Ҽ����س��˳� \n";
    cct_setcolor(COLOR_HWHITE, COLOR_BLACK);
    print_map_with_border(game, true, true);

    int display_x = 10;
    int display_y = 8 + game.size * 4 + game.colMax;
    cct_gotoxy(display_x, display_y);
    cct_enable_mouse();
    int mouseX = -1, mouseY = -1;
    int mouse_action = -1;
    int keycode1 = -1;
    int keycode2 = -1;
    while (1) 
    {
        // ��ȡ���ͼ����¼�
        int event_type = cct_read_keyboard_and_mouse(mouseX, mouseY, mouse_action, keycode1, keycode2);
        char pos_row, pos_col;
        bool right_pos = get_pos_with_border(mouseX, mouseY, game, pos_row, pos_col);

        // ����Ǽ����¼�
        if (event_type == CCT_KEYBOARD_EVENT) 
        {
            // ����Ƿ����˻س���
            if (keycode1 == 0x0D) 
            {
                cct_gotoxy(display_x, display_y);
                std::cout << "                     ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [�����س���] ";
                return;
            }
        }

        // ���������¼�
        if (event_type == CCT_MOUSE_EVENT) 
        {
            // ����
            if (mouse_action == MOUSE_LEFT_BUTTON_CLICK && right_pos)
            {
                cct_gotoxy(0, 0);
                std::cout << "                                               ";
                cct_gotoxy(0, 0);
                // ����µ�������¼�����
                std::cout << "���ڣ� " << mouseX << "�� " << mouseY << "��";


                cct_gotoxy(display_x, display_y);
                std::cout << "                     ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [�������] " << pos_row << "��" << pos_col << "��";
                return;
            }
            else if (mouse_action == MOUSE_RIGHT_BUTTON_CLICK && right_pos) 
            {
                cct_gotoxy(0, 0);
                std::cout << "                                               ";
                cct_gotoxy(0, 0);
                // ����µ�������¼�����
                std::cout << "���ڣ� " << mouseX << "�� " << mouseY << "��";


                cct_gotoxy(display_x, display_y);
                std::cout << "                     ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [�����Ҽ�] " << pos_row << "��" << pos_col << "��";
                return;
            }

            cct_gotoxy(display_x, display_y);
            std::cout << "                    ";
            cct_gotoxy(display_x, display_y);

            if (right_pos)
                std::cout << " [��ǰ���] " << pos_row << "��" << pos_col << "��";
            else  
                std::cout << " [��ǰ���] λ�÷Ƿ�";
        }
    }

}

void open_cheat(GameData& game, bool cheat) 
{
    // �ر�cheat
    if (!cheat)
    {
        for (int i = 0; i < game.size; i++) 
        {
            for (int j = 0; j < game.size; j++) 
            {
                // ������������
                int row_index = 2 + 6 + game.colMax + 4 * i;
                int col_index = 5 * 2 + game.rowMax * 2 + 4 * j * 2;
                clear_item_with_border(row_index, col_index);
                if (game.operations[i][j]) 
                    print_0_with_border(row_index, col_index);
                else if (game.marked[i][j]) 
                    print_x_with_border(row_index, col_index);
            }
        }
    }
    // ��cheat
    else 
    {
        for (int i = 0; i < game.size; i++) 
        {
            for (int j = 0; j < game.size; j++) 
            {
                // ������������
                int row_index = 2 + 6 + game.colMax + 4 * i;
                int col_index = 5 * 2 + game.rowMax * 2 + 4 * j * 2;
                // �����Ǳ��
                if (game.board[i][j] && game.marked[i][j]) 
                {
                    print_x_wrong_marked(row_index, col_index);
                }
                // �����������ѡ��
                else if (game.board[i][j] && game.operations[i][j]) 
                {
                    print_0_with_border(row_index, col_index);
                }
                // ������ûѡ��
                else if (game.board[i][j] && !game.operations[i][j])
                {
                    print_0_not_choose(row_index, col_index);
                }
                // û�����Ǵ�ѡ
                else if (!game.board[i][j] && game.operations[i][j])
                {
                    print_0_wrong_choose(row_index, col_index);
                }
                // û�����Ǳ��
                else if (!game.board[i][j] && game.marked[i][j])
                {
                    print_x_with_border(row_index, col_index);
                }
            }
        }
    }
}

void print_submission_K(GameData& game) 
{
    cct_cls();
    std::cout << "�����������С��5/10/15��: ";
    int input_size = 0;
    std::cin >> input_size;
    while (input_size != 5 && input_size != 10 && input_size != 15) 
    {
        std::cout << "�����������С��5/10/15��: ";
        std::cin >> input_size;
    }
    init_game_inner_array(game, input_size); // ֮���ʼ���ڲ�����
    cct_cls();
    cct_setfontsize("������", 32, 16);
    std::cout << "���ѡ��/�Ҽ�ѡX���س��ύ��Q/q������Z/z����";
    print_map_with_border(game, true, false);
    int display_x = 10;
    int display_y = 8 + game.size * 4 + game.colMax;
    cct_gotoxy(display_x, display_y);
    cct_enable_mouse();
    int mouseX = -1, mouseY = -1;
    int mouse_action = -1;
    int keycode1 = -1;
    int keycode2 = -1;
    bool cheat = false;
    while (1) 
    {
        // ��ȡ���ͼ����¼�
        int event_type = cct_read_keyboard_and_mouse(mouseX, mouseY, mouse_action, keycode1, keycode2);
        char pos_row, pos_col;
        bool right_pos = get_pos_with_border(mouseX, mouseY, game, pos_row, pos_col);
        int top_border = 2 + 4 + game.colMax + 2;
        int left_border = 4 * 2 + game.rowMax * 2 - 2 + 4;
        cct_setcolor(COLOR_BLACK, COLOR_WHITE);
        // ����Ǽ����¼�
        if (event_type == CCT_KEYBOARD_EVENT) 
        {
            // ����Ƿ����˻س���
            if (keycode1 == 0x0D) 
            {
                cct_gotoxy(display_x, display_y);
                std::cout << "                                                    ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [�����س���] ";
                Sleep(100);
                // �����ύ �ɹ���return ʧ����continue
                cct_gotoxy(display_x, display_y);
                std::cout << "                                                      ";
                cct_gotoxy(display_x, display_y);
                if (!check_answer(game)) 
                {
                    Sleep(500);
                    cct_gotoxy(display_x, display_y);
                    std::cout << "                                                   ";
                    cct_gotoxy(display_x, display_y);
                    if (right_pos)
                        std::cout << " [��ǰ���] " << pos_row << "��" << pos_col << "��";
                    else   
                        std::cout << " [��ǰ���] λ�÷Ƿ�";
                    continue;
                }
                else
                {
                    cct_gotoxy(display_x, display_y);
                    std::cout << "                                                ";
                    cct_gotoxy(display_x, display_y);
                    std::cout << " [�ύ�ɹ�] ";
                    return;
                }

            }
            // ����Ƿ����� Q �� q ��
            if (keycode1 == 0x51 || keycode1 == 0x71)
            { // Q �� q �� ASCII ��
                cct_gotoxy(display_x, display_y);
                std::cout << "                     ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [����Q/q����Ϸ����] ";
                return; // �˳�����
            }
            if (keycode1 == 0x5A || keycode1 == 0x7A)
            { // Z �� z �� ASCII ��
                cct_gotoxy(display_x, display_y);
                std::cout << "                     ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [����Z/z������/�ر�����] ";
                cheat = !cheat;
                open_cheat(game, cheat);
                Sleep(100);
                continue;
            }
        }

        // ���������¼�
        if (event_type == CCT_MOUSE_EVENT) 
        {
            // ����
            if (mouse_action == MOUSE_LEFT_BUTTON_CLICK && right_pos) 
            {
                cct_gotoxy(display_x, display_y);
                std::cout << "                     ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [�������] " << pos_row << "��" << pos_col << "��";
                int row_index = int(pos_row - 'A');
                int col_index = int(pos_col - 'a');
                int circle_y = left_border + col_index * 8;
                int circle_x = top_border + row_index * 4;
                // ��X��
                if (game.marked[row_index][col_index])
                {
                    game.marked[row_index][col_index] = !game.marked[row_index][col_index];
                    game.operations[row_index][col_index] = !game.operations[row_index][col_index];
                    print_0_with_border(circle_x, circle_y);
                }
                else
                {
                    game.operations[row_index][col_index] = !game.operations[row_index][col_index];
                    if (game.operations[row_index][col_index]) 
                        print_0_with_border(circle_x, circle_y);
                    else
                        clear_item_with_border(circle_x, circle_y);
                }
                cct_gotoxy(display_x, display_y);
                cct_setcolor(COLOR_BLACK, COLOR_WHITE);
            }

            else if (mouse_action == MOUSE_RIGHT_BUTTON_CLICK && right_pos)
            {
                cct_gotoxy(display_x, display_y);
                std::cout << "                     ";
                cct_gotoxy(display_x, display_y);
                std::cout << " [�����Ҽ�] " << pos_row << "��" << pos_col << "��";
                int row_index = int(pos_row - 'A');
                int col_index = int(pos_col - 'a');
                int circle_y = left_border + col_index * 8;
                int circle_x = top_border + row_index * 4;
                // ��O��
                if (game.operations[row_index][col_index]) 
                {
                    game.operations[row_index][col_index] = !game.operations[row_index][col_index];
                    game.marked[row_index][col_index] = !game.marked[row_index][col_index];
                    print_x_with_border(circle_x, circle_y);
                }
                else 
                {
                    game.marked[row_index][col_index] = !game.marked[row_index][col_index];
                    if (game.marked[row_index][col_index]) 
                        print_x_with_border(circle_x, circle_y);
                    else 
                        clear_item_with_border(circle_x, circle_y);
                }
                cct_gotoxy(display_x, display_y);
                cct_setcolor(COLOR_BLACK, COLOR_WHITE);
            }


            Sleep(50);
            cct_gotoxy(display_x, display_y);
            std::cout << "                                                        ";
            cct_gotoxy(display_x, display_y);

            if (right_pos) 
                std::cout << " [��ǰ���] " << pos_row << "��" << pos_col << "��";
            else  
                std::cout << " [��ǰ���] λ�÷Ƿ�";
        }
    }
}